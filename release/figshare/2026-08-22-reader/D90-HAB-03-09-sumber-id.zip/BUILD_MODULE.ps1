$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$moduleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceDir = Join-Path $moduleRoot 'source\id-ID'
$buildRoot = Join-Path $moduleRoot 'build'
$outputDir = Join-Path $moduleRoot 'output\pdf'
New-Item -ItemType Directory -Force -Path $buildRoot, $outputDir | Out-Null

$env:SOURCE_DATE_EPOCH = '1783900800'
$env:FORCE_SOURCE_DATE = '1'
$env:TZ = 'UTC'

$units = @(
    'D90-HAB-03-subgradien-id.tex',
    'D90-HAB-04-metode-subgradien-terproyeksi-id.tex',
    'D90-HAB-05-metode-gradien-proksimal-id.tex',
    'D90-HAB-06-akselerasi-id.tex',
    'D90-HAB-07-dualitas-id.tex',
    'D90-HAB-08-penurunan-gradien-stokastik-id.tex',
    'D90-HAB-09-transportasi-optimal-id.tex'
)

Push-Location $sourceDir
try {
    foreach ($unit in $units) {
        $stem = [System.IO.Path]::GetFileNameWithoutExtension($unit)
        $unitBuild = Join-Path $buildRoot $stem
        New-Item -ItemType Directory -Force -Path $unitBuild | Out-Null
        & latexmk -gg -pdf -interaction=nonstopmode -halt-on-error -file-line-error "-outdir=$unitBuild" $unit
        if ($LASTEXITCODE -ne 0) { throw "latexmk failed for $unit" }
        Copy-Item -LiteralPath (Join-Path $unitBuild ($stem + '.pdf')) -Destination (Join-Path $outputDir ($stem + '.pdf')) -Force
    }
}
finally {
    Pop-Location
}

& python (Join-Path $moduleRoot 'qa\build_habring_companion_reader.py')
if ($LASTEXITCODE -ne 0) { throw 'Combined reader build failed' }
Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $outputDir 'D90-HAB-03-09-modul-pendamping-id.pdf')
