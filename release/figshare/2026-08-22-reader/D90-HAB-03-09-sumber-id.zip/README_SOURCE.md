# Modul Pendamping Habring Bab 3-9 - sumber Bahasa Indonesia

This compact source package rebuilds the seven standalone Indonesian Habring
Chapter 3-9 readers and their combined 103-page reader-first PDF. It contains
only the Habring-derived module; no Penn or other mixed-license work is present.

Authority: Andreas Habring, *Lecture Notes: Convex Optimization*,
arXiv:2607.11664v1, DOI 10.48550/arXiv.2607.11664. The immutable arXiv v1
submission is licensed under Creative Commons Attribution 4.0 International.
This is an independent Indonesian translation/adaptation with identified
changes and corrections; it is not reviewed, approved, sponsored, or endorsed
by Andreas Habring, TU Graz, arXiv, or their institutions.

The custom class and two raster figures are exact components of the CC BY 4.0
arXiv submission but carry no separate embedded notices. The source preface
credits Christian Clason's template and Thomas Pock's lecture slides. Those
submission-level provenance caveats are retained in
`COMPONENT_RIGHTS_HABRING.csv`.

## Rebuild

Verified local toolchain:

- MiKTeX 26.5 / pdfTeX 1.40.29;
- latexmk 4.88 and Biber 2.21;
- Python with `pypdf==6.10.0` and `reportlab==4.4.9`;
- Windows Arial fonts for byte-identical cover reproduction.

Install the two Python packages from `requirements-reader.txt`, then run from
the extracted package root:

```powershell
powershell -ExecutionPolicy Bypass -File .\BUILD_MODULE.ps1
```

The script builds each unit with fixed source-date settings, places the seven
PDFs in `output/pdf`, and runs `qa/build_habring_companion_reader.py`. The
admitted combined reader has 103 A4 pages, `/Lang id-ID`, eight outline entries,
all fonts embedded with Unicode maps, no encryption or JavaScript, and SHA-256
`6cd291cc447999b7cd72622e8c2003b837cf4f21ea5de0fcb7094913e20acd87`.
On a different TeX/font platform, semantic content and pagination should be
checked even if PDF bytes differ.

The combined PDF is not semantically tagged and no independent human/native-
speaker Indonesian review is claimed. Exact determined source corrections are
listed in `CORRECTIONS_HABRING.jsonl`.
