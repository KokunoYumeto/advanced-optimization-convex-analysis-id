$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceDir = Join-Path $bundleRoot 'source\id-ID'
$buildRoot = Join-Path $bundleRoot 'build'
$outputPdf = Join-Path $bundleRoot 'output\pdf'
New-Item -ItemType Directory -Force -Path $buildRoot, $outputPdf | Out-Null

$env:SOURCE_DATE_EPOCH = '1783900800'
$env:FORCE_SOURCE_DATE = '1'
$env:TZ = 'UTC'

& python (Join-Path $bundleRoot 'qa\build_habring_ch01_ch02.py')
if ($LASTEXITCODE -ne 0) { throw 'Bab 1-2 gagal dibangun' }

$units = @(
    'D90-HAB-03-subgradien-id.tex',
    'D90-HAB-04-metode-subgradien-terproyeksi-id.tex',
    'D90-HAB-05-metode-gradien-proksimal-id.tex',
    'D90-HAB-06-akselerasi-id.tex',
    'D90-HAB-07-dualitas-id.tex',
    'D90-HAB-08-penurunan-gradien-stokastik-id.tex',
    'D90-HAB-09-transportasi-optimal-id.tex'
)

Push-Location $sourceDir
try {
    foreach ($unit in $units) {
        $stem = [System.IO.Path]::GetFileNameWithoutExtension($unit)
        $unitBuild = Join-Path $buildRoot $stem
        New-Item -ItemType Directory -Force -Path $unitBuild | Out-Null
        & latexmk -gg -pdf -interaction=nonstopmode -halt-on-error -file-line-error "-outdir=$unitBuild" $unit
        if ($LASTEXITCODE -ne 0) { throw "latexmk gagal untuk $unit" }
        Copy-Item -LiteralPath (Join-Path $unitBuild ($stem + '.pdf')) -Destination (Join-Path $outputPdf ($stem + '.pdf')) -Force
    }
}
finally {
    Pop-Location
}

& python (Join-Path $bundleRoot 'qa\build_habring_full_reader.py')
if ($LASTEXITCODE -ne 0) { throw 'Pembaca PDF lengkap gagal dibangun' }
& python (Join-Path $bundleRoot 'qa\build_habring_full_html.py')
if ($LASTEXITCODE -ne 0) { throw 'Pembaca HTML lengkap gagal dibangun' }
& python (Join-Path $bundleRoot 'qa\build_habring_full_epub.py')
if ($LASTEXITCODE -ne 0) { throw 'Pembaca EPUB lengkap gagal dibangun' }

Get-FileHash -Algorithm SHA256 -LiteralPath @(
    (Join-Path $bundleRoot 'output\pdf\D90-HAB-01-09-catatan-kuliah-optimisasi-konveks-id.pdf'),
    (Join-Path $bundleRoot 'output\html\D90-HAB-01-09-catatan-kuliah-optimisasi-konveks-id.html'),
    (Join-Path $bundleRoot 'output\epub\D90-HAB-01-09-catatan-kuliah-optimisasi-konveks-id.epub')
)
