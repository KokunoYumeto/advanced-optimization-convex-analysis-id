# Optimisasi Konveks — sumber edisi Bahasa Indonesia

Paket sumber ringkas ini membangun ulang edisi Bahasa Indonesia lengkap untuk
prakata dan Bab 1–9 Andreas Habring, *Lecture Notes: Convex Optimization*,
arXiv:2607.11664v1. Cakupan spine Habring v1 sudah lengkap; buku kuliah O015
yang lebih besar masih parsial karena suplemen terstruktur dan lapisan asli
yang tidak tumpang tindih dikelola secara terpisah. Paket ini tidak memuat byte
dari komponen MIT, Penn, Royer, atau Becker.

Sumber berwenang adalah paket arXiv v1 berukuran 230116 byte dengan SHA-256
`d9a22d09d0245bd7bfe4d162dab6ea4bb77552c6cec9e41820db7861b45b6748`,
tersedia di <https://arxiv.org/e-print/2607.11664v1>. Karya sumber, terjemahan,
adaptasi, materi pengantar, dan perangkat pembangunan dalam paket ini tersedia
berdasarkan Creative Commons Attribution 4.0 International (CC BY 4.0). Atribusi,
tautan lisensi, identifikasi perubahan, dan non-endorsement harus dipertahankan.
Kelas khusus dan tujuh gambar raster diwarisi dari submission CC BY 4.0, tetapi
tidak memuat pemberitahuan terpisah atau sumber pembangkit; rincian ini
dipertahankan di `COMPONENT_RIGHTS_HABRING.csv`.

Perubahan meliputi penerjemahan Bahasa Indonesia, pelokalan istilah dan label,
deskripsi akses untuk gambar, perbaikan TeX, serta koreksi matematis yang dapat
ditentukan. Segmen sumber stabil dan catatan unit mempertahankan keterlacakan.
Ini adalah edisi mandiri: Andreas Habring, TU Graz, arXiv, dan institusi terkait
tidak menyusun, memeriksa, menyetujui, mensponsori, atau mendukung edisi ini.

Provenans produksi: OpenAI Codex gpt-5.6-sol, Ultra, atas instruksi pengguna.
Seluruh kredit penulis dan sumber dipertahankan.

## Membangun ulang

Prasyarat yang diverifikasi pada checkpoint ini:

- MiKTeX 26.5 / pdfTeX 1.40.29, latexmk 4.88, Biber 2.21;
- Pandoc 3.9.0.2;
- Python dengan `pypdf==6.10.0` dan `reportlab==4.4.9`;
- font Arial Windows untuk reproduksi byte-identik halaman sampul.

Dari akar hasil ekstraksi, jalankan:

```powershell
powershell -ExecutionPolicy Bypass -File .\BUILD_ALL_READERS.ps1
```

Hasil checkpoint yang diakui:

- PDF 139 halaman: SHA-256 `da2b421b97efce4e3d7b8cf6be9938d17b7768b9c6bcb4846b09b9c692b34c41`;
- HTML mandiri dan reflowable: SHA-256 `717ee81912a8b903acc87e5c59d830aa1d8c78abdda6e0c869d66b9a7bcde3a4`;
- EPUB 3: SHA-256 `c630e25db3cbbfa6f6afa7213e526c47586b6e7b44f709095ea5a3881756fd41`.

PDF dapat dicari, tidak terenkripsi, mendeklarasikan `id-ID`, dan memiliki
navigasi bab, tetapi belum bertag semantik. HTML dan EPUB menyediakan permukaan
reflowable. Tidak ada klaim peninjauan oleh penulis sumber atau institusinya.
