# Perubahan terhadap sumber arXiv v1

Edisi ini menerjemahkan prakata dan seluruh sembilan bab ke Bahasa Indonesia,
melokalkan judul dan label, menambahkan identitas segmen stabil, menyediakan
deskripsi akses untuk gambar, serta memperbaiki kesalahan TeX dan matematika
yang dapat ditentukan tanpa mengubah maksud matematis. Urutan, rumus, bukti,
latihan, rujukan silang, dan aset sumber dipertahankan sejauh berlaku.

Setiap wrapper mencantumkan identitas sumber, lisensi, perubahan, dan
non-endorsement. Berkas bab memuat penanda segmen yang mengikatnya ke sumber
arXiv v1. Rincian hak komponen tersedia di `COMPONENT_RIGHTS_HABRING.csv`.

Provenans produksi: OpenAI Codex gpt-5.6-sol, Ultra, atas instruksi pengguna.
