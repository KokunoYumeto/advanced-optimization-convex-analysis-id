# O015 build and QA record

As of: 2026-08-21  
Unit: Habring Chapter 3 — Subgradients / Subgradien  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-03-subgradien-id.tex` — 3,940 bytes — SHA-256 `48fe2efc3fa2b724963e40942906061c5d7dc54c92ae4280641e951d55b4d669`.
- Translated chapter: `source/id-ID/habring-03-subgradien-id.tex` — 19,266 bytes — SHA-256 `d04ff82898c157f56924c6c08fd204bcd97625f060847fd8a0b6f7a2b90b0a5c`.
- Macros: `source/id-ID/macros-id.tex` — 4,465 bytes — SHA-256 `135642edfaffb7ec15e02e330dde76e694abe957da5f1a401c8563f9d885c1c2`.
- Class: `source/id-ID/shinybook.cls` — 10,133 bytes — SHA-256 `83514a06b2884dcaa02575bb3409d2f8cc9cf2fc6e6aef344b442d424850f2c0`.
- Figures are exact copies of the two arXiv-v1 raster assets and are bound separately in `COMPONENT_RIGHTS.csv` and the backend.

The final retained build used pdfTeX 1.40.29 / MiKTeX 26.5 and four `pdflatex` passes from `source/id-ID`, with output directed to `build/habring-unit-03-id`. The exact historical shell command was not captured as a standalone receipt; `pass4.console.txt` and the final `.log` are retained. Reproduction must use the listed input hashes and the same toolchain/options: `-interaction=nonstopmode -halt-on-error -file-line-error`.

## Final artifact

- Build PDF: `build/habring-unit-03-id/D90-HAB-03-subgradien-id.pdf`.
- Publication copy: `output/pdf/D90-HAB-03-subgradien-id.pdf`.
- Both: 516,084 bytes; 15 A4 pages; SHA-256 `45f7bc24ff46079881e42be9aa6f1b508c324a208f2b4dd82e35e7e3a6d544b4`.
- Final log: 101,648 bytes; SHA-256 `217291b4c0d275977674b03a5e1dc05bc293503c7583e9ef41a1a2cbca80a6ad`.
- Final text extraction: 25,751 bytes; SHA-256 `531760f570f311256d5b141bd5f28e5495469d9bdf0f2f0c70ce5260a400d2eb`.
- Two consecutive final builds were byte-identical.

## Structural and mathematical QA

`python qa/audit_subgradient_unit.py` passes:

- authority and target hashes exact;
- 61/61 ordered environments preserved;
- 11/11 stable segment markers present and ordered;
- source labels retained, with one declared target chapter label;
- two expected figure paths retained;
- 230 source and 252 target formula surfaces aligned into 46 explicit delta blocks;
- every non-editorial delta is ledger-bound;
- formula-delta manifest SHA-256 `c979be4ecb19687c87ef590feda4d5ba8f083a945a0e0cda98236d8d7581b681`.

An independent final rereview of target SHA-256 `d04ff828…` found P1=0, P2=0, P3=0. It separately confirmed the standing-space conventions, proof-exposition delta, finite-dimensional qualifications, supporting-hyperplane repair, and all referenced adverse-ledger IDs.

## Computation QA

`python qa/validate_subgradient_unit.py` passes with Python 3.13.9, NumPy 2.4.4, and SciPy 1.17.1:

- HiGHS solves the epigraph LP for `min |x-1|` at `x=1`, objective 0;
- SLSQP verifies the composite two-variable `l1` example at approximately `(1.5, 0.375)`;
- the explicit subgradient optimality residual is `6.50e-8` in infinity norm.

Result: `qa/SUBGRADIENT_SOLVER_RESULTS.json` — 980 bytes — SHA-256 `65dde2a94aeb55e71667146509f4b5302e947d2e79af2da8339dd6049974cc52`.

## Visual, text, and accessibility QA

All 15 physical pages were rendered and inspected in three contact sheets. The two mathematical figures and the reader-facing corrections appendix were also checked at higher resolution. No clipping, overlap, blank page, broken glyph, or unreadable formula was found. The extracted text has no active English prose residue under the bounded reader scan.

The PDF is unencrypted, searchable, and declares `/Lang` as `id-ID`. Both figures have Indonesian descriptions in the editable source. The PDF is not tagged; no semantic HTML/EPUB surface is claimed at this boundary.

## Nonblocking toolchain warnings

The final log contains only inherited/template/toolchain warnings: obsolete `xcolor` `hyperref` option; KOMA-Script with `tocloft`; unavailable Indonesian modules for `glossaries`, `tracklang`/`datatool`, and `biblatex`. It contains no overfull or underfull box, unresolved reference, undefined control sequence, or LaTeX error.

---

# Habring Chapter 4 build and QA record

As of: 2026-08-21  
Unit: Habring Chapter 4 — Projected subgradient descent / Metode subgradien terproyeksi  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-04-metode-subgradien-terproyeksi-id.tex` — 4,297 bytes — SHA-256 `4efde33cf820393e001153370cdf52f96bd8b22d24582ca17063cc87e492d249`.
- Translated chapter: `source/id-ID/habring-04-metode-subgradien-terproyeksi-id.tex` — 16,612 bytes — SHA-256 `29fdc330007009bd765a17ca1dcd0cf130ff802312ebb402bf03413da5f96a7d`.
- Authority chapter: `authority/habring/source-v1/projected_subgradient_method.tex` — 14,391 bytes — SHA-256 `44ac28a0f0b67fed4855f7ed91089fab52f77804115f2a06201bff98437bd8da`.
- The wrapper uses the frozen authority bibliography `authority/habring/source-v1/references.bib` directly.

The retained build used pdfTeX 1.40.29 / MiKTeX 26.5 with `latexmk` 4.88 and Biber, from `source/id-ID`, with `SOURCE_DATE_EPOCH=1786643315`, `TZ=UTC`, and output directed to `build/habring-unit-04-id`.

## Final artifact

- Build PDF: `build/habring-unit-04-id/D90-HAB-04-metode-subgradien-terproyeksi-id.pdf`.
- Publication copy: `output/pdf/D90-HAB-04-metode-subgradien-terproyeksi-id.pdf`.
- Both: 370,824 bytes; 13 A4 pages; SHA-256 `5c9991af837995b2e24f4a9060eb3b0efe7b2d71a9bbde01948eeb81ebfd63b7`.
- Final log: 101,402 bytes; SHA-256 `1e389bcb5d005b5b65772e7383766cfe3317293cd7da48491ea65ce38e3db87d`.
- Final text extraction: 27,027 bytes; SHA-256 `1b835413d44817328ca9945962963ae4bdeadec0d5fa3eba0dfb88b5005253e7`.
- A forced full rebuild reproduced the PDF byte-for-byte.

## Structural and mathematical QA

`python qa/audit_projected_subgradient_unit.py` passes:

- authority and target hashes exact;
- all 67 ordered environments and four authority labels preserved;
- eight stable translation segments present and ordered;
- three footnotes, the Beck citation, both informal exercise prompts, and the no-figure closure retained;
- 140 authority and 169 target formula surfaces aligned into 40 explicit delta blocks;
- every substantive delta is bound to O015-HAB-ADV-0019 through O015-HAB-ADV-0027;
- formula-delta manifest SHA-256 `d0453330d42781afffe1e1b7ad3d5a663533509f43a754f9958785b9646171b4`.

An independent final rereview of target SHA-256 `29fdc330…` found P1=0, P2=0, P3=0. It separately confirmed the Hilbert-space projection proof, projection characterization and nonexpansiveness, the fundamental inequality, Polyak and general step rules, the corrected strongly convex constants and induction, both exercises, and the transparency of all nine ledger entries.

## Computation QA

`python qa/validate_projected_subgradient_unit.py` passes with Python 3.13.9, NumPy 2.4.4, and SciPy 1.17.1:

- 512 deterministic projection samples satisfy the variational inequality and nonexpansiveness with maximum residual 0;
- a constrained nonsmooth example validates the fundamental inequality, Polyak and general schedules, and the nonzero-subgradient-at-constrained-optimum counterexample;
- an SLSQP epigraph solve validates the strongly convex value and distance rates with maximum residual 0.

Result: `qa/PROJECTED_SUBGRADIENT_SOLVER_RESULTS.json` — 1,773 bytes — SHA-256 `67719078430b0e3fbfabca3dbfac3d08fed6594659c5d0b2ae69cfd2a1cbb04a`.

## Visual, text, and accessibility QA

All 13 physical pages were rendered and inspected in a contact sheet; the chapter opening, Polyak proof/rate, and correction appendix were also inspected at full size. No clipping, overlap, blank page, broken glyph, or unreadable formula was found. The bounded English-residue scan found only cited English source titles.

The PDF is unencrypted, searchable, and declares `/Lang` as `id-ID`. It is not tagged; no semantic HTML/EPUB surface is claimed at this boundary.

## Nonblocking toolchain warnings

The final log contains only inherited/template/toolchain warnings: the locale fallback, obsolete `xcolor` `hyperref` option, KOMA-Script with `tocloft`, and unavailable Indonesian localization for `biblatex`. It contains no overfull or underfull box, unresolved reference, undefined control sequence, or LaTeX error.

## Two-unit backend verification

`python qa/validate_backend.py` passes with zero errors after deterministic generation/validation. The backend contains 238 records and 19 stable translation segments. After the final component-rights refresh, `backend/records.jsonl` is 161,956 bytes with SHA-256 `cfc027adbb6104adf9290222d5e37403eefcd6d3af9abe7acc765a52daabfca0`; its lossless `backend/records.csv` projection is 195,684 bytes with SHA-256 `9bc78b5f038bb784d92a04b1682781b3f00edcccd6008f0c0a789ca35ae36916`. Chapter 3 and Chapter 4 both record passed independent mathematical rereviews; independent Indonesian language review remains `not_recorded`, and PDF accessibility remains `pass_with_limitation` because the PDFs are untagged.

---

# Habring Chapter 5 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 5 — Proximal Gradient Methods / Metode Gradien Proksimal  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-05-metode-gradien-proksimal-id.tex` — 4,817 bytes — SHA-256 `8c67641de7ebf2e06afefa2309c09823e78a4d3d5dbba89a28536392d82c359d`.
- Translated chapter: `source/id-ID/habring-05-metode-gradien-proksimal-id.tex` — 20,575 bytes — SHA-256 `1292f09d375ff0e0ff12e7c87e673596400bb94f228db70d49f9a517b1678691`.
- Authority chapter: `authority/habring/source-v1/proximal_gradient.tex` — 18,464 bytes — SHA-256 `59d5694742f0e2f9f46da0c1418b5fe0ff18521c49078ed29c843b6e8c701f6e`.
- The wrapper uses the frozen authority bibliography `authority/habring/source-v1/references.bib` directly.

The retained build used pdfTeX 1.40.29 / MiKTeX 26.5 with `latexmk` 4.88 and Biber, from `source/id-ID`, with `SOURCE_DATE_EPOCH=1786665600`, `TZ=UTC`, and output directed to `build/habring-unit-05-id`.

## Final artifact

- Build PDF: `build/habring-unit-05-id/D90-HAB-05-metode-gradien-proksimal-id.pdf`.
- Publication copy: `output/pdf/D90-HAB-05-metode-gradien-proksimal-id.pdf`.
- Both: 473,685 bytes; 15 A4 pages; SHA-256 `6f8aa99f6d0395f3c732ed64d2b5cadd5d95ff2195e2504e959d31a3c010731d`.
- Final log: 99,841 bytes; SHA-256 `462372113f47285d8a7940c1d31c779b673c8ae1da85401840310cab9acd8deb`.
- Final text extraction: 33,973 bytes; SHA-256 `a2fdf8d859cd6767f951dfa4a17c8b89c470d98b13d24e01ce1783191e2313f8`.
- A forced full rebuild reproduced the PDF byte-for-byte.

## Structural and mathematical QA

`python qa/audit_proximal_gradient_unit.py` passes:

- authority and target hashes exact;
- all 78 ordered environments preserved;
- eight stable translation segments present and ordered;
- nine label occurrences retained in source order, with the duplicated second authority label transparently remapped to `proximal:eq:moreau_diff2_bound`;
- the Beck citation, all three informal learner prompts or their completed dispositions, the one unnumbered display, and the no-figure/no-footnote/no-input closure retained;
- 162 authority and 188 target formula surfaces aligned into 38 explicit delta blocks;
- every substantive delta is bound to O015-HAB-ADV-0028 through O015-HAB-ADV-0038;
- formula-delta manifest SHA-256 `3b910b86e304b2ba472df7fbf642db5928824ee999b551cc60f287b2c5705a3c`.

An independent rereview of the complete target and a final byte-delta rereview of target SHA-256 `1292f09d…` found P1=0, P2=0, P3=0. It confirmed the proximal existence/uniqueness and fixed-point arguments, Moreau definition and smoothing proof, completed projection/soft-threshold/Euclidean-shrinkage example, all six prox rules, the smooth descent lemma, and the corrected step conditions, polarization, indexing, rate, and full-sequence convergence theorem.

## Computation QA

`python qa/validate_proximal_gradient_unit.py` passes with Python 3.13.9, NumPy 2.4.4, and SciPy 1.17.1:

- box projection agrees with independent SLSQP to `2.23e-14` in infinity norm;
- coordinate soft threshold agrees with an SLSQP epigraph solve to `2.67e-7`, and Euclidean shrinkage agrees with an independent radial solve to `4.68e-9`;
- the Moreau-envelope gradient formula agrees with centered finite differences to `4.68e-10`;
- a quadratic-plus-`l1` forward–backward run uses the exact spectral constant `L=4.6167578080095515` and `tau L=0.95`; descent, telescoping, monotonicity, and corrected `O(1/n)` value bounds have no positive violation beyond floating-point noise;
- the independently solved optimum has gradient-mapping norm `9.79e-8`.

Result: `qa/PROXIMAL_GRADIENT_SOLVER_RESULTS.json` — 5,769 bytes — SHA-256 `de96482c608bbca67fc0a14eeb32a4e69890a97b8f6834a389ea198d2b440a54`.

## Visual, text, and accessibility QA

All 15 physical pages were rendered at 120 dpi and inspected in a contact sheet. The chapter opening, prox formulas/rules, Moreau proof, convergence theorem, two-page correction appendix, and attribution page were also inspected at full size. No clipping, overlap, blank page, broken glyph, or unreadable formula was found. The bounded English-residue scan found only the cited English source title and the explicitly identified source chapter title.

The PDF is unencrypted, searchable, and declares `/Lang` as `id-ID`. It is not tagged; no semantic HTML/EPUB surface is claimed at this boundary. Independent Indonesian language review remains `not_recorded`.

## Nonblocking toolchain warnings

The final log contains only inherited/template/toolchain warnings: locale fallback, obsolete `xcolor` `hyperref` option, KOMA-Script with `tocloft`, and unavailable Indonesian localization for `biblatex`. It contains no overfull or underfull box, unresolved reference or citation, undefined control sequence, or LaTeX error.

## Three-unit backend verification

`python qa/extend_backend_ch05.py` followed by `python qa/validate_backend.py` passes with zero errors. The backend contains 337 records and 27 stable translation segments: Chapter 3 has 11, Chapter 4 has 8, and Chapter 5 has 8. The Chapter 5 extension adds 99 records across the unit, segments, concepts, terms, source learning surfaces, corrections, QA, artifacts, rights, and relations. Two generation/validation cycles were byte-identical, and a separate baseline reconstruction proved the 238 pre-Chapter-5 records semantically unchanged except for legitimate artifact byte/hash refreshes. Independent Indonesian language review remains `not_recorded`; PDF accessibility remains `pass_with_limitation` because the reader PDFs are untagged. Final JSONL/CSV hashes are refreshed after the current control records below and must be read from the validator output rather than this prose to avoid a self-referential artifact-hash loop.

---

# Habring Chapter 6 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 6 — Acceleration / Akselerasi  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-06-akselerasi-id.tex` — 5,491 bytes — SHA-256 `46903dd6b6ff8c845624931d37d9b24fd37cd89f0bf77601ba11539c59dfd5b9`.
- Translated chapter: `source/id-ID/habring-06-akselerasi-id.tex` — 24,690 bytes — SHA-256 `b1e27d912bc94722ec1c33257598c074eec8a6f5bf81f43b8946f85b48f4c35a`.
- Authority chapter: `authority/habring/source-v1/acceleration.tex` — 18,873 bytes — SHA-256 `2ff1e10e9421c0fe01a09140e3e230cb2d3728c30c572bb6ca5513b229f1e605`.

The retained build used pdfTeX 1.40.29 / MiKTeX 26.5 with `latexmk` 4.88 and Biber, from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and output directed to `build/habring-unit-06-id`. The wrapper locally disables microtype expansion, loads the Libertine/newtx font maps, and localizes equation cross-references as Indonesian `persamaan`; shared Chapter 3–5 inputs were not changed.

## Final artifact

- Build and publication PDF: `output/pdf/D90-HAB-06-akselerasi-id.pdf` — 392,662 bytes; 15 A4 pages; SHA-256 `cb9edf46d8d2582591ad3114f9a2b316073825dfd48079d12560793ad4bca0a0`.
- Final log: `build/habring-unit-06-id/D90-HAB-06-akselerasi-id.log` — 97,942 bytes; SHA-256 `0775c19ecd2e8356e7b33bd50c30871f233e0c7d05dd703ba2ec19a4f7f560f0`.
- Final text extraction: `qa/D90-HAB-06-akselerasi-id.txt` — 37,033 bytes; SHA-256 `d2679e94ce7e44cdcf183b17e73295b5b5093a1612b2460c0c6ecba512431cda`.
- Two forced fixed-epoch final builds reproduced the PDF byte-for-byte.

## Structural and mathematical QA

`python qa/audit_acceleration_unit.py` passes. The audit script is 17,917 bytes with SHA-256 `f97926aecce6f63a1dcc7733785e0f283e064888ed68d6642d676dcdac3fc8c4`; its 37,873-byte report has SHA-256 `e82f254fb7e69d498162ffcdfb70fe7d4929556351f892872bb8e65da3715b4b`.

- all 99 ordered environments and all seven labels match the authority exactly;
- all twelve stable segment markers occur in order;
- the exact internal-reference surface is restored: four `cref` and four `eqref` invocations in authority order;
- the source and target both contain no citation, figure, asset, footnote, or included-file surface;
- the source editorial verification request is exposed as one rendered self-study verification prompt;
- 166 authority and 241 target formula surfaces align into 32 explicit delta blocks, with manifest SHA-256 `886d80e0a759977c0c176d9b97e595b4c3515ecd52446a8c8b714146a9be3f4a`;
- all 47 required correction surfaces are present and bound to exact ledger events O015-HAB-ADV-0039 through O015-HAB-ADV-0049.

An independent complete review of the pre-fix target identified two P2 and one P3 findings. The frozen post-fix delta review of target SHA-256 `b1e27d912…` passes with P1=0, P2=0, P3=0. It confirms the lower-bound quantifier order and hypotheses, the complete scaled Schur–Jury minimax proof including the equal-curvature case, and the exact reference/topology closure. It separately confirmed the Gelfand/Jordan proof, spectral corollary, local heavy-ball analysis, and FISTA energy/rate argument.

## Computation QA

`python qa/validate_acceleration_unit.py` passes with Python 3.13.9, NumPy 2.4.4, and SciPy 1.17.1. The 33,735-byte validator has SHA-256 `12aa1feacc6230131ce9b82a769177449a8af7ed586ccbf56f0b7ce`; its 37,060-byte result has SHA-256 `135ded1ed0f4f3ca70616822d8856a85d3747458c9ca6e765dab72a11d3b88f0`.

- Gelfand witnesses cover defective Jordan, nonnormal diagonalizable, complex-pair, and nilpotent matrices; the nilpotent case reaches exact zero at power four without dividing by a zero spectral radius.
- Heavy-ball witnesses cover a general admissible case, the `beta=0` zero-root edge, and the minimax parameters. The optimal modal radius is `2/3`, with maximum modulus error `1.11e-16`.
- FISTA passes 518 deterministic fundamental-inequality checks with maximum violation zero. The Lyapunov-energy drift is `4.62e-11`, below the `2e-9` tolerance, and both corrected explicit rate bounds have zero violation.
- At 40 equal gradient/prox evaluations, the FISTA objective gap is `3.0715e-05`, versus `1.4867e-04` for proximal gradient. These are deterministic witnesses, not replacements for the analytic proofs.

## Visual, text, and accessibility QA

All 15 pages of the final post-localization PDF were rendered at 120 dpi and inspected in a five-row contact sheet; formula-heavy pages and the corrections appendix were inspected full size. No clipping, collision, blank page, broken glyph, or unreadable formula was found. A bounded English-residue scan is empty after localizing `Eq.` to `persamaan`.

The PDF is unencrypted, searchable, and declares `/Lang` as `id-ID`; all fonts are embedded and expose Unicode mappings. It is not tagged, so accessibility remains `pass_with_limitation`; independent Indonesian language review remains `not_recorded`.

The final log has no LaTeX error, undefined control sequence, unresolved reference or citation, or missing glyph. It retains two small mathematical overfull warnings (7.08 pt and 3.00 pt); both displays were inspected at full size and remain visibly within the page without clipping. Other warnings are inherited locale/class/toolchain fallbacks.

## Four-unit backend verification

`python qa/extend_backend_ch06.py` followed by `python qa/validate_backend.py` passes with zero errors across two final generation/validation cycles; the JSONL and CSV exports are byte-identical between cycles. The 40,091-byte Chapter 6 generator has SHA-256 `286a4fabd006e748c9681533338c172096c0f42252bb87836a2bf3b1cd77d6a7`; the 25,048-byte validator has SHA-256 `20c45a79ca698a45d640719da547fd27c045055665d4f4315f7e094e7e3574b5`.

The backend contains 449 records, adding 112 Chapter 6 records to the 337-record baseline. Its 39 stable translation segments are distributed 11/8/8/12 across Chapters 3/4/5/6. Entity counts are: 52 artifacts, 4 assets, 55 concepts, 49 corrections, 1 course, 2 editions, 19 learning surfaces, 1 program, 36 QA events, 126 relations, 1 resource, 16 rights records, 39 segments, 43 terms, and 5 units. All 337 pre-Chapter-6 records match a freshly regenerated Chapter 5 baseline except legitimate current control/artifact byte and hash refreshes. Independent Indonesian language review remains `not_recorded`; PDF accessibility remains `pass_with_limitation` for all admitted untagged readers. Final JSONL/CSV byte identities are refreshed once more after the control updates in this paragraph and are taken from the terminal validator output to avoid a self-referential prose hash loop.

---

# Habring Chapter 7 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 7 — Duality / Dualitas  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-07-dualitas-id.tex` — 8,615 bytes — SHA-256 `3b6e710e37c07cc9ec82ca919451c313c52fa762d58c7b01c6792a78a0098797`.
- Translated chapter: `source/id-ID/habring-07-dualitas-id.tex` — 35,428 bytes — SHA-256 `11e9ad614f7ac4e3107e78bc3bed03a6d4acfe22f2a65fca26433b0ae3209fd9`.
- Authority chapter: `authority/habring/source-v1/duality.tex` — 30,761 bytes — SHA-256 `0b112dee2582813cec5629c02df1dda329f690f944b60f4694b1c5762129bea9`.
- Integrated correction records: `O015-HAB-ADV-0050` through `O015-HAB-ADV-0075`; the exact 26-record proposal is 15,830 bytes with SHA-256 `57dbba9afdee2fc453dde9fbb97621c1a6897ff5377c1ec6a210827a8dce675d`.

The retained build used pdfTeX 1.40.29 / MiKTeX 26.5 with `latexmk` 4.88 and Biber, from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and output directed to `build/habring-unit-07-id`.

## Final artifact

- Build and output PDF: `output/pdf/D90-HAB-07-dualitas-id.pdf` — 445,733 bytes; 21 A4 pages; PDF 1.5; SHA-256 `c4354e1e1366bdb20cebb9c6eca26fba172d6d82a6ad22dd9e2e470da2baeb6e`.
- Final log: `build/habring-unit-07-id/D90-HAB-07-dualitas-id.log` — 105,821 bytes — SHA-256 `795b594b1c78e0a0769fe6b7f292fea0d6ddc81a054cad00a4d857da0cab217d`.
- Final text extraction: `qa/D90-HAB-07-dualitas-id.txt` — 53,128 bytes — SHA-256 `b473c80434a35ec607c6a9b9da3dcc31e3d5a3a233ae1f7da72293a87d65a544`.
- Two forced fixed-epoch final builds reproduced the PDF byte-for-byte.

## Structural and mathematical QA

`python qa/audit_duality_unit.py` passes twice deterministically with zero failures on the exact frozen target. The 36,689-byte script has SHA-256 `4e29ad8cc208ab35f35e8dfc2bb323343977e7badcaed7aa7d8cfa75392cf35b`; its 32,121-byte report has SHA-256 `fd909b00e4274a31c9e9c707cbb9039d5e03233876d0c0094c66c1049802307f`.

- all 148 ordered source environments are preserved;
- all eleven stable segment markers occur in source order;
- all 24 label occurrences are retained, with only the duplicated final source label remapped uniquely and its reference changed in lockstep;
- all 21 `eqref`, 3 `cref`, 1 `Cref`, 9 `ref`, 2 citations, 1 footnote, 9 items, and 5 learner prompts are preserved;
- the source and target have no figure, asset, or included-file surface;
- 254 source and 296 target formula surfaces align into 49 explicit delta blocks, with every one of the 43 substantive blocks bound to an integrated correction event;
- the 81,046-byte formula-delta manifest has SHA-256 `fe72e72d0223117a0b34727d235ced9b6bf2af17cf48154e6b670d2ce75d89fb`.

Independent full-target and final-delta rereviews pass with P1=0, P2=0, P3=0. They confirm the finite-dimensional Hilbert/Riesz convention, conjugacy and biconjugacy repairs, Fenchel--Rockafellar scope, Moreau scaling, primal--dual gap, PDHG update/ergodic proof, and ADMM typing, stationarity, residual, Lyapunov, and objective arguments.

## Computation QA

`python qa/validate_duality_unit.py` passes twice with byte-identical stdout and no stderr. The 45,213-byte validator has SHA-256 `127bed94abe4b506ebd999a46ea71b31457f2f4cc65c7fdd7cd4efcc60569c5b`; its exact 10,830-byte receipt has SHA-256 `9ceeadd90b4868f600241301813a8f24c1d1279690abc8cbf96baa3faf62f3c3`.

The suite checks Fenchel/subdifferential and scaled-Moreau identities; an independent SciPy Fenchel--Rockafellar witness; PDHG one-step inequalities, convergence, metric coefficients, averaging indices, and the zero-operator branch; and ADMM primal/dual residuals, Lyapunov descent, and objective convergence with negative controls. These deterministic witnesses support, but do not replace, the included analytic review.

## Visual, text, and accessibility QA

All 21 pages of the exact final PDF were rendered at 120 dpi and inspected in three contact sheets. Formula-heavy primal--dual/ADMM pages, the correction appendix, and the one repaired proof-heading/list transition were inspected at full size. No clipping, collision, blank page, broken glyph, or unreadable formula was found. The bounded English-residue scan is empty.

The PDF is unencrypted, searchable on every page, and declares `/Lang` as `id-ID`; every embedded font exposes a Unicode mapping. It is not tagged, so accessibility remains `pass_with_limitation`; independent Indonesian language review remains `not_recorded`.

## Toolchain and backend verification

The final log has no LaTeX error, undefined control sequence, unresolved reference or citation, missing glyph, overfull/underfull box, or rerun request. Remaining notices are inherited locale/class/toolchain fallbacks.

`python qa/extend_backend_ch07.py` followed by `python qa/validate_backend.py` passes across two deterministic generation/validation cycles. The five-unit backend has 50 stable translation segments distributed 11/8/8/12/11 across Chapters 3/4/5/6/7. Its exact current record count and JSONL/CSV byte identities are taken from the terminal validator output after all control-file updates, avoiding a self-referential artifact-hash loop. Pre-Chapter-7 semantic records remain unchanged except legitimate current artifact/control hash refreshes.

---

# Habring Chapter 8 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 8 — Stochastic Gradient Descent / Penurunan Gradien Stokastik  
Admission: PASS

## Build inputs and artifact

- Authority: `authority/habring/source-v1/stochastic.tex` — 4,665 bytes — SHA-256 `610d11b59d8dfabbbbe6fbc509a0f9ac1727540458c67f8cd3b7bab49566a07d`.
- Target: `source/id-ID/habring-08-penurunan-gradien-stokastik-id.tex` — 6,378 bytes — SHA-256 `f610aaec91aa9b76582f251458da65d25cc37a933a51da478cad13ee16e5a344`.
- Wrapper: `source/id-ID/D90-HAB-08-penurunan-gradien-stokastik-id.tex` — 5,129 bytes — SHA-256 `d00ea41830af388c227a1054025f049a9315da6f41675573965042d320eb7428`.
- Integrated corrections: `O015-HAB-ADV-0076` through `O015-HAB-ADV-0083`; exact eight-record proposal SHA-256 `a815d0211da31b21a25a3f9fd8a2c1ec5fcc7da5e7a62c980f75df40ae65d45d`.
- Build/output PDF: `output/pdf/D90-HAB-08-penurunan-gradien-stokastik-id.pdf` — 346,785 bytes; 8 A4 pages; SHA-256 `c1ed028667c5df3fd0a837807e2a17bf7a9e1fa3170938853c9a96b9670fa86a`.
- Final log: 98,530 bytes; SHA-256 `59609048d4930761a5de52f05aa65f80cf3da36dc7f64bd624c1ec539e64702c`.
- Final text extraction: `qa/D90-HAB-08-penurunan-gradien-stokastik-id.txt` — 13,751 bytes; SHA-256 `8556e8138248e163bff23d1778e1d2d782d7c0b3bfa6c1c4df5adaed439a05c6`.

Two full builds from `source/id-ID` with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, `latexmk`/pdfTeX, and Biber produced identical PDF bytes.

## Structural, mathematical, and computation QA

`python qa/audit_stochastic_unit.py` passes twice byte-identically with P1=0, P2=0, P3=0. The 29,112-byte script has SHA-256 `d6a201efc1489fd8220510408bb65cf3cb56d5603b130f46287c6ec8f5be905e`; its 12,202-byte report has SHA-256 `d44495208072e4555011dce4cf6155d434bc526574614d2683b8a97484f730dc`.

- all 24 ordered environments and all nonblank source lines are covered by three stable segments;
- the sole label/reference pair and no-citation/no-figure/no-footnote/no-exercise closure are exact;
- 38 source and 61 target formula surfaces align into seven substantive delta blocks, every one bound to the eight integrated correction events;
- the 24,702-byte formula-delta manifest has SHA-256 `2f9632d02071ded0c84d54ca17af019137cecfe18245d94a7e9243449c0e9fe9`.

The independent source/target review found no remaining target defect. It confirms the normalized finite-sum oracle, well-posed projected iteration, conditional filtration/oracle assumptions, exact second-moment identity, consistent best-iterate definition, restored factor, and sharp `S_K`/`Q_K` bound.

`python qa/validate_stochastic_unit.py` passes 24/24 gates twice with byte-identical output. The 18,417-byte validator has SHA-256 `ef05e828b83ab285e5ba090dc27753cd758d5c3e1697f9c138b57bf052a7006e`; its 21,107-byte receipt has SHA-256 `3b78aa1140a08cf811493f37496b10c2955f02bec570385dcde6480f37578f22`.

It verifies the normalized finite-sum mean and missing-`N` negative control; three exact conditional-oracle states and their variance decomposition; metric projection and the one-step recurrence; ten exact-enumeration best-iterate cases under two schedules; and the source's failing extra-`Q_K` asymptotics. The minimum theorem-bound margin is `1/8`. For `tau_k=(k+1)^(-1/5)` at `K=100000`, the correct `Q_K/S_K` term is approximately `0.1332502401`, while the erroneous `Q_K^2/S_K` term is approximately `221.9331877`.

## Visual, text, accessibility, and backend QA

All eight exact final pages were rendered and inspected in a contact sheet; theorem/proof and correction pages were inspected at full size. No clipping, collision, broken glyph, blank content page, or unreadable formula was found. The bounded English-residue scan is empty. The log has no TeX error, unresolved reference, missing glyph, box warning, or rerun request.

The PDF is unencrypted and searchable on every page, declares `/Lang` `id-ID`, and embeds all fonts with Unicode mappings. It remains untagged, so accessibility is `pass_with_limitation`; independent Indonesian language review remains `not_recorded`.

`python qa/extend_backend_ch08.py` followed by `python qa/validate_backend.py` passes across two deterministic generation/validation cycles. The six-unit backend has 53 stable translation segments distributed 11/8/8/12/11/3 across Chapters 3/4/5/6/7/8. Its exact current record count and JSONL/CSV byte identities are taken from the final validator output after all control updates, avoiding a self-referential artifact-hash loop. Pre-Chapter-8 semantic records remain unchanged except legitimate current artifact/control hash refreshes.

---

# Habring Chapter 9 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 9 — Excursion on Optimal Transport / Selingan tentang Transportasi Optimal  
Admission: PASS

## Build inputs and artifact

- Authority: `authority/habring/source-v1/optimal_transport.tex` — 15,378 bytes / 264 lines — SHA-256 `719df724b368126cc7540dffd461dc33aba7d5b5b6060132181086dfa17649ba`.
- Target: `source/id-ID/habring-09-transportasi-optimal-id.tex` — 21,252 bytes / 352 lines — SHA-256 `45c0eef50b535ffb8722ad74caf4df0bf014f5eebb43d13b24f00639018ca3bd`.
- Wrapper: `source/id-ID/D90-HAB-09-transportasi-optimal-id.tex` — 6,822 bytes / 87 lines — SHA-256 `1e308a2bed0d1a6f5cdcff09cce932674cf32842a135bc88a5a34bc96c483ff6`.
- Corrected unit-local bibliography: `source/id-ID/references-ot-id.bib` — 306 bytes / 9 lines — SHA-256 `93611c4b6a753478c51c601e59ef6cd3e290677e2e2d25b104d5d3b74df03126`.
- Integrated corrections: `O015-HAB-ADV-0084` through `O015-HAB-ADV-0096`; proposed content ledger SHA-256 `643fde3fbe1409732ef2df8fdef52465e4df7a583fd9bbeb2137a6122f548add`.
- Build/output PDF: `output/pdf/D90-HAB-09-transportasi-optimal-id.pdf` — 498,244 bytes / 15 A4 pages — SHA-256 `edc8e17fd43d17a0dd7811879dfbedaab9ac226c291ed5558ca0bfbb3ce10214`.
- Final log: 103,255 bytes — SHA-256 `2b083221c49f6fbdede8f541e68cd9129632a74168d7855c1ddc14c1bf48b3a4`.
- Final text extraction: 30,053 bytes — SHA-256 `283864c3fc84d414ff721f128a0f10e4b61b4646c0f5edcd53551ee13f911859`.

Two fixed-epoch builds from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and `latexmk -gg -pdf`, produced byte-identical PDF files.

## Admission result

The strict audit passes twice: all 47 ordered environments, five labels, native TikZ figure, citation/footnote/glossary surfaces, and every nonblank authority line are preserved in nine stable segments. Its report SHA-256 is `eb8b194c01dd7610dcdb7325322765ab16b3ec9cf907d28f9463fa11692767aa`; the 35-block / 34-substantive formula manifest SHA-256 is `796e13fbf1f221139f0233d30b2464dfb026027eb5b9ce44b66b58c2f2e169ef`. All substantive deltas bind to exact integrated corrections.

The open validator passes 41/41 gates twice. It checks a rectangular 3-by-4 OT primal/dual witness with objective 0.575 and zero gap, Wasserstein-2 squared distance 3, a positive entropic Sinkhorn plan in 27 iterations with maximum marginal residual `3.608224830031759e-15`, factorization/KKT/scaling/strict-convexity witnesses, and four negative controls. Receipt SHA-256: `4f751c615f2d7f03622b1447b3985ad1d660bd4f758cf4c4fb61d4d384b4e7a0`.

All 15 pages were rendered and inspected; formula-heavy pages and the correction appendix were inspected full size. No clipping, collision, blank content page, broken glyph, or unreadable formula remains. The final independent rereview is P1=0, P2=0, P3=0. The PDF is searchable, declares `/Lang` `id-ID`, embeds all fonts with Unicode mappings, and remains untagged. Semantic HTML/EPUB and independent human Indonesian review remain open. Full evidence is in `CHAPTER09_SOURCE_AUDIT.md` (SHA-256 `49f3d61892cf7587281fa3a95525b7f7ae1814223c38fe3de76efc02a193a85b`) and `qa/CHAPTER09_WORKLOG.md` (SHA-256 `0527b8b61dee2ffccd493e8331b7d57f592ba3ec9b5ef87226c15cb1a342e99e`).

`python qa/extend_backend_ch09.py` followed by `python qa/validate_backend.py` passes across two deterministic generation/validation cycles. The seven-unit backend contains 793 records and 62 stable translation segments distributed 11/8/8/12/11/3/9 across Chapters 3/4/5/6/7/8/9; final export identities are emitted by the validator after live control updates.

---

# Penn Chapter 3 build and QA record

As of: 2026-08-22  
Unit: Penn Chapter 3 — Introduction to Gradient Ascent and Line Search Methods / Pengantar Pendakian Gradien dan Metode Pencarian Garis  
Admission: PASS

## Build inputs and artifact

- Authority: `authority/penn-state/source/ClassNotes/Section3.tex` — 41,715 bytes / 608 lines — SHA-256 `d4ae6142e2366b12575eafddc833df067518af114e9816187668cc367be43010`.
- Target: `source/id-ID/penn-03-pendakian-gradien-dan-pencarian-garis-id.tex` — 44,364 bytes / 646 lines — SHA-256 `7c75d0ae56a5a912d561d91ece607f088a4ff4f3de4dbc3396ce40d6d7d6a229`.
- Wrapper: `source/id-ID/D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.tex` — 8,203 bytes / 192 lines — SHA-256 `0876d121d417ef4f73f308eac62056a55499628af44713e06246315852dcfa38`.
- Bundled-bibliography excerpt: `source/id-ID/references-penn-ch03-id.bbl` — 852 bytes / 25 lines — SHA-256 `d3e645c03298c14fee272d44b5d471a81d31aec60a95d4f568b4923edde63867`.
- Integrated corrections: `O015-PENN-ADV-0004` through `O015-PENN-ADV-0024`; proposal SHA-256 `80aa5a3f7b4f46c7dfe01f58f6f68555c9aeaeb91d0877eaf27cbb447c4a67fa`.
- Build/output PDF: `output/pdf/D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.pdf` — 515,851 bytes / 20 A4 pages — SHA-256 `e1be82d06572c51b403608cd9595cc5adf2dc64cfa93f53001eba94e48f77e3e`.
- Final log: 27,077 bytes / 697 lines — SHA-256 `2702aa4b756fec32557368a144ddfe9a91f32363e034cefea9956034178a74f6`.
- Final text extraction: 47,464 bytes / 828 lines — SHA-256 `9880848f06e2f1104a88213f3a9f7629db87c6cc8bf0b515281cf553ed1895bc`.

Two complete builds from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and `latexmk -gg -pdf`, produced byte-identical PDF files. The final log has no TeX error, undefined control sequence, unresolved reference/citation, missing glyph, overfull/underfull box, or rerun request. The only retained log notice is an OT1 bold-small-caps font substitution; direct inclusion of the frozen bibliography excerpt produces an expected terminal-only latexmk notice.

## Structural, mathematical, and computation QA

`python qa/audit_penn_ch03_unit.py` passes twice byte-identically. All 142 ordered environments, 35 labels, 37 unique reference targets, nine citations, four figure calls, twelve exercises, and all 608 authority lines in eight segments close exactly. The 499 source and 570 target math records align into 230 canonical-equal pairs and 89 delta blocks, with zero unbound blocks and zero unknown correction bindings. The report SHA-256 is `97af8d897decb2aac58355d97cf65898c1396e18c08deca5e1e8834a6b49d588`; the formula-manifest SHA-256 is `af04268dddc2cc3b74ccfe775967673bcfebab911d5d298c61df2a5a68ff653c`. Independent final rereview is P1=0, P2=0, P3=0.

`python qa/validate_penn_ch03_unit.py` passes 31/31 checks twice, including eleven negative controls. It validates bracketing, dichotomy, golden-section evaluation reuse/contraction/plateau failure, bisection, strong-concavity distance control, quartic extrema, Newton curvature/sign/failure cases, and exact local convergence-rate behavior. Result SHA-256: `dcf133cf7ca8aefebb3193711c8ceb1b719d9756b15778971572f1762e6b0565`.

## Visual, text, and accessibility QA

All 20 final pages were rendered at 120 dpi and inspected in a 4-by-5 contact sheet; the title/about/contents pages, Newton-rate page, bibliography, correction appendix, and attribution page were inspected full size. No blank page, clipping, collision, broken glyph, or unreadable formula remains. The title was reflowed manually to remove the non-content blank verso produced by the default book title machinery.

The PDF is A4/PDF 1.5, unencrypted, searchable on every page, declares `/Lang` `id-ID`, exposes six outlines, and has no form fields, widgets, or JavaScript. It is untagged. Nineteen reader fonts expose Unicode maps; eighteen embedded font resources inside the four inherited vector figures do not. Accessibility therefore passes with an explicit limitation; independent Indonesian language review remains unrecorded.

Full authority, rights, closure, and admission evidence is in `PENN_CH03_SOURCE_AUDIT.md`. Semantic HTML/EPUB, interactive computation, and the independent solution/mastery layer remain open.

`python qa/extend_backend_penn_ch03.py` followed by `python qa/validate_backend_penn_ch03.py` passes across two deterministic generation/validation cycles. The canonical backend now has 973 records and 70 stable translation segments. The Penn extension adds 180 records: 17 artifacts, four assets, 14 concepts, 21 corrections, two editions, 19 learning surfaces, 12 QA events, 59 relations, one resource, seven rights records, eight segments, 14 terms, and two units. JSONL: 718,846 bytes, SHA-256 `77fe247050077fda23c9a0bb2aa9c329f7c72d2e2e5f4b8890956b9df32343ec`; lossless CSV: 860,463 bytes, SHA-256 `5fe10a172f5abd9b847cf99c71620c02c460649d531537dbd61283a2c2d7f0cf`.

The 698-record Habring semantic baseline is unchanged at record-set SHA-256 `41fd7e0f51828f4c70f9f56a8ab424ad1ee944bb3f02ba5a654ff059bbeab878`. Ninety-four immutable baseline artifact records remain unchanged. The sole enumerated baseline refresh is `artifact.o015.adverse-ledger`, updated from the pre-admission 99-record ledger to the live 120-record identity; the refreshed 793-record baseline set has SHA-256 `7588bdc2e110564bd420e5bcf7bd1737b3f91dd50eabfa213eaa12fa757bfe4f`. Validation returns zero errors.

---

# Penn Chapter 4 build and QA record

As of: 2026-08-22  
Unit: Penn Chapter 4 — Approximate Line Search and Convergence of Gradient Ascent / Pencarian Garis Hampiran dan Konvergensi Pendakian Gradien  
Admission: PASS

## Build inputs and artifact

- Authority: `authority/penn-state/source/ClassNotes/Section4.tex` — 34,684 bytes / 469 lines — SHA-256 `76113034709b5914fa920076f2e882ccf30157e78ce5bdf4593a5d39af1886d5`.
- Target: `source/id-ID/penn-04-pencarian-garis-hampiran-dan-konvergensi-id.tex` — 33,313 bytes / 613 lines — SHA-256 `c5c0f09d38454177e61c2a97c9beef07771d5f4f715cc7a4a81a871ff54ced8f`.
- Wrapper: `source/id-ID/D90-PENN-04-pencarian-garis-hampiran-dan-konvergensi-id.tex` — 8,018 bytes / 187 lines — SHA-256 `b40ac7e4e1ee69afd0f7f82dbfc9042c6df79c1aaf2ccca78ec9e639b2030edc`.
- Bundled-bibliography excerpt: `source/id-ID/references-penn-ch04-id.bbl` — 625 bytes / 16 lines — SHA-256 `037e62878f1a562314a33054da8f4df4e49c029bbad31c2ec75066cd3e1a99f3`.
- Integrated corrections: `O015-PENN-ADV-0025` through `O015-PENN-ADV-0037`; proposal SHA-256 `fa9c5c0b097b7349a959ca6c1c9c797fc0ed2ea61e91148badec62bb239b7bbd`.
- Build/output PDF: `output/pdf/D90-PENN-04-pencarian-garis-hampiran-dan-konvergensi-id.pdf` — 847,350 bytes / 17 A4 pages — SHA-256 `c0f283aa7d70eba05de6a35c98bc0aa55f3177ab40702bf7eed5de45a7b6ab8a`.
- Final log: 27,564 bytes / 706 lines — SHA-256 `f247633a55e47a6fc002899bc9dbd24128f0949e39cc2954f78164411c301174`.
- Final text extraction: 26,421 bytes / 845 lines — SHA-256 `3ee30d8a4948910d40d8f61bec87a8e36e29f1934c6000dab1d9a8c96f5e518f`.

Two complete builds from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and `latexmk -gg -pdf`, produced byte-identical PDF files. The final log has no TeX error, undefined control sequence, unresolved reference/citation, missing glyph, overfull/underfull box, or rerun request. The only retained log notice is an OT1 bold-small-caps font substitution; direct inclusion of the frozen bibliography excerpt produces an expected terminal-only latexmk notice.

## Structural, mathematical, and computation QA

`python qa/audit_penn_ch04_candidate.py` passes twice byte-identically. All 112 ordered environments, 32 labels, 66 displayed-formula pairs, 52 source reference calls and complete target closure, four citations, five figure calls, four exercises, and all 469 authority lines in seven segments pass 22 fail-closed gates. Twenty-six determined formula pairs bind to all 13 corrections. The report SHA-256 is `c43e0195fc7da99590efd17b83ace3ca6a5721bc5156e86d2121a877b85e2c0a`; the formula-manifest SHA-256 is `fe7aa0bbd5cab4ff50cdf855a3bcf3c73f6ad0e007e2ce2033369cf54ed4a65e`. Independent final rereview found and fixed one P3 capture-theorem wording defect and finishes with P1=0, P2=0, P3=0.

`python qa/validate_penn_ch04_math.py` passes 12/12 checks twice. It validates ascent-form Wolfe signs and negative controls, finite Armijo backtracking, the failure recurrence, deterministic Kantorovich/exact-ascent witnesses, the corrected quadratic matrix/condition factor, and eventual unit-step/superlinear Newton behavior. Script SHA-256: `6f2ebf4a462043d327b5eb8c7e238808b6098aea2c193eab66cfa43794cd4bc4`; result SHA-256: `44c2b1a2509775e182e38b125f6c25ca49eb2f7e23e68ec2fce6878bf7704dd2`.

## Visual, text, and accessibility QA

All 17 final pages were rendered at 130 dpi and inspected in a four-column contact sheet; title, figure, algorithm, proof, correction, and rights pages were inspected full size. The source's two forced `[p]` algorithm floats initially created an otherwise mostly empty algorithm page; changing only their placement to `[htbp]` reflowed both boxes with their surrounding proof and example. The final reader has no blank page, clipping, collision, broken figure, or unreadable formula. Exact evidence is in `qa/PENN_CH04_VISUAL_QA.json`, SHA-256 `e700d08476f7aaa018ca31687d2eea2e8a50729599f760d300dd5b6f89211e70`.

The PDF is A4/PDF 1.5, unencrypted, searchable on all 17 pages, declares `/Lang` `id-ID`, exposes six outlines, and has no forms or JavaScript. It is untagged. Of 36 font resources, 26 expose Unicode maps and ten inherited vector-figure resources do not. Accessibility therefore passes with an explicit limitation; independent Indonesian language review remains unrecorded.

Full authority, rights, closure, and admission evidence is in `PENN_CH04_SOURCE_AUDIT.md`. Semantic HTML/EPUB, interactive computation, and the independent solution/mastery layer remain open.

## Backend admission

`python qa/extend_backend_penn_ch04.py` followed by `python qa/validate_backend_penn_ch04.py` passes across two byte-identical cycles. The nine-unit backend contains 1,128 records and 77 stable translation segments. Penn Chapter 4 adds 155 records and seven segments; its record-set SHA-256 is `b956955faee9f9f41b1212952d5c76c6d0eea2f30b33e4881198e48e8a409714`. The stabilized 973-record baseline has record-set SHA-256 `a53d556fe87bab226e120d7df3611b15e38cabb3defb19e850d481dd72058f9c`; its 861 semantic records remain `e20bb942a17185bfcabbc0e0377ce3608697530162664ebe06fba4400ec706a9`, and its 109 non-refreshed artifacts remain `0694bc4785d8712429c783002f0940d61c3832c32de8b8fc5fc436c128ca21e1`. Only `artifact.o015.adverse-ledger`, `artifact.o015.component-rights`, and `artifact.o015.coverage-overlap` are authorized live-binding refreshes.

Final JSONL: 829,770 bytes, SHA-256 `d378b1fcaf46fc83076a9961da16ff96d5f50e22912ede054be923a6bd389650`. Final lossless CSV: 994,096 bytes, SHA-256 `b36ecc26c8080786d6f0eacd3d3af7ffb6bbf81151400b561853751b72cc34df`. The 65,190-byte extension script has SHA-256 `f1e8f13c48bf5b76f0eb0212190ebe247a7ab40a11100dade9ba0fcacdc7ae14`; the 34,749-byte validator has SHA-256 `a56508efbd0b84f485b3fecaec77df41fb5410657a2c89bdf1a2676e4e79f15b`. Validation returns `errors=[]`.

---

# Penn Chapter 5 build and QA record

As of: 2026-08-22  
Unit: Penn Chapter 5 — Newton's Method and Corrections / Metode Newton dan Koreksinya  
Admission: PASS; optional Penn/Habring companion boundary frozen after this unit

## Build inputs and artifact

- Authority: `authority/penn-state/source/ClassNotes/Section5.tex` — 22,371 bytes / 317 lines — SHA-256 `15186b99be0913d83046e3e32eaf7a378d3a4fccd222219984b091ddf7f9a428`.
- Target: `source/id-ID/penn-05-metode-newton-dan-koreksi-id.tex` — 27,317 bytes / 400 lines — SHA-256 `0f6afd7da2268661124f967f299ac9df89bb6a8f5683b3e4e8fea32718a8549a`.
- Wrapper: `source/id-ID/D90-PENN-05-metode-newton-dan-koreksi-id.tex` — 7,230 bytes / 175 lines — SHA-256 `82450c4cdbe6de904c7cba1ee22922869f5d2e2caf19be69285092a5ea987e55`.
- Bibliography excerpt: `source/id-ID/references-penn-ch05-id.bbl` — 625 bytes / 16 lines — SHA-256 `037e62878f1a562314a33054da8f4df4e49c029bbad31c2ec75066cd3e1a99f3`.
- Integrated corrections: `O015-PENN-ADV-0038` through `O015-PENN-ADV-0049`; all twelve proposed records are byte-identically appended to the live adverse ledger.
- Final PDF: `output/pdf/D90-PENN-05-metode-newton-dan-koreksi-id.pdf` — 2,691,780 bytes / 15 A4 pages — SHA-256 `427db2c5a4428dfbe222d7e1d4f5c5349d4f78484a8593c412328fe94a7353c6`.
- Canonical log: 27,062 bytes / 700 lines — SHA-256 `bb3e9416233d14400ced235b69eeb95f76e6347dfeabbfd2c06727b543aed8be`.
- Extracted text: 29,195 bytes / 541 lines — SHA-256 `78fc7ecf877b7707c6c33736210449d502bbc148b84994b65b0d2fc4791365d3`.

Two complete fixed-epoch builds produced byte-identical PDFs. The canonical log contains no TeX error, undefined reference or citation, overfull box, missing glyph, or rerun request; one contained underfull caption warning is accepted.

## Structural, mathematical, computation, and rights QA

The final structural audit passes twice and preserves all 84 ordered environments, all ten labels, all five exercises, the sole citation, four figure calls, the exact 35 displayed-formula sequence, the complete reference closure, and every source line in seven gap-free segments. `qa/PENN_CH05_STRUCTURE_REPORT.json` is 26,392 bytes, SHA-256 `89757169df04a17c4e19bb72469aa6cd5ebb094e4c1298e3b8b78b44b3d9146a`.

The independent rereview raised and resolved one P2 and three P3 findings and closes at P1=0, P2=0, P3=0. Its 9,373-byte receipt has SHA-256 `239e4d79f90c570ac95ceb22cab097b41980c308abb39f940fe66dbc5f7861dd`.

The deterministic SymPy 1.13.1 validator passes all seven gates twice. It reconstructs the quartic Newton map, the double-peak stationary set and failed pure-Newton ascent direction, the corrected modified-Cholesky factor and solves, spectral bounds, and a local Q-quadratic witness. `qa/PENN_CH05_SOLVER_RESULTS.json` is 6,242 bytes, SHA-256 `9c5905c0022a1a99f8064484cff40abff0b9435df133822b5e16fc2b0ac6401f`. No excluded Maple code is executed.

The four Penn vector figures are retained byte-exactly. Five Maple/legacy listings remain excluded because their component rights are unclear/external; their reader roles are replaced by three independently authored, separately registered pseudocode surfaces. Penn-derived text/figures remain CC BY-NC-SA 3.0 US; original bridges are separately identified inside the combined NC-SA derivative.

## Visual and accessibility QA

All 15 pages were inspected in a contact sheet; pages 4, 5, 9, 10, 11, 12, and 14 were inspected at full size. No blank content page, clipping, collision, broken figure, unreadable glyph, or stranded algorithm page remains. The exact 2,687-byte visual receipt has SHA-256 `3130aee988a10cf4fc4c2b3cfbdc494293142519c0c416d603a109704188bde4`.

The PDF is A4/PDF 1.5, unencrypted, searchable on all 15 pages, declares `/Lang` `id-ID`, exposes six outlines, has no forms or JavaScript, and all 137 font resources expose Unicode maps. It remains untagged; semantic HTML/EPUB and independent human/native-speaker Indonesian review remain open.

## Backend admission

Root independently reran `python qa/extend_backend_penn_ch05.py` and `python qa/validate_backend_penn_ch05.py` after the producing agent's clean cycles, then repeated the transaction after the authorized architecture/rights/coverage refresh. The terminal two cycles are byte-identical and validation returns `errors=[]`.

The ten-unit companion backend contains 1,283 records and 84 stable segments. Chapter 5 adds 155 records in seven contiguous source/target mappings and has terminal record-set SHA-256 `979ec311c13ac368e7950bb734d4240310dec154d3e8151b042ed82333cb78c8`. The 1,128-record incoming baseline is unchanged after the three enumerated live-control refreshes and has record-set SHA-256 `23ffc42f0fa6b19a828154db74bdda2a0fa99e860f7615c918f4c7a3787f2edb`; its 999 semantic records have SHA-256 `971333c796eeb036b59cc1ff5ce6c0ce5bfa2836e5ab4d7f4176d4aeea0b5d97` and its 126 immutable artifact records have SHA-256 `68c89eb4dd196935f8b60d9f3eccc32a4ae61530503d189bb4ca3903bd9061c0`.

Final JSONL: 942,447 bytes, SHA-256 `e57a457d20edfcf772f38f7dd9dfdd3368530d785bbf5b71179b90784b8130f9`. Final lossless CSV: 1,129,757 bytes, SHA-256 `e2ca8f3b58dc74e208a579ff1b55997d0e5e202f49c2b018edce6358b7492c2f`. The 67,831-byte extension script has SHA-256 `d06a5149cdf6e08588cf20a586b7418e7244c189f2f4e8c06e8082cc75b1f1b9`; the 38,114-byte validator has SHA-256 `f89dfcb19a2febc15d44b75ed9894ed348861632db35b66a371843457e5e0ab6`.

---

# Habring Chapters 3--9 combined reader and resumable-source QA

As of: 2026-08-22  
Artifact: `output/pdf/D90-HAB-03-09-modul-pendamping-id.pdf`  
Disposition: PASS for reader-first public checkpoint; coherent partial companion module, not the complete D90 course

The deterministic builder `qa/build_habring_companion_reader.py` is 9,325 bytes, SHA-256 `288df54ace12fe45b7a3735b54f710878078fdbcbd5a293752520b780dc864de`. It combines a one-page Indonesian scope/rights/accessibility cover with the seven already admitted Habring Chapter 3--9 readers and removes ReportLab's unused default Helvetica selection without removing any painted text. Two final builds are byte-identical.

The combined reader is 3,090,098 bytes / 103 A4 pages, SHA-256 `6cd291cc447999b7cd72622e8c2003b837cf4f21ea5de0fcb7094913e20acd87`. It is unencrypted and searchable on all 103 pages, declares `/Lang id-ID`, exposes eight correct outline destinations, preserves all 127 source link annotations, and has no form or JavaScript. All 121 reachable painted font objects are embedded and expose Unicode maps. The 102 component pages preserve byte-identical decoded content streams and identical extracted text relative to their standalone readers. TeX math extraction retains inherited control/private-use delimiter glyphs; the merge introduced none. The PDF remains untagged and independent human/native-speaker Indonesian review remains unrecorded.

All 103 final pages were rendered at 80 dpi and inspected across five contact sheets; the cover was inspected full size. No blank page, clipping, collision, broken figure, malformed transition, or unreadable glyph was found.

The compact source release `release/figshare/2026-08-22-reader/D90-HAB-03-09-sumber-id.zip` is 160,908 bytes, SHA-256 `be06ba070d97506970378cea801c2525abc69bb305c3770b59186a6e212a645f`, with 29 unique entries. It includes all seven wrappers and chapter bodies, class, macros, both figures, complete bibliography closure, exact CC BY 4.0 legal code, Habring-only corrections/rights/source authority, pinned Python requirements, the combined-reader builder, and `BUILD_MODULE.ps1`. A fresh extraction built all seven standalone PDFs and the combined reader successfully; the clean combined output was byte-identical at SHA-256 `6cd291cc447999b7cd72622e8c2003b837cf4f21ea5de0fcb7094913e20acd87`. No Penn, Griffin, Maple, `.mpl`, Git, credential/token, cache, or temporary entry is present.

---

# MIT OCW 6.253 first-topic semantic-source build and QA

As of: 2026-08-23  
Unit: complete-notes pages 2--5 — The Role of Convexity in Optimization / Peran Kekonveksan dalam Optimisasi  
Admission: PASS

## Exact inputs and outputs

- Authority PDF: 8,030,116 bytes / 340 pages / SHA-256 `41afb47e0f6ce328298d386d16c15defa1d98c88802175a22ba80b619bd18181`.
- English semantic witness: `source/en/mit-01-role-of-convexity-semantic-witness.md`, 5,752 bytes, SHA-256 `a18aefa9e1ffa29d0a3cea21d0df34f05025cb7c2008ae57b5db44730c9d1f58`.
- Indonesian semantic source: `source/id-ID/mit-01-peran-kekonveksan-id.md`, 8,641 bytes, SHA-256 `2170dec12e707782c7677647f77ad8ee3360b282a8dbb9fb5620170106004bf3`.
- Semantic HTML: `output/html/D90-MIT-01-peran-kekonveksan-id.html`, 20,613 bytes, SHA-256 `fff4de952dd2cb208208e1cfb3bbc8fe8a64936ff5fdb532a23a92fb0dc6af8b`.
- Reflowed PDF: `output/pdf/D90-MIT-01-peran-kekonveksan-id.pdf`, 53,370 bytes / 3 A4 pages, SHA-256 `bd03912f9d3fe6dbe7376577c7ca6e7ab5aee007dd33b51669cde1792644df58`.

The exact source boundary is four PDF pages with 21 top-level items distributed 4/3/5/9, 12 nested bullets distributed 0/8/4/0, and two freestanding display formulas. There are no source figures, theorem statements, learner exercises, hints, answers, solutions, or interactivities in this block. Corrections `O015-MIT-SEM-0001`--`0003` disclose the discrete-dual scope, self-dual/involution meaning, and normalization of a source function-type arrow.

## Deterministic and semantic validation

`qa/build_mit_pilot.py`, 3,025 bytes, SHA-256 `b109c24f01feb1f57193a05b56ae662902078c5fd63f457084379f7db66dac74`, builds HTML5/MathML and LuaLaTeX output. Two clean bounded-output builds reproduce the admitted HTML/PDF hashes exactly. `qa/validate_mit_pilot.py`, 19,571 bytes, SHA-256 `16dacd29912fd8b749f8d6ae8d44b716f814111c0a40eed27799e64fe6bf1108`, reparses both semantic sources, verifies exact page/item anchors, recomputes list/math topology and all three corrections, rebuilds twice, rerenders the PDF, and checks document metadata/font maps. Its passing 4,167-byte report has SHA-256 `1e11642f8c1ab1ade013c4377f4dc0bc119ec0e89e6073eec787c7c341de0970`.

The actual HTML passes browser measurement at 1280-by-720 and 390-by-844 with zero horizontal or display-math overflow, one main landmark, semantic heading/TOC/skip-link structure, 14 MathML nodes including two displays, no images, no duplicate IDs, no unresolved fragments, and no console warning/error. `qa/MIT_L01_BROWSER_QA.json` is 1,757 bytes, SHA-256 `2d5c90b3343040c4ed3dfbdb3714737dfba8317d1781c1e5c27145f5afbbb76d`.

All three PDF pages were rendered at 160 dpi and inspected individually; there is no clipping, overlap, unreadable formula, broken heading, blank page, or stranded correction. The PDF is searchable, unencrypted, declares `/Lang id-ID`, and all six font resources expose ToUnicode maps. It is not tagged. Independent semantic/math rereview is P1=0/P2=0/P3=0 at `qa/MIT_L01_INDEPENDENT_REREVIEW.md`, 2,691 bytes, SHA-256 `8259c6631c1c8645684c75a0244feedfc7289023d13e909cfdc73941eed35e50`. Independent human/native-speaker Indonesian review remains unrecorded.

## Backend and next source boundary

`qa/extend_backend_mit_l01.py`, 62,794 bytes, SHA-256 `b206d3e64628ed8a98ba7a776bcc34c1d6bec19175ec59082950fe6d2e63cf79`, and `qa/validate_backend_mit_l01.py`, 39,185 bytes, SHA-256 `be59f34bc8aa083f31a7f2a62a72aa20ab264167f6288d03b04247c8ef54d19e`, add and validate 130 exact MIT/Royer/pilot records over the 1,300-record incoming baseline. The resulting backend contains 1,430 records; the added-ID set has SHA-256 `fa0e7d763e2c3eab68ac32fe935d777f3c688c5d59cc509d93416608726cfaf5`. JSONL is 1,036,556 bytes, SHA-256 `ebf44ca94323584e40b548ce36da560899e39a1e76ed2c993a0786b4ee7c4a2b`; lossless CSV is 1,244,072 bytes, SHA-256 `bc73abb3457cacc10423c1785a0db70a9007fdef8ac0a2be1de48d25d389fdf5`. Two terminal generation/validation cycles are byte-identical and return `errors=[]`.

The next coherent source-order block is complete-notes pages 6--13, from “Duality” through “Exceptional Behavior”; page 14 begins “Modern View of Convex Optimization.” Its exact topology and material Athena-figure risk are frozen in `MIT_L02_BOUNDARY_CENSUS.md`.

## Current descendant byte note

The historical ten-unit Zenodo release preserves the Penn Chapter 4 and 5
reader bytes recorded in its public receipt. The current working-tree
descendants include the later bounded terminology normalization and therefore
have distinct identities: Penn Chapter 4 is 847,337 bytes,
`18e7162f8d1e55a050ee96a6ba05a2ffaa0d5cb578f96e264152666a79dc83a8`; Penn
Chapter 5 is 2,691,773 bytes,
`dad34c7cb363197da1ae87117b22b2dde21d6d183997745cd3ffff62245c0b96`, with
wrapper SHA-256 `7de8bc61dc3f59999ac6414df90ef6925d5a7d4665f79d71998c8f0e45839c14`.
They are not substituted into the immutable historical release.

The preceding next-block note is historical now that the pages 6--13 boundary
has passed; the next executable source cursor is page 14.

# MIT OCW 6.253 pages 6--13 semantic-source build and QA

As of: 2026-08-23  
Unit: complete-notes pages 6--13 — Duality through Exceptional Behavior /
Dualitas sampai Perilaku Pengecualian  
Admission: PASS for this bounded semantic reader boundary; not a complete-course claim

## Exact inputs and outputs

- Authority PDF: `authority/mit-ocw-6.253/course-archive/static_resources/6c63c6219c60378bc27d5b4a9167f1bc_MIT6_253S12_lec_comp.pdf` — 8,030,116 bytes / 340 pages / SHA-256 `41afb47e0f6ce328298d386d16c15defa1d98c88802175a22ba80b619bd18181`.
- English semantic witness: `source/en/mit-02-duality-semantic-witness.md` — 11,539 bytes / SHA-256 `6fc62cd32c9231c7f4b254ee2f0c46dbe2d4f19bcb23b5523c0aaaedb4762dde`.
- Indonesian semantic source: `source/id-ID/mit-02-dualitas-dan-perilaku-pengecualian-id.md` — 12,895 bytes / SHA-256 `b3e26c12a934b023b7b7ad4933082e6b50d68cd09c948d079a6a01df6b478917`.
- HTML: `output/html/D90-MIT-02-dualitas-dan-perilaku-pengecualian-id.html` — 38,196 bytes / SHA-256 `d722e7bebc5b5f1c0a9d4c1980b747564897521ea7632be0ab0e3433b26ec007`.
- PDF: `output/pdf/D90-MIT-02-dualitas-dan-perilaku-pengecualian-id.pdf` — 67,749 bytes / 5 A4 pages / SHA-256 `06b9c6ce9eaac8f78149e7a881ebdff6ef5c8692d9040c5dec8929a2e646d89b`.
- Validation report: `qa/MIT_L02_VALIDATION.json` — 3,076 bytes / SHA-256 `59047c4b9185e56e9f68791a12c70099d3652e42ae04ca064d0ebeaf01e2fe95`.
- Browser receipt: `qa/MIT_L02_BROWSER_QA.json` — 2,004 bytes / SHA-256 `a8f1e3fab187a21a1eee0a4362add3855648ccd3d0f249ec08216936db6dd6d1`.
- Independent rereview: `qa/MIT_L02_INDEPENDENT_REREVIEW.md` — 2,850 bytes / SHA-256 `67e20f5dc42afadb52d8cf299b6a7a8891286d1aa70b9972a17c70b407ac4e2e`.

## Topology, rights, and gates

The source closure is exactly pages 6, 7, 8, 9, 10, 11, 12, and 13: 19
top-level items, 7 nested lists, 4 freestanding display formulas, 2 explicit
examples, 1 answered didactic prompt, 1 source-display, and 61 target MathML
nodes. Seven of eight pages contain Athena Scientific permission-gated
graphics. No source image byte, crop, or copied layout is redistributed; each
surface is an exact-locator semantic description retaining labels and
mathematical relationships. No exercises, hints, solutions, or interactive
surface exists in this source boundary, and none is invented in the target.

`qa/validate_mit_l02.py` reports `errors=[]` and `result=pass`; two deterministic
HTML/PDF rebuilds are byte-identical. Browser evidence at 1280x720 and 390x844
records zero horizontal overflow, duplicate IDs, bad overflow elements, or
console warnings/errors. The PDF is searchable, A4, unencrypted, declares
`/Lang id-ID`, and is explicitly untagged. The target carries the MIT CC
BY-NC-SA 4.0 attribution, change marking, NC/SA obligations, and
non-endorsement. No human/native-speaker Indonesian review is represented.

## Continuation

The preceding page-14 continuation wording is historical now that L03 is
admitted. The next source cursor is complete-notes page 15. The additive backend
extension is also admitted and idempotent:
it adds 65 records (8 segments) to the protected 1,430-record baseline, for
1,495 total records / 92 stable segments. `backend/records.jsonl` is 1,076,672
bytes, SHA-256 `61422fc3d0a1dfa3fed57f3710ae0ffbefb48b8b45957c25ed7455d3a9bd05e7`;
`backend/records.csv` is 1,293,072 bytes, SHA-256
`146f9a251bcd6b7c9938debc5e9b3f8d680cb51b6d6309bc9a85c90269d22f82`; the
65-ID set is `1436ab92aa0c80e1aedaf5ae1dce1b2ba28b31a9a88695d6f6d2803bc41789c4`.
The extension script is 27,926 bytes, SHA-256
`9c13a77eb1bd6a4d440bd4f765099201ccf1e1bba611423a9689853cac1d8368`; the
validator is 15,089 bytes, SHA-256
`5b0999b563b7dd3afa199bd8d89d391772b026035b836d448f2cef418576811a`, and its
passing receipt is 7,985 bytes, SHA-256
`6a325456a0591b6fe17704b7d0139247bbed8d1a622a18702f86048b45939005`.
Only these final frozen backend identities are controlling; earlier
intermediate L02 hash blocks (`b3f5...`, `2e2e...`, and related CSV/receipt
values) are superseded and noncanonical. The remaining full-course bridges, labs, mastery/solution layer, capstone,
semantic EPUB, tagged PDF, and human review remain open. Automatic Penn
expansion remains stopped; page 14 is the next executable source cursor.

# MIT OCW 6.253 page 14 semantic-source build and QA

As of: 2026-08-23  
Unit: complete-notes page 14 — Modern View of Convex Optimization /
Pandangan Modern tentang Optimisasi Konveks  
Admission: PASS for this bounded semantic reader boundary; not a complete-course claim

## Exact inputs and outputs

- Authority PDF: `authority/mit-ocw-6.253/course-archive/static_resources/6c63c6219c60378bc27d5b4a9167f1bc_MIT6_253S12_lec_comp.pdf` — 8,030,116 bytes / 340 pages / SHA-256 `41afb47e0f6ce328298d386d16c15defa1d98c88802175a22ba80b619bd18181`.
- English semantic witness: `source/en/mit-03-modern-view-semantic-witness.md` — 3,961 bytes / SHA-256 `ba74c799dfd1dfe87fc7be0695fd12d1780dadbff44d86f8ad6b7fc015171605`.
- Indonesian semantic source: `source/id-ID/mit-03-pandangan-modern-optimisasi-konveks-id.md` — 4,758 bytes / SHA-256 `24599f175ae5a40246d9677042a5c3d191802900562467d94eede8ef72837060`.
- HTML: `output/html/D90-MIT-03-pandangan-modern-optimisasi-konveks-id.html` — 9,762 bytes / SHA-256 `01785166246be0f1187353c64f228f341626951e7d20fef127a4b92ab7e96d90`.
- PDF: `output/pdf/D90-MIT-03-pandangan-modern-optimisasi-konveks-id.pdf` — 34,550 bytes / 2 A4 pages / SHA-256 `3cc20409b71331564cbc5429ce72cd27ebe3cbdb072910d2483e0bdeee54a136`.
- Validation: `qa/MIT_L03_VALIDATION.json` — 2,836 bytes / SHA-256 `fd92d811343e22192573293745c2f11175ba493f44bc5eb39801dfa6c47daff6`.
- Browser QA: `qa/MIT_L03_BROWSER_QA.json` — 1,396 bytes / SHA-256 `3455de5d1e4edfbc236d0684c252e254bb7a29a54f5519306e0c24c27ac6cb5e`.
- Independent rereview: `qa/MIT_L03_INDEPENDENT_REREVIEW.md` — 2,163 bytes / SHA-256 `daba4cbafe99d3fa47c8a9a9b9959ed8860b7bde442e5dc94a126171ca8227b1`.

## Topology, rights, and gates

The source closure is exactly complete-notes page 14: 2 top-level items, 6
nested bullets, 2 source-figure surfaces, zero display formulas, and zero image
bytes in the derivative. The two Athena Scientific permission-only graphics are
omitted as bytes, crops, and layout and replaced with exact-locator semantic
descriptions retaining labels and mathematical relationships. The target keeps
MIT CC BY-NC-SA 4.0 attribution, change marking, NC/SA obligations, and
non-endorsement. The source has no learner exercises, hints, solutions, code, or
interactive surface; none is invented or claimed.

`qa/MIT_L03_VALIDATION.json` reports `errors=[]` and `result=pass`; two
deterministic HTML/PDF rebuilds are byte-identical. Browser evidence at
1280x720 and 390x844 records no horizontal overflow, duplicate IDs, unresolved
fragments, images, or console warnings/errors. The PDF is searchable, A4,
unencrypted, declares `/Lang id-ID`, and is explicitly untagged. No
human/native-speaker Indonesian review is represented.

The current public preservation baseline is corrected Zenodo record
`10.5281/zenodo.22071030`; its sanitized readback is 9,338 bytes, SHA-256
`4d1ec4e50c2428a6c0cbad1e8e530892f1bc0b6c6eeb7da89b48e987932c6dbb`. That
record is the corrected L02 lineage and is not a claim that L03 files are
already public. The next source cursor is complete-notes page 15.

# MIT OCW 6.253 page 15 semantic-source build and QA

As of: 2026-08-23  
Unit: complete-notes page 15 — The Rise of the Algorithmic Era /
Kebangkitan Era Algoritmik  
Admission: PASS after live browser QA for this bounded semantic reader boundary; not a complete-course claim

## Exact inputs and outputs

- Authority PDF: `authority/mit-ocw-6.253/course-archive/static_resources/6c63c6219c60378bc27d5b4a9167f1bc_MIT6_253S12_lec_comp.pdf` — 8,030,116 bytes / 340 pages / SHA-256 `41afb47e0f6ce328298d386d16c15defa1d98c88802175a22ba80b619bd18181`.
- English semantic witness: `source/en/mit-04-rise-algorithmic-era-semantic-witness.md` — 3,225 bytes / SHA-256 `1c6afe0318471c2680291c2968a348ff84ad3dbeb702218d1496412b3871c5f8`.
- Indonesian semantic source: `source/id-ID/mit-04-kebangkitan-era-algoritmik-id.md` — 4,081 bytes / SHA-256 `98d4a0d31241e626e96b7929cb2cda135c8559d829326711f7dff436b8cdab0d`.
- HTML: `output/html/D90-MIT-04-kebangkitan-era-algoritmik-id.html` — 9,975 bytes / SHA-256 `c7ee3ace683dd854ce99259536b58bc802cb17fdd189a32b403f9e87521ea81e`.
- PDF: `output/pdf/D90-MIT-04-kebangkitan-era-algoritmik-id.pdf` — 36,971 bytes / 2 A4 pages / SHA-256 `9056c6ba9fa3996f907d1dfd6147ef219aa7c88941582c78d01977e60ce8ef5f`.
- Validation: `qa/MIT_L04_VALIDATION.json` — 3,400 bytes / SHA-256 `891dc5639a16099b81667fa2101df0992cf4d4c83654f44a2921ba12831717cd`.
- Builder: `qa/build_mit_l04.py` — 3,614 bytes / SHA-256 `733a186a8eb98bc418926ac2642b4e2b6093ef6432ba3471f4df9b9ffe00f9e7`.
- Validator: `qa/validate_mit_l04.py` — 18,735 bytes / SHA-256 `b2b5f289b35e4dadc2a49fb367b1373094789061aab31bf2b99056541052ab17`.
- Browser QA: `qa/MIT_L04_BROWSER_QA.json` — 1,125 bytes / SHA-256 `87a619e7df2a4226fe6f27307659b049e2176795b11488401dc05a6a34c86e56`.
- Visual QA: `qa/MIT_L04_VISUAL_QA.json` — 1,275 bytes / SHA-256 `6da40ec0179d47143a4f99bea9a8e3e899d776773de6580afb1417085e8ff1bf`.
- Independent rereview: `qa/MIT_L04_INDEPENDENT_REREVIEW.md` — 1,906 bytes / SHA-256 `39dc3005a3f16445eccdb73363719b3b03224efc573f7c8a45f9c73bc8a3b7d4`.

## Topology, rights, and gates

The source closure is exactly complete-notes page 15: 6 top-level items, 12
nested bullets, 1 inline math surface, zero display formulas, zero figures, and
zero image bytes. The MIT component remains CC BY-NC-SA 4.0 with attribution,
change marking, NC/SA obligations, and non-endorsement. The source has no
learner exercises, hints, solutions, code, or interactive surface, and none is
invented in the target.

`qa/MIT_L04_VALIDATION.json` reports `errors=[]` and `result=pass`; two
deterministic HTML/PDF rebuilds are byte-identical. Its live browser QA reports
`result=pass` at desktop 1280×720 and mobile 390×844, with no horizontal
overflow or console findings and zero duplicate IDs, unresolved fragments, or
images. The PDF is searchable, A4, unencrypted, declares `/Lang id-ID`, and is
explicitly untagged. No human/native-speaker Indonesian review is represented.

## Publication and continuation

Zenodo publication for L04 is pending after an HTTP 504; no L04 DOI or public
byte identity is claimed. The corrected L02 record remains the last verified
public checkpoint. The next source cursor is complete-notes page 16; automatic
Penn expansion remains stopped.

## 2026-08-23 final L04 gate refresh and consolidated continuation

The earlier `pass_with_limitation` browser wording in this L04 record is
superseded. Live browser QA now reports `result=pass` in
`qa/MIT_L04_BROWSER_QA.json` (1,125 bytes; SHA-256
`87a619e7df2a4226fe6f27307659b049e2176795b11488401dc05a6a34c86e56`).
At 1280×720 and 390×844 the DOM has no horizontal overflow, console findings,
duplicate IDs, unresolved fragments, or images. Final validation reports
`errors=[]`, `result=pass`: `qa/MIT_L04_VALIDATION.json` is 3,400 bytes,
SHA-256 `891dc5639a16099b81667fa2101df0992cf4d4c83654f44a2921ba12831717cd`;
`qa/validate_mit_l04.py` is 18,735 bytes, SHA-256
`b2b5f289b35e4dadc2a49fb367b1373094789061aab31bf2b99056541052ab17`.
The reader PDF remains untagged and human/native-speaker Indonesian review is
still unrecorded; those limitations are unchanged.

The additive L04 backend gate passes over the byte-preserved 1,495-record L02
baseline. It adds 48 records (17 artifacts, 1 learning surface, 14 QA events,
14 relations, 1 segment, and 1 unit), yielding 1,543 total. Exact frozen
identities are:

- `backend/records.jsonl`: 1,102,706 bytes; SHA-256 `92f6b805a83361f29a830b8c37b1c52f3468cb420d10b9a3a810cf0f8ac20645`.
- `backend/records.csv`: 1,325,476 bytes; SHA-256 `fedc1855df37e006e52ba76d99af2ee132accfa3b416519c39c036454f378a7d`.
- New-ID set: SHA-256 `8216b6f6713c519699e42923138a3f5e1f374000f3a494ececc646b9819dbb2d`.
- `qa/extend_backend_mit_l04.py`: 26,315 bytes; SHA-256 `19d315c38d77691b067050e6a09ffb411767008a41582b1674c90d37087f7272`.
- `qa/validate_backend_mit_l04.py`: 14,123 bytes; SHA-256 `d218daa09e803be9dd9c6401a5aace85f5340a88dbb7cf53b3563728bbb79c46`.
- `qa/MIT_L04_BACKEND_VALIDATION.json`: 7,178 bytes; SHA-256 `59277c7f61b350625d829b079b8800343489a97591c7f4cbf56d01e2c82c1204`; `result=pass`, `errors=[]`.

L03 publication is now verified at DOI `10.5281/zenodo.22071175`: 40 public
files (32 inherited plus 8 additions), a 484,193-byte delta ZIP SHA-256
`16116f249ffd4fc731a01de8f748b13c9e32c6734ca60c035098420e40b2909f`,
and an 11,373-byte anonymous readback SHA-256
`3d3a22a371eb267915f19773e8d4fc94b482840d808a46b0b376e98518ad8822`.
The L04 HTTP 504 attempt published nothing, so no standalone L04 release or DOI
is claimed or planned. Page 16 begins the next coherent multi-page source
section/batch; it receives one consolidated semantic, build, browser, visual,
backend, rights, and preservation gate at the batch boundary rather than a
page-level project/release cycle.

# MIT OCW 6.253 pages 16–19 semantic-source build and QA (L05)

As of: 2026-08-23
Unit: complete-notes pages 16–19 — closing course-orientation block
Admission: PASS; one coherent four-page boundary, not a complete-course claim

## Exact inputs, outputs, and QA evidence

- Authority PDF: `authority/mit-ocw-6.253/course-archive/static_resources/6c63c6219c60378bc27d5b4a9167f1bc_MIT6_253S12_lec_comp.pdf` — 8,030,116 bytes / 340 pages / SHA-256 `41afb47e0f6ce328298d386d16c15defa1d98c88802175a22ba80b619bd18181`.
- English semantic witness: `source/en/mit-05-course-orientation-semantic-witness.md` — 7,120 bytes / SHA-256 `3acbde47074da0429419e5c702785ee0490efa5e43f2b07cbac497f0d480492f`.
- Indonesian semantic source: `source/id-ID/mit-05-orientasi-kursus-id.md` — 8,702 bytes / SHA-256 `65cb7fec2d6b1aeda69837e10568f2410a9f4bded2b835b8dac59a9b516444cc`.
- HTML: `output/html/D90-MIT-05-orientasi-kursus-id.html` — 16,029 bytes / SHA-256 `424d854bb1e83e841a15d0073aad3db6bab0585ca6d587fd14a3b5cfb4274d83`.
- PDF: `output/pdf/D90-MIT-05-orientasi-kursus-id.pdf` — 46,785 bytes / 3 A4 pages / SHA-256 `2af9e4dc8e999969f03817350451c4b21f3c764564eee64327d15b48483313c0`.
- CSS: `source/id-ID/mit-l05.css` — 2,636 bytes / SHA-256 `d8d8417c4d2f9e01852cd30bc97552f377da3a6d1f9bbee25c25d47e16ce9645`.
- Validation: `qa/MIT_L05_VALIDATION.json` — 4,195 bytes / SHA-256 `2ef09a674c6bcc586cd13dd513a2f0f24aade6d10d2d11ccdfe317b7307dc3aa`.
- Live browser QA: `qa/MIT_L05_BROWSER_QA.json` — 1,271 bytes / SHA-256 `24b775fb6afc271a16a62097151175852a4a01eb1c41605a196258e19f01d342`.
- Visual QA: `qa/MIT_L05_VISUAL_QA.json` — 1,544 bytes / SHA-256 `d32b4e66cf7c1fd4f9fa06c75f88bfb80404caeefe894ba92396c548d126af04`.
- Independent rereview: `qa/MIT_L05_INDEPENDENT_REREVIEW.md` — 3,066 bytes / SHA-256 `c1c358c32f245ca4ef1c15efe3ed4d319f9bdef758319bce04f501bb525f7fb9`.
- Immutable correction snapshot: `00_control/MIT_L05_CORRECTION_SNAPSHOT.jsonl` — 642 bytes / SHA-256 `c701e631c4839aa07a2f8a4b8e8f026394c66bd709ffa37318431bbc461e1595`.

## Topology, rights, and reader gates

The boundary is exactly four source pages with four ordered source headings,
16 top-level items, 26 nested bullets, two unique live source URIs, zero
mathematical formula surfaces, zero figures, and zero image bytes. It contains
no table, worked example, exercise, hint, solution, code, or interactive
surface. MIT CC BY-NC-SA 4.0 attribution, change marking, NC/SA obligations,
and non-endorsement remain explicit. `O015-MIT-SEM-0004` is admitted as a
determined name correction: the witness preserves the printed “Vanderbergue,”
and the learner-facing target uses and discloses “Vandenberghe.”

Two deterministic builds are byte-identical. Validation reports `errors=[]`
and `result=pass`. Live browser QA at 1280×720 and 390×844 reports no horizontal
overflow or console findings, with zero duplicate IDs and unresolved
fragments. All three A4 PDF pages pass 160-dpi visual inspection without
clipping, overlap, missing glyphs, black boxes, or malformed lists. The PDF is
searchable, unencrypted, `/Lang id-ID`, and untagged. Independent rereview
closes P1=0/P2=0/P3=0; human/native-speaker Indonesian review is unrecorded.

## Backend and continuation gates

The final additive L05 backend has 1,605 records, adding 62 records to the
exactly reconstructed, byte-preserved 1,543-record L04 baseline. The protected
baseline is JSONL 1,102,706 bytes /
`92f6b805a83361f29a830b8c37b1c52f3468cb420d10b9a3a810cf0f8ac20645`
and CSV 1,325,476 bytes /
`fedc1855df37e006e52ba76d99af2ee132accfa3b416519c39c036454f378a7d`.
Final L05 identities are:

- `backend/records.jsonl`: 1,142,443 bytes; SHA-256 `30c6f3257d481136995acd7947a725da003c4ab2ea2e9049de53a23fa681658b`.
- `backend/records.csv`: 1,373,874 bytes; SHA-256 `f66227edc14e953b44d833b87b0373f76d87bf04fdd32d2f50552597915746e3`.
- `qa/extend_backend_mit_l05.py`: 35,174 bytes; SHA-256 `6a1b0c319e3a59820bcd18b257b9d160d0c39ae21f1dcf772df9bb8a61c7b36c`.
- `qa/validate_backend_mit_l05.py`: 27,004 bytes; SHA-256 `d4572ac9c0924459beebb225f8184b60b8e6a022fe1bdcccba2a6409a4f6fbab`.
- `qa/MIT_L05_BACKEND_VALIDATION.json`: 5,108 bytes; SHA-256 `7e653889523fdf6da918a0403e230b7f3a185107ed87ca22cc6936f37db57afc`; `result=pass`, `errors=[]`.

No standalone L04 Zenodo version exists. A combined L04+L05 Zenodo checkpoint
and the GitHub push containing L05 remain pending. The active production batch
is complete Lecture 2, pages 20–28: its 9,962-byte census has SHA-256
`fc0cb5b863652aa810ed765f247a248be1510cd61f240277b896e605a41b3ea4`.
Its witness and target are drafted but unadmitted, and build/QA is in progress.
Page 29 begins Lecture 3 and is the next-after-batch cursor.

## 2026-08-23 — Consolidated L04+L05 release gate

`release/zenodo/2026-08-23-mit-l04-l05/build_l04_l05.py` passed twice with
byte-identical outputs before publication. The frozen delta ZIP is 482,954
bytes / SHA-256
`96e323fb190462747a3e4b97c21211fc63f7e555ae029c7b683078ac28ac8c17`;
the archive reopens with 53 entries, all 52 manifest-bound payloads match, and
the forbidden-entry count is zero. Publication and credential-free readback
then passed for 50 public files (40 inherited unchanged, 10 additions). The
public bound manifest is 4,486 bytes / SHA-256
`437179a80f28091b0351172d8b56a0c46d945efe292da6e63c28b62b0da96b9a`;
the public checksum file is 5,039 bytes / SHA-256
`59c26562dd44d2ed4333ff21c674daccbea8077a0f8220a1c3564524ceba57cb`.
The public receipt is 14,060 bytes / SHA-256
`89266a7b3a332081aaef9d591eb1df449c6b0a1ab0a8526a1b91f27b8be01cd5`.

## 2026-08-23 — L05 GitHub public-byte gate

After pushing content commit `e18454bcb72251c3cc65a522046e6ed572792f7b`,
the anonymous commit API returned HTTP 200 with exact tree
`5a2841879dcc0122ad3e2243637cc5e257ee4a88`. Every one of the 42 paths
changed from parent `c944f218ec6d806bbc0dd12623275819bdb022a3` was then downloaded from
the immutable raw-commit surface; every response was HTTP 200 and matched the
corresponding Git blob byte-for-byte and by SHA-256. Receipt:
`release/github/2026-08-23-mit-l05/github-public-readback.json`, 10,947 bytes,
SHA-256 `1ecd35857a60b122d925b4ac53dca185cfae337b89f0552713167a8902595b7c`.

# MIT OCW 6.253 Lecture 2 pages 20–28 consolidated build and QA (L06)

As of: 2026-08-23  
Admission: PASS; complete Lecture 2, not a complete-course claim

Exact witness, target, HTML, and PDF identities are respectively 15,594 bytes /
`a8094ad892a90a20d271e961504fb418b1ea241859b072cf5ba56317783b809a`,
17,772 /
`a9e8b353adddc4919b6244e27df4365a33e74d4b034b9d99fff6eb3f93e0b23e`,
70,446 /
`94275af59592c64e7c8ae55fc384b721b2863a22ee328c33dc3b1d5a1e0af9a6`,
and 74,235 /
`84ce42542ed58e102c736dacc02b69cf16ab264a577d689d2fe5f7a24ba37d75`.
The boundary census is 9,962 bytes /
`fc0cb5b863652aa810ed765f247a248be1510cd61f240277b896e605a41b3ea4`.

The 6,086-byte fail-closed reader receipt has SHA-256
`6a8eab2cb69bf1403a8da3f9fbcc40f482c4b9a18e3ebbba24ac82ccee989257`
and reproduced unchanged after another full run. It verifies nine source
pages, 32 top-level items, 17 nested items, 12 display formulas, five semantic
figure descriptions, source-page 29 as the clean delimiter, exact rights and
correction bindings, two deterministic builds, searchable A4 PDF, and zero
copied image surfaces. Browser QA at desktop 1280×720 and mobile 390×844 has
no horizontal/formula overflow, duplicate IDs, unresolved fragments, or
console findings. Four-page 160-dpi visual inspection is clean. Rereview closes
P1=0/P2=0/P3=0. The PDF remains untagged; missing human review is recorded but
is not a gate.

The backend extension and independent validator pass two successive cycles
with identical output. They add 109 records with new-ID-set SHA-256
`756dced298991b810b3d153159379728f714beee2bbe188ab07c004bdbed7b82`,
yielding 1,714 records. JSONL is 1,231,983 bytes /
`9ad375756d2ee3159acf760f5d68084d2921e665cf993e2aaa6514f1e710337e`;
CSV is 1,480,312 bytes /
`f5c81e38ee9d1b4e9d2bcc7632603266fcf271b9b8c6454e99ba3e4b0041f72f`.
Generator, validator, and receipt identities are
`33fe4df3d268cf6a4e2656befe66d517e35634c6c1387244762da524df8c1df0`,
`565f600cc936ecbbf60eaa9a9d80ea535f5b4b49934418f8a22e0571af26f5b5`,
and `247fd848a4b4d0c3960ee82d48b7648304215ca69dddf1736305734106615c4c`.
The backend binds corrections through
`00_control/MIT_L06_CORRECTION_SNAPSHOT.jsonl` (1,406 bytes /
`4049f5ed333489bc0b8942e91ae3ab05f43677f13de1e532d544d7691724737f`)
so later append-only ledger growth cannot invalidate this unit.

Next: publish this admitted boundary once in the existing GitHub/Zenodo
lineages, then build Lecture 3 pages 29–38 as one consolidated L07 batch.

## 2026-08-24 — L06 publication and public-byte gates

GitHub content commit `283998197adeccbc1cf731f8cd4748295e5ba171` / tree
`c95e59cdce36c5942e8e1cf97c78a7c4f7bcc7bc` is public. The anonymous
commit API returned HTTP 200, and all 41 changed paths were downloaded from
the immutable raw-commit surface and matched local bytes and SHA-256 values.
Receipt: `release/github/2026-08-24-mit-l06/github-public-readback.json`,
10,580 bytes / SHA-256
`f0ca9b3edead3308793daf9f1b2f60dc1019def0cdf59e54f0e483d630db64e4`.

The repaired Zenodo release gate proved the exact latest parent, concept
lineage, PDF default preview, ambiguous-publish recovery path, 50 inherited
files, and 8 additions. The local package reproduced byte-identically twice
before mutation. Public record `22073743` / DOI `10.5281/zenodo.22073743`
then passed anonymous inventory and full-byte readback for all 58 files. The
523,322-byte delta ZIP remains
`2e8806904a65e3f09143c0f7a0b5371b009b7b54f50392d21079907261d15fd1`;
its 40 entries and 39 manifest-bound payloads pass with zero forbidden
entries. Public receipt: 16,084 bytes / SHA-256
`083df9f3bcef845e8eb55b6a99e8e51b6cd8d3294e9f5818e6abbf684f31986e`.

Next: close the existing L07 pages 29–38 reader/build/visual/browser gate,
admit it once into the stable backend, and advance to page 39.

# MIT OCW 6.253 Lecture 3 pages 29–38 consolidated build and QA (L07)

As of: 2026-08-24
Admission: PASS; complete Lecture 3, not a complete-course claim

The boundary census, witness, target, HTML, and PDF are respectively 11,013 /
13,879 / 16,518 / 77,399 / 75,885 bytes with SHA-256 values
`3c7400bdd092cffe358e852e5304091bfd53b10fb36d366f558e1b0f9c8bee2f`,
`ab9fb12728b53c0369094a347827aa40d74332b811976b8e0733caf245bce18b`,
`b1554fcb455bb43ecd72aa4c4e0f70d6d502c885009ba5e6a799e639e69441dd`,
`cc3b4f665d5f0b4cb9e26245ec0cce71658c6c0b3e5e07cee3fcabfb43df5e13`,
and `2c7b4defaa56578f628c048dc4f17ee06b61f2bc33122b172af5539a5dae2eec`.
The validator is 28,883 bytes /
`9dd39156c3591c0a771cc894ac5085fb5c787b5a472b722be24eb4d84c2d16ca`;
its rereview-bound receipt reproduced unchanged at 8,176 bytes /
`c076f79323c21186ceab5cbb56a128c71a31c67aa55b635f1eeebe313b4bd7e1`.

The gate verifies ten source pages, 16 top-level items, 14 nested items, 13
display formulas, four text-only figure blocks / six panels, and source page
39 as the clean Lecture 4 delimiter. Two deterministic HTML/PDF builds match
the canonical bytes. Desktop 1280×720 and mobile 390×844 have no horizontal
or formula overflow, duplicate IDs, unresolved fragments, or console
findings. All four PDF pages pass 160-dpi visual inspection. Independent
rereview is 4,136 bytes /
`d5f0bfc23b7a9b74d30570de9b2bd058c0ded84b51414b7b0b929349764ea86d`
and closes P1=0/P2=0/P3=0. The searchable A4 PDF is `/Lang id-ID` and untagged.

The immutable correction snapshot is 1,490 bytes /
`eba6c2039e1f893287921d72f5169e14861d95955acd7c6682e59cabcd030084`.
Two root-repeated backend generator/validator cycles are identical. They add
106 records with new-ID-set SHA-256
`a7ff4f1545568ab41e9e47fade09c80258750639781f5724d3e2a0792e7c2e66`
and yield 1,820 records. JSONL and CSV identities are 1,321,559 bytes /
`1f6384b25937765bdd32e9ae59d68ac11772c15ddd250861d7d051742ad43843`
and 1,586,211 /
`a6986c21e9757dd1750dd5e515e9038a973ecbeeae22db07d99ff81ea3f92985`.
Generator, validator, and passing receipt hashes are
`f2e6bdc042bfd1fe39e902aa4c413b6d421e7bf0ce491cf805dd4a709922c993`,
`7d9a47c70186e456b3281230223a89e1e8af9382509125e8de2d55af0386e867`,
and `37ddb31f13788e7e0ae6622304b38ec456693b78726bdf2625c5a7797be9d948`.
Next: preserve L07 once in the existing public lineages, then freeze the
coherent Lecture 4 batch beginning on page 39.

## 2026-08-24 — L07 local preservation package gate

`release/zenodo/2026-08-24-mit-l07/build_l07.py` was repeated twice after
backend admission and reproduced the same release bytes. The delta ZIP is
410,297 bytes / SHA-256
`767d3d21dd587f328c6c631ff9ba1febca6e3168474c2d264d90fa0b040bea40`;
it reopens with 27 unique entries, all 26 manifest-bound payloads pass exact
size/hash checks, and forbidden, credential-shaped, and mutable-global-control
entry counts are zero. The manifest and checksum file are 5,396 and 6,723
bytes / SHA-256
`3465065b4062a7cfe9361b4efc20f60930e2584c496bd8651f50365266a5139e`
and `de5ef346e2a00cdd6dd62b392af1e1e9010e458c8361e6037e990bf660ff8910`.
The intended public inventory is 58 inherited files plus eight additions,
with the L07 PDF as default preview. This is preparation evidence only until
the existing-lineage publication and anonymous readback close.

## 2026-08-24 — L07 public preservation and bound-manifest gate

GitHub content commit `c9cbd848a97b535049355d756de5e53d650fa25d` / tree
`4345de52cea5c3d5d0665484faff3b9ff8c84eef` passed anonymous immutable-patch
and exact-byte readback for all 40 changed paths. Receipt: 10,827 bytes /
SHA-256
`d3596d7f91afebced0fa1ba5ab85d99b09d10ba5549b57d7660bd41b9b98e0b5`.

The local release builder was extended fail-closed so draft creation binds the
manifest to record `22074102` / DOI `10.5281/zenodo.22074102` before upload.
The final bound manifest and checksum file supersede their pre-draft hashes:
5,423 bytes /
`743fec5b9dce1e7464af5c8d31c755e6cc04f37e1f0fdb91f827ca3feaddfe07`
and 6,723 bytes /
`9f0ca3ccf05b91917267fc54b35d0e4bc8aa3c3b2bbf7abeb2623283bf53ecaa`.
The ZIP remains 410,297 bytes /
`767d3d21dd587f328c6c631ff9ba1febca6e3168474c2d264d90fa0b040bea40`
and passes 27-entry / 26-bound-payload verification. All 66 public files—58
inherited and eight additions—passed anonymous byte/SHA-256 readback, with
the L07 PDF as default preview. The public receipt is 18,225 bytes /
`cc2681664e065d897e104218a086e9f113e8149ac474eedd026dcf51d28bfc81`.
No L07 preservation action remains; page 39 is next.

# MIT OCW 6.253 Lecture 4 pages 39–49 consolidated build and QA (L08)

As of: 2026-08-24
Admission: PASS; complete Lecture 4, not a complete-course claim

The boundary census, witness, target, HTML, and six-page PDF are respectively
11,700 / 22,457 / 24,496 / 113,898 / 91,293 bytes with SHA-256 values
`20ef255184a6e31476b368bd8b1ad08c39ea2ab9f6fdc1fa2c53574471a95055`,
`db45c443fb4e978b6bb4681a228a279f83048b8210530f77ed772a82c5f324a4`,
`b0c8b0418db9029441db23ad7deac1bed8a187ef9ae5ecd61ccfb56ce2a78758`,
`b084dd10113b55e7789885d0ec303376c0bca58fdbb960b428ce1feac9e30c0a`,
and `b01517ee401e0b9f069e4f121f57e1bc3a482b9ceb69cba067c4371f11a47e62`.
The validator is 33,409 bytes /
`48d83f7bb0b4cb115ea91ccc9e98daf5c88e86faaedc425adccfeea20ea040e0`;
its receipt reproduced unchanged at 10,509 bytes /
`da2448349a7075fe20008df94f2f3a45d472df5ab1d3631a43a3f12f6352c745`.

The gate proves pages 39-49, page 50 as the clean delimiter, 27 top-level
items, 16 nested items, 26 display formulas, and five semantic figure
descriptions. Corrections `0009`-`0011` are bound. Two deterministic builds
match canonical bytes. Desktop 1280×720 and mobile 390×844 have no horizontal
or formula overflow, duplicate IDs, broken fragments, or console findings.
All six A4 pages pass 160-dpi visual inspection. Independent rereview closes
P1=0/P2=0/P3=0. The PDF is searchable, `/Lang id-ID`, and untagged.

The immutable correction snapshot is 2,347 bytes /
`d99f8df4e722a9c98368bb169df17aa41d21754766b9ee19747a52569b40cb17`.
Two further root-repeated backend generator/validator cycles are identical.
They add 137 records with new-ID-set SHA-256
`407216b4f4337bb2c55716c81cad231ca596d65df250297fbaff57e1f295db59`
and yield 1,957 records. JSONL and CSV identities are 1,441,643 bytes /
`0779f8bc03d437da72adafe2daf99c820d5849f0e14b630a0c3bd6f512b10085`
and 1,727,978 /
`ed209ae9325d27b5e1360b59804833e91ab014c821741f2f52badfc5f0eda836`.
Generator, validator, and passing receipt hashes are
`6920fe6c673fddb80d018ea29814c26ed64741d0241a7ce73ea9580c760262d0`,
`9e884f1dcc4d71ff149468ffaa0804deb0b772ff93a923ad6468777b970e0be8`,
and `98a726263b5ec30a3fbadc6080afc38472338831f7a176aa0e81c1bad8635d4a`.
Preservation gate: PASS. GitHub commit
`024fd4eaf185b44250ab4ed41eb46afb660b4fbd` exposes all 42 changed paths with
exact anonymous byte identity; receipt is 11,195 bytes / SHA-256
`98396b8be5dc814443a47a4054e42f730b09bc3f9e0a1c384fca1f6771f32b40`.
Zenodo DOI `10.5281/zenodo.22074528` exposes 74 files, 66 inherited unchanged
and eight additions, all anonymously byte-matched. Its bound manifest and
checksum file are 5,431 / 7,581 bytes with SHA-256
`32b734818f143de77de420d985a0c4c6ac4f55a262b5330014be496e2fb84277`
and `68b62dd5c424a97ebed0268ab08c091be1d64acb1f063942c62e29d3c545b8b1`.
The 20,320-byte public receipt has SHA-256
`3c162ec07d5fd17accf417ec4659ef1b5849c8b83873ab93720fd9d8326fe9ea`.
Next: freeze and translate one coherent Lecture 5 batch from page 50.

# MIT OCW 6.253 Lecture 5 pages 50–63 consolidated build and QA (L09)

As of: 2026-08-24
Admission: PASS; complete Lecture 5, not a complete-course or public-preservation claim

The boundary census, witness, target, semantic HTML, and seven-page A4 PDF are
respectively 19,753 / 25,798 / 28,712 / 118,805 / 101,797 bytes with SHA-256
values
`e4357023e0c2a6d4478adb904e9fec2789bc616f56bfba07d05789f74cc0cd85`,
`5a262868b3d9091dd62123a2d1679e876f957cb640f104ad998a519214ced8ff`,
`a84e4173125a8f8606d14793bd5779efa82da1ae5a549e8a78422ac83af001d9`,
`1dcbb699a620a00c05e39ca6c28d6e40c408b1b70bdc2a4678d634654ed771c9`,
and `34b8b184a90a5da04ac421b6b8d73840cef4b43bb43a49b01fdc65c1b1e04721`.
The reader validator is 57,332 bytes /
`f9bd7204bd2a2eabe3b91dfe1d5c3e0a9c3021b39c3874bcde9d8a2db90cdd9b`;
its passing receipt is 21,488 bytes /
`d4659f5dbf81ec931eb665b71fadf0d46d0940952557f1147cacdcf63b7608b2`.

The gate proves complete-notes pages 50--63 and page 64 as the clean Lecture 6
delimiter. It binds 14 ordered pages, 41 top-level items, 17 nested items, 19
display surfaces, seven independently worded figure descriptions / 12 panels,
and two examples. There are no source exercises, hints, answers, solutions,
code, interactives, or admitted images. No Athena Scientific image byte, crop,
or layout is copied. The immutable eight-event correction snapshot for
`O015-MIT-SEM-0012`--`0019` is 5,506 bytes /
`e5ef98e4218d768cd51053e08d55c5ef44a44afa26237be652152eecd1052acc`.

Deterministic validation reproduces the canonical reader bytes and closes with
no errors. Desktop 1280×720 and mobile 390×844 have no page or formula
overflow, duplicate IDs, unresolved fragments, or console findings. The
browser receipt is 1,903 bytes /
`e7b4c8984efa9ab560894d61b3b9d54db11549cfb7bd42f99e9c105e4cd93619`.
All seven PDF pages pass 160-dpi visual inspection; its 2,281-byte receipt has
SHA-256
`f113bdd70a3ef20907d7a50c9832cacd26d68fbe532593357d1e84cd61c4048b`.
Independent rereview closes P1=0/P2=0/P3=0 in a 2,860-byte receipt with
SHA-256
`95f21db8e7657ceac3b3c992214cc754bdcfda3b4a71446e868e2b51f990fe4c`.
The PDF is searchable, A4, unencrypted, declares `/Lang id-ID`, and remains
untagged. Unrecorded human review is disclosed evidence, not a gate.

The additive backend preserves the exact 1,957-record L08 baseline and adds
142 records, yielding 2,099. JSONL is 1,577,079 bytes / SHA-256
`b483dfba003cd9fb422055c7836f62dd326575afcfc9b3c0a9a54aa6e1ad7ef8`;
CSV is 1,886,451 bytes /
`297629b3d20bd51bafd50cd5ecd0de70bd397b603a572e45083ca61b247f2574`.
The generator, validator, and passing receipt are 59,113 / 39,600 / 7,456
bytes with SHA-256
`bbe16a599e71aada89c9ab48e963b2a306d51e6fed6b8a906c78e8b7f61b7203`,
`e7d290e4061f8a5e64a09ad3b892e84d4110367c79385fe151d9c6f7f8e6e7d8`,
and `57415a985dc106a29812595ae081418cde80e99be186be04dd60db3eecc298c7`.
Repeated generation/validation is idempotent and never renumbers the protected
baseline.

Preservation gate: PASS. GitHub content commit
`06247a233dc9c9de85fc2a9ea1ff305e3907a1b7` / tree
`5b0082178eb0adef5f945bd603d98cacfcbeea85` exposes all 50 changed paths with
exact anonymous byte identity; its 13,044-byte receipt has SHA-256
`018357e9643a608bdb9b7b5386c58765af87829ce6200a5701e8d2471abf62a1`.
Zenodo DOI `10.5281/zenodo.22076259` exposes 82 files, 74 inherited unchanged
and eight L09 additions, all anonymously byte-matched. Its bound manifest and
checksum file are 7,062 / 8,399 bytes with SHA-256
`0dba56a45bf4dbea33f3a9295f870bc3eeb9d35303e9bb36fbc1bd14f2a159d8`
and `935849dad70bbaaefc807e242b6521012d742de3e50e4b0923b886d715ac82d6`.
The 22,376-byte public receipt has SHA-256
`aaf48c68d4935edf036c97c1ffc470fff7d12609c18c1049def3f8d689e14360`.
Next: freeze and translate one coherent Lecture 6 batch from page 64.

# MIT OCW 6.253 Lecture 6 pages 64–85 consolidated build and QA (L10)

As of: 2026-08-24  
Admission: PASS; complete Lecture 6, not a complete-course or public-preservation claim

The boundary census is 17,483 bytes / SHA-256
`ab8c8ce397df3b57f1ae426687fba2b14d51313c7a6b4596369eae07116fb13e`.
The English semantic witness, Indonesian target, reflowable HTML, and ten-page
A4 PDF are 43,575 / 45,994 / 169,871 / 133,787 bytes with SHA-256
`0dfe2c694fad607cef6c37ea7e84a0da359cedee6dc0bf023010f9c8a647c455`,
`be2dd29422f5e14ce26315258e772143335475cc2ee9c0d6bfc25f2ff05c8a53`,
`2c3e0e72e535b181880b4e52cbc112c7d2fc393b8f5636e091ff517ed76f2038`,
and `3b01d57e8e8a7d7887f36cfdc205d1b68d1d007a152bd8e0cd75479628e1abc0`.

The strict reader validator and passing receipt are 47,560 / 22,193 bytes with
SHA-256
`9b6f96dbdea58ab61ddaff92ccdf924e4cc80e92b21f6ca0ed13e08d03095328`
and `f700ad7d811e7c244285533deef8a492783918b7d6c0f7943f922a09edd77640`.
Root repeated the complete validator after the independent run; each run makes
two byte-identical HTML/PDF builds. The gate binds pages 64–85 and page 86 as
the `LECTURE 7` delimiter, 70 top-level items, 41 stable display blocks, 16
independently worded figure descriptions / 24 panels, and 394 MathML nodes.
There are no source exercises, hints, answers, solutions, code, interactive
surfaces, copied images, media, or forms.

Corrections `O015-MIT-SEM-0020`–`0030` are frozen in the 7,453-byte snapshot,
SHA-256
`72a8a2da79ea31e2587e42e5e6f54ec4662a749717d5c9c6119c707beef094ee`.
They include explicit repairs to nonnested neighborhood radii, the part-(b)
proof scope, an unbound projection variable, and a reversed set-difference
label; the English witness preserves the printed source state.

Live browser QA passes at 1280×800 and 390×844 with all 41 display blocks,
zero page-width overflow, duplicate IDs, broken fragments, or console entries.
Its 1,445-byte receipt has SHA-256
`ab8524f5097ee52c2a802212f4aabedadfb437afeadd5020659f1ab8a882ebbb`.
The two widest mobile formulas remain inside explicit horizontal-scroll
containers. All ten PDF pages pass 160-dpi inspection; the 1,298-byte visual
receipt has SHA-256
`17b24989fe86dbf34b5db47240d601606425500905cb3611b535d6ed5d50532d`.
The PDF is searchable, A4, unencrypted, and uses embedded Unicode fonts; it
remains untagged. The independent rereview closes P1=P2=P3=0 at 8,023 bytes /
`6d450dde5c3a0bdaa2404abc576a4b43b5d774a1d7b5a44fc7856c3e6097fa63`.

The additive backend preserves the exact 2,099-record L09 baseline and adds
225 records, yielding 2,324. JSONL is 1,797,378 bytes / SHA-256
`d8694c14afa0933132504c32ea6e2e5862606f913d4b6626bffd35b2bfbee75c`;
CSV is 2,144,290 bytes /
`fb9c84063bf976ddf5e2e15f435617c1cca346eebfd08051d9927a34ffcba367`.
The generator, validator, and deterministic passing receipt are 58,954 /
24,177 / 3,911 bytes with SHA-256
`29dde5ef886914d57b5c5f1e32228371d6ce95101b351cd5a83a9d328dac6af3`,
`736e1084a26fd23f2ec6fd1628ec1f1c94be76f4b34c44d62368a6bf3cd1cb5b`,
and `0ab18adef83d7e8cc8899ce3100a8003671f48c180447c4334e6ee6dce5c15dd`.
Two canonical validator runs agree; stripping the L10 workflow recovers the
prior JSONL/CSV records and order exactly. The schema is unchanged and
`relation.mit.l09-precedes-l10` links the units.

Preservation gate: PASS. GitHub content commit
`2f39b8146db59eb89243ec15cd0c430c1cdda0cf` / tree
`178cdd4e6b8d90720cb43b9d8c7268fab10e1a12` exposes all 43 changed paths with
exact anonymous byte identity; its 11,449-byte receipt has SHA-256
`750b97f06f85f0aa6cba9a6cd9082e1f13e1fc374b84f14ab80c2a80aeb0fd7b`.
Zenodo DOI `10.5281/zenodo.22077419` exposes 90 files, 82 inherited unchanged
and eight L10 additions, all anonymously byte-matched. Its public bound
manifest and checksum file are 7,245 / 9,243 bytes with SHA-256
`6a62b171368591390bb7ac2dbbfa3e367196dfe26c66913367928ef81dfe5f69`
and `5e8b9f7f3f89ae1c9288060d97aae7a8f10df6694a26b6af3dd83137ecfb0998`.
The 24,582-byte public receipt has SHA-256
`e2502d2192a803fbd22f4ac2017772d6de37208b5d261568c89a30f073bb260e`.
Next: freeze and translate one coherent Lecture 7 batch from page 86.

# MIT OCW 6.253 Lecture 7 pages 86–97 consolidated build and QA (L11)

As of: 2026-08-24
Admission: PASS; complete Lecture 7, not a complete-course or public-preservation claim

The boundary census and immutable correction snapshot are 5,840 / 15,532
bytes with SHA-256
`6586e3feb4463da884027c778a70c0f066b48d2948c38d1ba9a80ebde98c6f6a`
and `8acc411765e4d5e29f9e89447c26f2b37f00110d43ac2b0043c0762ed070a016`.
The English semantic witness, Indonesian target, reflowable HTML, and six-page
A4 PDF are 23,801 / 25,023 / 96,216 / 89,771 bytes with SHA-256
`625efb8801d24c270d2bf851bf1c7fb27cb307146742d7cbddc00b5cb5873c8c`,
`f908901609e1a1e6091734b55ba63b980f491dd5a5e4e813621816cbceb1c32b`,
`19dd1f9aeb65e951089a4501fefa65761448f86f21ee7024ccfde9a71e5b988d`,
and `82d39fa34f8e743204ba88b3b91f50d4a549bb7b0b79e529ed0bec1a51f16bc8`.

The gate binds 12 source pages, 36 semantic items, eight nested items, 21
display blocks, seven independently worded figure descriptions / 16 panels,
three worked examples, and one counterexample. It also binds page 98 as the
excluded `LECTURE 8 - LECTURE OUTLINE` delimiter. There are no exercises,
hints, answers, solutions, code, interactive surfaces, or copied Athena image
bytes/layouts.

Corrections are frozen in exact source-page order as `O015-MIT-SEM-0034`,
`0035`, `0036`, `0037`, `0040`, `0031`, `0038`, `0039`, `0032`, and
`0033`. The 43,578-byte strict reader validator has SHA-256
`6935a6b6cfe99b8f65e576d201a042a5df1ca2f619f52095e8a9d27a709fbd3f`;
its 12,136-byte passing receipt has SHA-256
`c70e7c16984d02e50c5e40a6ba7833bcff622c271b486db8c0eee358b71a2d0d`.
Two deterministic rebuilds reproduce the canonical HTML and PDF byte for
byte, and strict-final validation closes with `errors=[]` and
`release_ready=true`.

Live browser QA passes at 1280×720 and 390×844 with no page-width overflow,
duplicate IDs, unresolved fragments, wide mobile math, or console findings;
its 1,465-byte receipt has SHA-256
`03a7d0caf238595fae71facd891098213328744e172b58ee0c2359530400eeaf`.
All six PDF pages pass 160-dpi inspection with no clipping, overlap,
truncation, broken glyphs, orphaned outline items, or split conclusions; its
2,590-byte receipt has SHA-256
`8878aca621d4428e1053420a5f5f1252043b18c9c0cca39862e5f4328aac57ed`.
The PDF is searchable, A4, unencrypted, declares `/Lang id-ID`, and remains
untagged. Independent rereview closes P1=P2=P3=0 in a 7,395-byte receipt with
SHA-256
`5c58bd030b99fd488fdd49082cf92e1714f0e36a09d39da3b625f7a16e028ff8`.

The additive backend preserves the exact 2,324-record L10 baseline and adds
148 records, yielding 2,472. JSONL is 1,942,530 bytes / SHA-256
`b6a49365c69c6ce3d524fe658e16763a036661daf46d0dc8e8182bfff5e58a78`;
CSV is 2,313,694 bytes /
`8bbcb8d978d90073462fb966ab368b59cf226c794cf338060706dfccbee9ea66`.
The generator, validator, and deterministic passing receipt are 61,263 /
27,437 / 3,968 bytes with SHA-256
`48ac891056bcfd49f1b17ba59053d6c89a03f5efa85578d0dd59f59942e66f0d`,
`dc4479cc79161ab256491399627330fb3df71ba142647e7c4166b730edc96c1d`,
and `1d7d27001595d1312600fe39ebc980ec5b473699d466caf28920eb286db5449f`.
Two regeneration/validation cycles agree; stripping the L11 workflow recovers
the prior records and order exactly, and the schema is unchanged.

Preservation gate: PENDING. Preserve L11 once in the existing GitHub and
Zenodo lineages and anonymously verify every new public byte. Do not claim an
L11 public identity until that transaction succeeds; page 98 is next only
after preservation closes.

Architecture supersession: after the pending L11 preservation gate, the next
build lane is the Habring structured-source spine. Page 98 is retained only as
the MIT-companion cursor; no Becker file or build is admitted until its exact
nonduplicative subset, `../preamble.tex` repair, and deterministic build pass.

## L11 public preservation gate

Preservation gate: PASS. GitHub content commit
`c51e1131c34e6e937197ee118b072269a5a4af23`, tree
`464b8bad46b862842f8970df290d8ba4fbc0efba`, parent
`11b3f779456bda9951e22910775aee05a830cb1f`, and all 50 changed paths passed
immutable anonymous exact-byte/SHA-256 readback. Its 13,135-byte sanitized
receipt has SHA-256
`33385fc3b94844c2df8e2ac1314366280dded69eff3ed28d597b9548ae0c5dff`.

Zenodo record `22086656`, DOI `10.5281/zenodo.22086656`, is published in the
existing concept `10.5281/zenodo.22059741` after parent `22077419`. All 98
files passed anonymous byte verification: 90 inherited unchanged and eight
L11 additions; the L11 PDF is the default preview. The public manifest,
checksum file, delta ZIP, and sanitized receipt are respectively 7,254 /
10,071 / 558,826 / 26,639 bytes with SHA-256
`214e90b6aa7f63e59feeac1ded513df6d6b0df32e7f3b728a95eb2defc08b728`,
`bdf0171a198d201e3e267ca5732ed78e1a9463d8ac433ddd84c67a0490253f31`,
`dfa5691563029b510451c1d5296364a5aec824bc76b32b54502d0b149260b133`,
and `008175e80a2e13dbf4ce3af14a1428177d3b78d3469512fd04d1f365e692c101`.
No upstream contact occurred. The next build lane is Habring v1; MIT page 98
is dormant.

# Habring v1 preface and Chapters 1–2 consolidated admission; full-spine readers

As of: 2026-08-25
Admission: PASS; Habring v1 Chapters 1–9 complete, larger O015 coursebook partial

The exact authority inputs `preface.tex`, `preliminaries.tex`, and
`convexity.tex` are 492 / 26,946 / 29,947 bytes with SHA-256
`d6ec9d0522446fc65f3868d0b7cd1d221462c3099fbd0b2d6ea412ab53315967`,
`8c1e4bdad36f2dcb57867c475afa5adce12a3951fc650e8667f2e4d82d3b569d`,
and `e5cf93ad93cb2064bdff6c1ea200f20b4eb94351127185a01d678c3fb5a662b8`.
The localized Chapter 1 and Chapter 2 sources are 31,009 / 42,828 bytes with
SHA-256 `6ed957c8bf654608e8d572b2f0368478a4dc185ba51c150ea9dee36bb62868e7`
and `99a992f36756cb64f82d21cfcaf68fdaee8b8dd61ef2b007322d9d2623989f22`.

The independent structural audit passes twice with byte-identical receipt:
`qa/HABRING_CH01_CH02_STRUCTURE_REPORT.json`, 46,054 bytes /
`cc7d31e36b7f04e9fcb14692b53ce460be58958e3c0bb66b44af85e6282451bc`.
It verifies 244 / 280 ordered environment tokens, 32 / 52 items, exact label
and reference closure, one plus seven figures, all five inherited raster bytes,
25 stable segments, all 65 correction bindings, all 38 Chapter-2 correction
markers, and zero unaccounted display-formula deltas. The event interval
`0097`–`0161` contains 65 events; the earlier count of 61 is rejected.

The 36-page A4 unit PDF is 720,624 bytes /
`5fc51737b0ec2d2342e93c0a53a997cd1f81a3df2d15415ef5fdd9c2c4a9dbdf`;
two builds are byte-identical and the final TeX log has no error, undefined
reference, or overfull box. The open-math receipt is 6,909 bytes /
`3debf7f8875c1dc5ce89f8c163f0cd349edb62849e861719aa80bd6931009587`;
all 32 gates and nine adverse controls pass.

The complete nine-chapter reader PDF is 3,779,312 bytes / 139 A4 pages /
`da2b421b97efce4e3d7b8cf6be9938d17b7768b9c6bcb4846b09b9c692b34c41`.
All 139 pages and all 36 unit pages passed rendered visual inspection. The PDF
navigation gate resolves all 287 / 482 named destinations, 29 / 156 links,
and seven / nine outlines with no invalid annotation rectangle; receipt:
1,687 bytes / `eded727695f3d632920e408b4c7e5e13184ae11ca34631e9b7921c09a6ce97cc`.
The visual receipt is 2,571 bytes /
`7aed39e74194591d51fcb168cdfff26a9bfb330a35fc56a7d7302fbd2de7ddbe`.
After the rights-label correction, unit page 36 and its identical full-reader
page 37 were rerendered at 160 dpi and visually reinspected without defects.

The complete HTML is 1,669,938 bytes /
`717ee81912a8b903acc87e5c59d830aa1d8c78abdda6e0c869d66b9a7bcde3a4`.
After the first 390×844 test exposed 214 CSS pixels of page overflow, the
builder confined long inline formulas to their own scroll surfaces. The final
1280×720 and 390×844 runs have zero page overflow, duplicate IDs, broken
fragments, broken/missing-alt/external images, unscrollable math, or browser
diagnostics; all 414 display formulas render. Browser receipt: 2,415 bytes /
`cbd89cf154c9b044d3792b6888dcc7635e082b912572b1ecc85ae3a13a308701`.

The EPUB 3 is 231,700 bytes /
`c630e25db3cbbfa6f6afa7213e526c47586b6e7b44f709095ea5a3881756fd41`.
Two normalized builds are byte-identical; 71 source labels, 2,206 MathML
surfaces, internal navigation, five raster alternatives, six TikZ semantic
fallbacks, XML/resource closure, language, license, and model provenance pass.
Receipt: 4,247 bytes /
`824f0bf53305f68d2ac46ecee04a03151fe224297efbf11ed0c5bef928b484cf`.

The additive backend preserves all 2,472 L11 records and adds 624 records in
25 stable segments. The canonical 3,096-record JSONL / CSV are 2,408,339 /
2,875,457 bytes with SHA-256
`21f19a4c56276b0abb677c58d9deb23d512e033b7a0f26c241ed9feb72891667`
and `f3561b09cf15ae2bdd5fc84ee7d464abc720be04d92715200002518e63f4ee2f`.
Two staged generations and two root validation cycles reproduce them exactly;
receipt: 10,298 bytes /
`929e532404e2c77d5570c4483f303ad57fc8096464248395f92752f32f0105ed`.
All component rights remain CC BY 4.0 with attribution, change disclosure,
license link, and non-endorsement. Preservation gate: PASS for GitHub and
Zenodo; Figshare is an independently recorded operational retry, not a build or
production hold.

## Complete Habring v1 public-preservation gate

GitHub commit `46d5753e853397e013d21b01872d789f7ee07a63`, tree
`97581caaced321b85b0131ba3df0e671ff3afa8a`, and all 46 changed paths pass
immutable anonymous byte readback. Receipt: 11,883 bytes / SHA-256
`0c5d39c29219acaf74832a4b29688babb892a8fcaafcd5377931ee6da5603352`.

Zenodo DOI `10.5281/zenodo.22088305` is public/latest in the existing concept.
The exact 100-file namespace contains 98 inherited unchanged files plus the
3,779,312-byte Habring PDF and 1,856,748-byte comprehensive ZIP. All 100 public
downloads match their expected SHA-256 identities. The Habring PDF is the
anonymous default preview. The comprehensive ZIP passes CRC, seven unique
nonrecursive members, six inner checksum bindings, nested 56-entry source
bundle verification, and zero self-reference. Receipt: 27,419 bytes /
`49c00f1f3d0ca6a2f2949352feff4b5ef4a627f4464acaf81d106def8db75dca`.
The ZIP intentionally binds the prepublication control snapshot recorded in
its input lock; these postpublication receipt/cursor updates are later evidence
and are not substituted into the immutable published ZIP. Reproducing the
published release means verifying the frozen ZIP and its manifest, not
rebuilding it from subsequently advanced live controls.

The prepared Figshare payload independently passes all local gates at seven
files / 6,007,269 bytes, but authenticated preflight returns HTTP 403
`InactiveAccount`. Zero mutation occurred. The 2,924-byte sanitized failure
receipt has SHA-256
`a8686c9a558954911d61b81762c5d571e0fc656286f25d6b7b506cf8c08ae218`.
Retrying the same article when the account is active is additive and does not
block the Becker build lane.

The subsequent narrow GitHub preservation-evidence commit
`90062e1d78f41011ba350c88f07ebef44de80365` / tree
`24865fc6929518c29a419305e96aba955d60aa44` also passes anonymous verification.
Its public API and immutable patch agree on 39 unique changed paths; all 39 raw
files, totaling 9,603,708 bytes, match the committed bytes and SHA-256 values.
The sanitized 13,489-byte receipt has SHA-256
`4c06f305356da35a7fc66794425e8d2bb45d020705a6fcfac16a7b3ea84e1e90`.
This is a preservation-evidence gate only and does not alter the frozen Habring
reader or Zenodo release bytes.

The final evidence descendant also passes: commit
`42e9c6a4bd98d0583335382d33355ff70e1bedde`, tree
`9490cf09028b97026318eb0d5d4ec4fbfe85dcf9`, parent
`90062e1d78f41011ba350c88f07ebef44de80365`. Its five changed evidence paths
total 232,442 bytes and match immutable anonymous readback. Receipt:
`release/github/2026-08-25-habring-preservation-receipts/github-final-evidence-push-readback.json`,
1,865 bytes / SHA-256
`c544f0ec524221ef4196caaaa882b015287406ca4b8c24a05d8fe62c6882ab55`.

# Becker-01 Lagrangian duality, Slater, and KKT consolidated build and QA

As of: 2026-08-25  
Admission: PASS locally and publicly preserved; larger O015 course partial

Authority/archive gate: PASS. Official commit
`98ed6930084c435ba0f675f7646ced1f2fd8729e`, tree
`f04670e3f7be3d4836c380fd8bd31883e0b992c9`, 164,525,001-byte archive /
SHA-256 `52ec99acf2bfb7f4db308a7b0988ef9cfd28404a822c5cf0ac922d7f43c41821`.
All 180 files / 168,574,596 bytes match official API blobs. The root MIT
license is 1,071 bytes / SHA-256
`c026320fa977e084507f66ce2d4de70f3955b39a590f5cdd6e10e690e7a13cac`.
The APPM donor is source-closed; the alternate master fails closed because of
40 bad preamble paths and 24 absent figures.

Boundary gate: PASS. Five admitted ranges—1263–1321, 1398–1405, 1414–1499,
1652–1726, 1731–1743—are bound by the 2,383-byte source-boundary receipt,
SHA-256 `abe1c8c46c5e3c94f489e8e81447587d075d55c643f10e6c2f5065349da32da2`.
The 12,294-byte English witness has SHA-256
`20335c054393ea43d8912046b6dbfa07f6018f9e16b889e4cd0f66abc064d565`.
LP ranges 1322–1397, 1406–1413, and 1727–1730 are excluded for O018.

Reader-build gate: PASS. The 12,924-byte Indonesian body and 7,330-byte wrapper
have SHA-256 `ad656aa517ff418cc1529d2c2c62c602ea95aa2a4dbff9cf1f3f336f26e574ce`
and `85903fa4ac1975acd38bbadcd543a954257d7f8eba7552e3ee482bd12b8da04d`.
Two clean PDF builds are byte-identical: 12 A4 pages, 487,534 bytes, SHA-256
`c698444856fd01e1ee306d7e3dbca31992f8bb4cf7b4a4cf106ea678be83e615`;
zero fatal, undefined-reference, or overfull-box findings. The 3,868-byte PDF
build receipt has SHA-256
`e1ae5997f3901e504e000a9f6c35eb439da17a8419594e7d0d678e3a886207ed`.
Two HTML builds are byte-identical: 30,131 bytes / SHA-256
`b4a762b10746d394be714177669ad1d5e9903aa04933e8ff4791a179dd0377c0`;
its 699-byte receipt has SHA-256
`d6b152f6d7f9da95e274b328623c59f391adb1b12edb122aafede04f1062606d`.

Math gate: PASS 10/10 twice. The 13,799-byte receipt, SHA-256
`ed11bcc47d9545b1b8c47ac0ca1aca8b9f27cc23331c4389aeabde7cdaed790b`,
checks SDP primal/dual optima, one-norm projection, Moreau decomposition, QP
KKT, penalty scaling, source boundary, and provenance with open NumPy/SciPy.

Browser/accessibility gate: PASS within recorded limits. At desktop 1280,
tablet 768, and phone 390 viewports the centered top-level reader fills the
usable width without page overflow; wide display mathematics scrolls locally,
inline formulas do not. All 118 MathJax containers render; zero broken
references or console findings occur. Receipt: 2,187 bytes / SHA-256
`6206858c25bcf9dc3f0caaaccaa96d29dd2cdf496e020771663c91f617d09dc7`.
The HTML declares `id-ID`. The searchable PDF declares `/Lang id-ID` but is
untagged; this known limitation remains in the original accessibility closure.

Visual gate: PASS. All 12 PDF pages were inspected after the final rebuild;
zero clipping, collision, truncation, broken glyph, hierarchy, formula-layout,
or orphan-list defects remain. Receipt: 1,723 bytes / SHA-256
`6c068de1d31d382f016de4f41949a936005ef8fcdd137721fe93ba9901104fea`.

Independent semantic gate: PASS. The final 2,698-byte rereview, SHA-256
`5dc7624654e142de950a79a863d46f8dd20bd6776fd615dc50b92788d4d21625`,
confirms Becker/Krock and inherited Boyd–Vandenberghe/Bertsekas credits, honest
translation/editing language, `lambda>=0` and `mu>=0` before exclusion of
`mu=0` in the Slater proof, and saddle quantifiers `x in D`, `lambda>=0`,
`nu in R^p`. No P1/P2/P3 semantic issue remains.

Backend gate: PASS. Deterministic reprojection removes the superseded Becker
block, preserves the exact 3,096-record non-Becker prefix, and creates one
224-record `d90.becker.98ed693.b01.*` block. Final count is 3,320 records /
3,320 unique IDs. JSONL is 2,552,754 bytes / SHA-256
`48292d9ab6f8917e914f8ad9d07e0be99b8c1eeb1f3a3f38be36600728ab6f67`;
CSV is 3,054,550 bytes / SHA-256
`baf7e3c11cd10e636cdf61f3f469954f6f0e072a49f2e6528186e3ba4231810f`.
The 2,991-byte receipt has SHA-256
`deaa9b0d797a023814695b2c6648ca74ddc1b171199aa5c949a1d84ca195d7ed`.

Release-package gate: PASS. The reader-first ZIP has 21 entries / 621,079
uncompressed bytes and is 511,931 bytes / SHA-256
`5d33d0cb89e1eaa96027a0b645bc54425b6008a45e7f0ae8ffed7938cc429281`.
Two builds are byte-identical; CRC, fixed timestamps, safe unique paths,
package-tree equality, and all 20 checksum bindings pass. Manifest and
`SHA256SUMS` are 9,446 / 2,062 bytes with SHA-256
`4902c55f0c7ed5f41c4613855cd03bd38e681962e61c549b2cb2d4ec287c6ced`
and `9ec108b1154128212d4faea0ef200cbaa5c120072463faf43890394a958fe9d8`.
Local verification is 7,124 bytes / SHA-256
`7ef77415c7e16508b31a1cb998817f6a515ba83d127e8924a51065a3704e93ff`.
No raw archive, cache, build tree, full backend, credential, or forbidden
project-label byte enters the compact package.

Public preservation gate: PASS. GitHub commit
`7ff680f4079499c08f3b29780105f58279f519d5`, tree
`a36c6a880f483681575c4b946d53a4ee0e493bf5`, exposes 62 changed paths /
8,203,835 bytes, all matched by anonymous immutable raw readback. Receipt:
`release/github/2026-08-25-becker-01/github-public-readback-becker-01.json`,
16,504 bytes / SHA-256
`1521d1267be860fc9dfb2a1aef8708761bcc6c319108f08ff09d13d926afdd79`.

Zenodo record `22096817`, DOI `10.5281/zenodo.22096817`, is published/latest
in concept `10.5281/zenodo.22059741`. All 99 public files pass anonymous exact
byte/hash readback: 90 inherited unchanged and nine additions. The authoritative
public file state selects the Becker-01 PDF as default preview; authenticated
draft lookup returns 404. Its 405-byte sanitized closure receipt has SHA-256
`ebe7ccc4031a5a1cfb35c2c5e94b2b5fd9a2eab5d0575aad4cbc649ca7e0bbbc`.
Public-byte receipt:
`release/zenodo/2026-08-25-becker-01/zenodo-public-readback-becker-01.json`,
27,333 bytes / SHA-256
`b36739a507f1f6aeae2a2a88ac4b12bfd8c1b6f6f341fd05be33b97a38e7851e`.
No credential material or upstream contact is recorded.

Publication-evidence descendant gate: PASS. GitHub commit
`18d5799e27d0f70d36001082465d5fa0fd48cb39` / tree
`37da43821d7d1b354d8c8a28c2cdbc089c9f6236` exposes 17 receipt/control files /
560,180 bytes; every API blob matches the exact committed bytes. The sanitized
4,985-byte receipt has SHA-256
`2e23d36a42a8524567a7d2b02c48931d1446b3e14c5afe080c4741d0a9519e82`.

# Becker-02 Douglas--Rachford consolidated build and QA

As of: 2026-08-25  
Admission: PASS locally and publicly preserved; larger O015 course partial

Boundary gate: PASS. Frozen donor `APPM5720Notes.tex` is 130,911 bytes /
SHA-256 `dd2e209a05a6f993ccac3b7c32e464005466b45c93237e96c85da56147466cb8`.
Exact lines 2750--2797 are 48 LF lines / 1,285 bytes / SHA-256
`386f1f0f94f6433eebdd6d07e10f3ffe28ffa8650e392cb0158a389e01452cf2`.
The 1,358-byte wrapped witness has SHA-256
`fdc368741a0a88eb9d21c69d655ac6ce1b44571c2d49c6a3302e3efc4673594b`
and its interior matches byte-for-byte. The 1,773-byte boundary receipt has
SHA-256 `06cd220dee304ad6e33ec66109d4e7e1a8c0d41e221770634b280850000ca10f`.

Reader-build gate: PASS. Indonesian body/wrapper identities are 4,915 /
7,134 bytes with SHA-256
`2d0e7d64d8226954640013caecd1cacfb3c60d2ae75a27f130f97e900a20464a`
and `23fd130a5e644801ccb2374450ec07744c9e68dff003c295f3b127d9a9b90955`.
Two clean PDF builds are byte-identical: 458,915 bytes, nine A4 pages,
searchable, `/Lang id-ID`, SHA-256
`32e26d96a0878ad2a5e798a099759eb4351cbe728a2d2b912757ebc402e49794`;
zero fatal errors, undefined references, or overfull boxes. PDF receipt:
4,942 bytes / `a6d8ee690768e343dc0157d7528478ee8dcdadb56af0ce9fab713fccae9b697e`.
Two HTML builds are byte-identical: 18,370 bytes /
`ff42d60d3bdce967341f69932a07cb85af868b3f4bb02a10f8beb627198719fe`;
HTML receipt: 4,575 bytes /
`db3f89b93196197840b7c8ce710a3a9ebe6b354c35092c19ed9167e296f7d380`.

Math gate: PASS 8/8 and byte-identical on rerun. The 9,486-byte receipt,
SHA-256 `bbfc499b2f6046c4db3c1a3327aac5fe6432030077f4de27915cd2c2fdb836ad`,
binds the live source/readers and validates corrected Fenchel dual signs and
strong duality, an exact relaxed scalar Douglas--Rachford contraction, and a
nonsmooth fixed-point/subgradient witness with open Python/NumPy.

Visual/accessibility gate: PASS within recorded limits. All nine 150-dpi page
renders were inspected at 1,241 by 1,754 pixels with zero clipping, overlap,
broken glyph, equation, hierarchy, header/footer, or page-number defect.
Receipt: 1,981 bytes /
`7a5909ba3cf96aeb601a1fea8c2668851112afbc9d3ed41e65576371dd4ae43f`.
The centered HTML reader passes browser inspection at 1280x900, 768x900, and
390x844: useful-width fill ratios are 0.893, 0.842, and 0.885; center delta is
zero; page overflow, broken fragments, uncontained display math, and console
findings are zero. One tablet and six phone display formulas scroll locally.
Receipt: 1,974 bytes /
`afb5ba3c5242e74ff6b1f2522bba6818d29baa70d924dffb968f65ff531622c8`.
The PDF remains untagged, so tagged-PDF closure is still open.

Rights/semantic gate: PASS. MIT source and CC BY-SA 4.0 translation/correction
layers remain separate; full MIT notice, Becker/Krock and inherited
Bauschke-Combettes/Lions-Mercier credits, change disclosure, exact
`OpenAI Codex gpt-5.6-sol, Ultra` marker, and nonendorsement are present. No LP,
adjacent ADMM section, figure, exercise, solution, code, or interactive is
imported. Final independent rereview records P1=P2=P3=0. Receipt: 1,973 bytes /
`97ad583f637be41672aca786807a1d2b8974406d34b3f9865b2d98a0f9727163`.

Backend gate: PASS. The extension preserves 3,320 prior records exactly and
adds 110 under `d90.becker.98ed693.b02.*`, for 3,430. JSONL/CSV are
2,623,909 / 3,142,537 bytes with SHA-256
`6943678e867b5f72a509e1dbc57dcdbc61c79cc7ced3828fc3b8da999dff3ae6`
and `4e3249844a4948f02522c300ff69d313cabda2768d23f7f6f674b9c25ae08f97`.
Two regenerations match; stripping the new workflow recovers exact prior
JSONL/CSV bytes and JSONL line sequence. Extension/validation receipts are
2,818 / 4,598 bytes with SHA-256
`e9eb335369ce480ba2f835cf15304ab52e2b74de0bf380ecd4044b2d21a3c844`
and `626e271c81187203b900fa2d8eace3079290e6a9aa9163e30dfa6faf463320f6`.
The generic historical validator remains stale at its old 793-record baseline;
this known unrelated failure does not contradict the dedicated passing gates.

Release-package gate: PASS. Two ZIP builds are byte-identical. The reader-first
package has 22 safe unique entries, 482,742 bytes, SHA-256
`b97f1ea849f1edb5a46422bda94e06e4217405a8642217f3d4a7ed740f0c5f6e`;
CRC, fixed timestamps, exact package-tree bytes, and `SHA256SUMS` pass. Local
verification is 7,368 bytes / SHA-256
`5d8972d9ccdcd378fd4a0fad464918afbd1907a08c6ba603ea51f05acc57c7ea`.
No raw authority archive, full backend, build/cache tree, credential, bulk
provenance dump, or forbidden project-label prose is packaged.

Public-preservation gate: PASS. GitHub content commit
`2923d8b6e06f1ced65a91be4bd63e4766e1fb5b7`, tree
`b44b2d044d015ead4913f332588170238549820f`, passed anonymous exact-byte
readback for 59 changed files / 8,172,433 aggregate bytes. Receipt: 36,917
bytes / SHA-256
`01f10d998820983f4dc0e068dd5423144165e1f4421fa1dac283608e81642dab`.

Zenodo record `22098168`, DOI `10.5281/zenodo.22098168`, is published/latest in
concept `10.5281/zenodo.22059741`. All 99 files passed anonymous size/SHA-256
readback: 91 inherited unchanged plus eight Becker-02 additions. The configured
default preview is the Becker-02 PDF. Receipt: 26,801 bytes / SHA-256
`8920dcfad62b0f4d34642b60f35b5b8d7f7a901ad430b75b90d35683a5bb9b24`.
Authenticated closure returns HTTP 404 for the record draft and finds zero open
lineage drafts; receipt: 394 bytes / SHA-256
`4fbd6d2e456d89ed024c4d390a560a091dec1d364594e240d61a6d84a55c07f5`.
No credential material was recorded and no upstream contact occurred.
The GitHub receipt/control evidence descendant
`64b60dae61096a265c6deec8e7defb21b1d917d5` also passes anonymous exact-byte
readback for 18 files / 618,143 bytes; receipt SHA-256
`74180653bbfb02557987efe6eb617c5e6ed1b67d4610e36291fdaad70c536da5`.

# Becker-03 variance-reduction consolidated build and QA

Source-boundary gate: PASS. Frozen donor lines 2971--2988 are 18 LF lines /
900 bytes / SHA-256
`b81634bf07565fcf8d2774bea7b96e565e5fdd76cf5e782c5e4eb6fb3268c5ed`;
the 977-byte witness has SHA-256
`66f243b97cd379b73d217c6a3e424db688f8ace246852cb24f78108c53186607`
and an exact byte-matching interior. Boundary receipt: 1,815 bytes / SHA-256
`41cb539339f04ffe81ced83d0c28cf13ca8071bc5ac2de5dd21cfe6700da29e3`.

Deterministic reader gate: PASS. Two PDF builds produce the same 476,357-byte,
11-page, searchable id-ID A4 PDF, SHA-256
`2d2475c2bbd1af90dc203b0691dbc5f176d2a233c6888d49aec2fe045f498d6a`;
zero fatal, undefined-reference, or overfull-box findings. Receipt: 4,920 bytes
/ `2b00568f097123cbfe443580a74d22c1589fc92929bc4ed891adf6fd18851727`.
Two HTML builds produce the same 24,322-byte semantic reader, SHA-256
`da86d8fc79e7dbc039b936437a310e74c3115d90407f7b7c1dce191e00a6fdcb`;
receipt: 4,636 bytes /
`2a2174cff80da75d38ee71788edc4346d893b1332e7e834152d7bfe3ac2b1b13`.

Math gate: PASS 11/11 with exact rational computation and no randomness. It
checks the primary SAGA theorem witness, conditional unbiasedness/variance,
old-table replacement, exercise arithmetic, a finite exact rate witness, and
the averaged-iterate identity. Receipt: 6,375 bytes / SHA-256
`51fd654f14763f7aa96ef103e98291a34a477eba6eeb2b16df88dcc94497013f`.

Visual/browser gate: PASS. All 11 PDF pages were inspected at 150 dpi with
zero clipping, overlap, glyph, formula, hierarchy, header/footer, or page-number
defect; receipt 2,472 bytes /
`1387dcaa996c32a93aac0492f15f71cac9d60022b5c1b26685d0f16e0fa65f48`.
Browser QA at 1280x900, 768x900, and 390x844 shows one viewport declaration,
zero page overflow, zero broken fragments or console findings, and local scroll
containment for eight wide phone formulas; receipt 2,523 bytes /
`87cfb2cd11657fa7051df151d5972c11350bbdaf2264f892dc3893bee50365ec`.
The PDF remains untagged; HTML is semantic but loads a pinned MathJax CDN.

Rights/rereview gate: PASS. MIT and CC BY-SA 4.0 component scopes are separate;
Becker/Krock and Defazio/Bach/Lacoste-Julien credits, complete MIT notice,
change disclosure, exact model marker, and nonendorsement are present. The
SAGA PDF is local evidence only. Independent rereview records P1=P2=P3=0;
receipt 3,799 bytes / SHA-256
`ec8a9cc7429440abc8b2cb371dbe41318774eecc09fcccbffdc1dc2333a9a338`.

Backend gate: PASS. The protected 3,430-record state gains 155 B03 records,
including four explicit hint/solution pairing relations, for 3,585. JSONL is
2,724,813 bytes / `fd8e7f3a13cbc17784b7f9b6a39f83344124ec381b98a34bf8095935c5c054fb`;
CSV is 3,267,489 bytes /
`56004e9095adc61950b89c9e6f6959e6dc0f33d5211d4b67f4f1277216245c72`.
Two regenerations match; exact workflow stripping recovers the baseline.
Extension/validation receipt SHA-256 values are
`8df8ad1b95748fec54f9149678fa87ea68947567c14ab314afd6a3471036e1c9`
and `e13710679ca55db8bd51d293395721516e722c47f5984a7c333cdd57c3a79cc0`.

Release-package gate: PASS. Two ZIP builds are byte-identical. The 22-entry
reader-first package is 501,094 bytes / SHA-256
`49a05c958630aa1592587bd8083e3da993333fb2853c1e710c34089b8a013ff3`;
CRC, safe paths, fixed timestamps, package-tree identity, and `SHA256SUMS` pass.
Local verification: 7,359 bytes /
`f3beff89ea6e83456152055e444e604789d048e6bb8f5ccd93574f9620844c8b`.
Public-preservation gate: pending immediate execution in existing lineages.

## 2026-08-25 — Becker-03 public-preservation gate

Public-preservation gate: PASS. GitHub commit
`09cc7e554b87c735428fb8cf3320a3d499956894`, tree
`babb37fc16f31f95fee3e34a9b941d23e25a564b`, and parent
`64b60dae61096a265c6deec8e7defb21b1d917d5` expose 58 changed paths /
8,512,495 aggregate bytes. Every immutable raw path passed anonymous exact-byte
readback. Receipt:
`release/github/2026-08-25-becker-03/github-public-readback-becker-03.json`,
36,273 bytes / SHA-256
`78c4f0ab66d160b9e4939527e37252f6c8164d2ab7947c1e578bf834df01e3e2`.

Zenodo record `22102236`, version DOI `10.5281/zenodo.22102236`, in concept
`10.5281/zenodo.22059741` is published/latest with exactly 100 files: 92
inherited byte-identical files and eight additions. Seven parent release aids
are omitted only from this version and remain in earlier immutable versions.
All public downloads passed anonymous byte/SHA-256 readback, and
`D90-BECKER-03-reduksi-varians-id.pdf` is the default preview without a repair.
Receipt:
`release/zenodo/2026-08-25-becker-03/zenodo-public-readback-becker-03.json`,
27,084 bytes / SHA-256
`a50feeff83c7fbb6d45a49ac2b1156f12600e93e94a14b78b1ffff49ab4c5c1d`.
The 17,356-byte release manifest and 761-byte checksum file have SHA-256
`84c41fe28ba4879f9022d091b9c2c45aa2656b8bf89dbe4fb8b8f4399246b136`
and `4c9daa3229e7e71266feb1cbcd44fa37c541437cf8c310bbd162201ac340f6a0`.
Authenticated draft lookup returns 404 and the concept contains zero open
drafts; the 394-byte closure receipt has SHA-256
`94cd4529f15e1f905f0afe08a15f2141821cafbfe84f1e37293af385e175ca8b`.
No preview repair, credential recording, or upstream contact occurred. All
three bounded Becker modules are now publicly preserved, and the production
cursor advances to `FINITE-ORIGINAL-CLOSURE`; the following evidence-descendant
gate changes no reader or DOI byte.

Evidence-descendant gate: PASS. Commit
`c6d6fac17b5e3cd735adca98a55e9d2596ad65aa`, tree
`ec595d7700cca172f7c749cbd09cffda50db7f7e`, parent
`09cc7e554b87c735428fb8cf3320a3d499956894`, contains 19 receipt/control and
publisher/verifier paths / 851,480 bytes. Public `main` points to it and every
immutable raw path matches. Receipt: 12,945 bytes / SHA-256
`191713508a9ed3c1e4dd6c99e1860c107c6df32428dcad7aa4c911a8abc25fc3`.

## 2026-08-26 — Original-01 consolidated admission and Zenodo gate

Original-01 passed the finite tranche gate. The independent source, wrapper,
PDF, HTML, and EPUB identities are respectively 27,431 / 5,311 / 486,032 /
353,245 / 64,322 bytes, with SHA-256
`db677ca6bab274a5db3e356fc996cef3bb00fb67770a90984460aa265fabcf26`,
`d632765baf270a7a7c1b39f051d83c1d76dd3ccc04457fb1b4b92088ffdd9322`,
`7fafa5aff08ee02f6b79c8dcea7b4bf509570958f94dc94ae51fc9e66b9f6bca`,
`052155a1edc7f8f81a84e5445e1408c3ffdef6e42899677bf80f6300bc7558a4`, and
`d3aaea87c928c825aac37310b3143e43c375f2ebb0ab4fe37bd0e34bfeab1f08`.
The PDF has 16 pages, is searchable and page-filling, and is truthfully
untagged; HTML browser QA and EPUB native MathML are the accessible reflow
surfaces.

Consolidated receipts pass: math
`17e9510f9cb1562bbaee822c4b9381e8ff828aced798ca91723b2b6bc732751e`, PDF
build/visual `3a40f7be6da3ba76bd8ab7354da50af8f68c02b436882e61617fb077328c6fe0` /
`49fa45dce663b5719f72295865497dd93e5e9f80fc78ef7ead89c0d29c6f1ae5`, HTML
build/browser `989ebdfe80076fe0b9405815f98f2dfe4cda19405f03c515fb6fc52e9c4f2753` /
`22a4c01477c1b6cfcb59885bf0018eee9cb3656fc3dc3635f7c54afa77c4e0cd`, EPUB
build/conformance `e95c686006d920774a2d0a080410d4348e58d4e2d197cbf8593b326a3285334e` /
`e1c9b411c9990df28b37a4dcb2d9111058a842768a3af13010397a700033d40c`, backend
`c3d1961503dd77c3b9fea4b35556cc4916cef04ce663c58fca518622218bb561`, rights
`3f2dc12b538b1468cdfd810382a63a42d27801f25f93067dd36b816f098196fe`, and
rereview `c3ae6f9298ef9e2ecc26a6dd23534d2d197ddc1f8ad2f8c676412e2ec0c258e0`.
Backend admission has 3,943 records; the JSONL and CSV identities are
2,941,125 / 3,537,781 bytes with SHA-256
`d829eb7641e04aff41529be436818514d88dc3b2961d2d23fbc12d1d6b9fc35f` /
`4fd14cad8d08b0e551bf8ce8d306fc8ee11751a9b66e1717b7f1a3c16a822ab4`.

The compact package gate passes with two byte-identical builds, safe paths,
CRC, fixed timestamps, and checksums: 721,697 bytes /
`8f175c21f404e20fccef2b42c2eaa1ccdf1599cfc89c189d1b912d3a0d3c454a`.
Zenodo publication/readback gate passes in existing concept
`10.5281/zenodo.22059741`: record `22103674` / DOI
`10.5281/zenodo.22103674`, 99 files (90 inherited, 9 additions), Original-01
PDF default preview. The 26,975-byte public receipt has SHA-256
`8a88a48955a40e21a10f92889a29a17f41879f774140a147793b2dd794cd84e2`; closure
is pass with 404 draft lookup and zero open drafts (391-byte receipt
`7790f5c71f0093e97c99b3d3f70db4a203fa85492801b618f55778ad34dd4b10`).

The remaining release gate is narrow GitHub commit, push, and anonymous raw
readback. No upstream contact occurred and no credential material is recorded.

## 2026-08-26 — GitHub public-preservation gate closed

GitHub gate: PASS. Existing repository
`https://github.com/KokunoYumeto/advanced-optimization-convex-analysis-id`,
branch `main`, commit
`ec90fc78b5f974f845d04f2e1c59069e5eacefe3`, tree
`8b02653ebaac49f558c7707d05f93a6ed4b0c71f`, parent
`c6d6fac17b5e3cd735adca98a55e9d2596ad65aa`. The exact commit contains 83
explicit Original-01/control paths totaling 10,792,966 bytes. Anonymous
raw.githubusercontent.com readback matched local bytes, sizes, and SHA-256
for all 83 paths. Receipt:
`release/github/2026-08-26-original-01/github-public-readback-original-01.json`,
53,588 bytes / SHA-256
`eb5f9041a3edb59692122402adaa1acccb77453186881e98552fbf15cabc91d2`.
The bounded verifier is
`release/github/2026-08-26-original-01/verify_github_original_01_public.py`,
SHA-256 `197a12d17efaddbb642d1f2a4d8baf234cf032cb7c27cfff5d0e5a6758d6f376`.

Both GitHub and Zenodo preservation gates now pass. No upstream contact or
credential material was involved. The next gate is a larger coherent original
module on variational inequalities, maximal monotone operators, resolvents,
and splitting; this is not a publication or evidence-only loop.

## 2026-08-26 — Original-02 consolidated admission and Zenodo gate

Original-02 reader identities are PDF 453,811 bytes / 16 A4 pages /
`0dee2b2c16f0f0868b2c0813462fce6ecc02ad2b71174eb4c622f23988771284`, HTML
190,403 / `ed60085e7ccbfcafa6675dc8bc4ebd728eaaf7c27ca24d35d5dbec7b742f529a`,
and EPUB 48,701 / `dcde3d4e1a2070626fb86d3994667ce57095e5f8849b67ce3ebecaa145b54a86`.
Two clean reader builds match. Every one of 16 PDF pages passes visual review;
desktop/tablet/phone HTML reflow passes; EPUBCheck 5.3.0 reports zero fatal,
error, warning, or usage findings and the EPUB contains 295 native MathML
surfaces. Exact math validation passes 20/20, including two byte-identical lab
replays. Rights/non-overlap and rereview pass, P1=P2=P3=0.

Backend extension/validation receipts are
`938232e46d790d89813d85fe86609bfdb868759cac0f22104b72959af38b8370` /
`bc12cc183c2e972497ac230eeb56dd9dee80930de9fb5ae449f4086d21d479a2`.
The canonical 4,338-record JSONL/CSV files are 3,183,459 / 3,839,894 bytes with
SHA-256 `52efa90b75fecfa61498bd60ec530045d5cb08c921b6149735f1c6aaa3305439` /
`2f1963d415772229eb8a2d017a7aea847c7cf205c94afc8810b8cdbd89f8343c`;
two independent regenerations match and recover the protected baseline.

Package gate: PASS. Two builds reproduce the same 39-entry, 679,973-byte ZIP,
SHA-256 `40768542571ba269b2b175e080a611a4626f92068510d5e26b95cb53da66a1eb`.
Zenodo gate: PASS at record `22104724` / DOI `10.5281/zenodo.22104724`, 99
files (90 inherited, nine additions), correct default preview, anonymous
exact-byte readback, draft 404, and zero open drafts. GitHub is the sole
remaining preservation gate for this boundary.

## 2026-08-26 — Original-02 privacy-correction and current-byte gate

The preceding 679,973-byte package identity is superseded for current use.
Two deterministic sanitized builds reproduce the same safe 39-entry ZIP:
680,451 bytes / SHA-256
`5fc4323613bbf3572d85c8c3ffbdcddc43a6ddbe9dd3f899829a2b67362e319d`.
The current Zenodo manifest and checksum file are 6,559 / 1,001 bytes with
SHA-256 `92e05870cc496deb1c9509a1299fdc90d73e9b04f920a3c8347171d900a9771f` /
`1e1b5734be66d452fdf025100e1d4ec22184de02798f8f765eddccf74ef81576`.

All regenerated current QA receipts pass. PDF build/visual, HTML build/browser,
EPUB build/conformance, math, rights/non-overlap, and independent rereview
SHA-256 values are respectively
`d734ea6ecb0effdbcf710a682e9acab5996de7b502af774499d0410b2867d51a`,
`e41dcb44f270ecc483b2e2ab1c231ff88c99aaf1ff6fd926805d0764fb530c04`,
`c3564fa0ee594207bae55ecd06f6ff0b4137350a685aeadac51dc14775ebaee5`,
`24f7dd83724fc860b775715f72cd967a24f097cb8041686f8918154d08cd3891`,
`f2f0a2782f194ffadb96e5f09a0c7a8eac68809d786f9cd68f34eb1498fe12c6`,
`4ba00a859ae31066373581d19df7e01432e0b515e6e7687746637755693ba85e`,
`c20d9a3b32bf5dc61e4c1e6c147dc2ea0004c0f06c767481352f739e4b8aa7e4`,
`5d692573ed02910b131365567f8fdf7b1065f557923727779bd3bc13afa7dd2e`,
and `a13acdb1165da017628314ab0b966e6cd1a8cd9f7091cbfa09b88f8a68c23082`.
Backend build/validation remain
`938232e46d790d89813d85fe86609bfdb868759cac0f22104b72959af38b8370` /
`bc12cc183c2e972497ac230eeb56dd9dee80930de9fb5ae449f4086d21d479a2`.

Zenodo in-place correction gate: PASS. Same record/DOI/concept, 99-name
inventory, metadata, and default preview; exactly three replacements; 96
protected files unchanged; no new version. Anonymous exact-byte and privacy
readback passed with zero profile-locator hits in public additions, nested
archives, or decoded PDF streams. Authenticated closure passed with draft 404
and zero open drafts. Correction/readback/closure receipt SHA-256 values are
`2cf795cc52647254c20fcf76e6b3b6b6b216bf55b2a62868a06fff638ba40114`,
`2c6c7b0bf91f7fe5fd1d0dc7093f80c1442cbfdab0aa6a0365a3044f39db8d0f`,
and `65c7cc9348012928e1eb32c42ca167facde86bf19a94cd2c402b0af98cce68ab`.
GitHub remains the sole outstanding preservation gate for this boundary.

The pre-commit exact-path gate covers 103/103 manifest paths and 11,225,771
bytes, with zero configured-credential hits and zero profile-locator hits even
after nested archive and PDF-stream decoding. Structured JSON/JSONL/CSV and
Python AST checks pass. Narrow `git diff --check` reports only five known
blank-line-at-EOF findings in the already frozen PDF visual verifier and four
byte-bound package copies; changing them would invalidate accepted package and
public identities, so they are preserved. There are no other whitespace or
patch-integrity findings.

## 2026-08-26 — Original-02 GitHub public-preservation gate closed

Local commit gate: PASS. Commit
`74780b65dcf9954bdf915aecbf57cd17fd6b43ea`, tree
`e6c004afc1efeff73a62860039491fd92525ba35`, parent
`15fb78bcf7c769b524401c24779469d6ecfc5ffd`, contains exactly 103/103
manifest paths with only added/modified statuses. Remote push to the existing
`main` branch passed.

Anonymous public-byte gate: PASS. The REST route was unavailable because the
anonymous GitHub quota returned 403 before data. Direct unauthenticated Git
smart-HTTP ref advertisement proved public `main` equals the target commit;
all 103 immutable raw URLs then matched the corresponding commit blobs. Total
verified public content is 11,226,335 bytes. Receipt:
`release/github/2026-08-26-original-02/github-public-readback-original-02.json`,
44,964 bytes / SHA-256
`c992e2563577d6edf16a5424db12edd5cbf9e4f75b832eadb51499574d32eab0`.
No credential material was supplied or recorded. Original-02 preservation is
closed; the next QA boundary belongs to course-wide assessment, two remaining
labs, capstone, tagged PDF/accessibility, and integrated final readers.

## 2026-08-28 — Original-03 and integrated reader/backend gate

Original-03 closure: PASS. The 53,446-byte receipt SHA-256 is
`0e4dfa26143342cb22580c5cd2bff074a403337a3dd7aa82e3879aa82d261907`;
P1/P2/P3 are all zero. Three bounded scripts (smooth globalization,
log-domain entropic transport, and composite inverse-problem capstone) replay
twice byte-identically and all numerical certificates pass.

Integrated PDF: PASS. Artifact: 1,671,254 bytes, 141 pages, SHA-256
`9deefecf469c9f2aace26bc8ccdedc552debbe9874ae035badaf5cffee0f80e5`.
Build receipt: 10,782 bytes /
`a36f0bfcf8526d6ed1161ec5627fc7d9631ae4df3bbead703b4549880deef83d`.
The structural validator ancestor before binding visual evidence is 80,066
bytes / `f39b33734ca4ecad977758d45c2a26895d3b9d75ee72c17f42b296f7db9f36f0`;
the current post-binding descendant is 80,194 /
`8cd8a5593ff8d8f9a78c53f7196527bdb26ed50560de8291a4964069d867af07`.
This two-identity chain is intentional. Every one of 141 pages was rendered and
inspected; the visual receipt is 3,100 /
`41c12f4110ef70c0808c3eca5a8170d5ea63ada2723b005914b5612f6e6bd13d`.
Searchability, `id-ID`, marked content, structure tree, reading order,
bookmarks, links, font maps, and `/Tabs /S` all pass. No PDF/UA claim is made.

Integrated HTML/EPUB: PASS. HTML is 2,485,595 /
`028e026033bc60bba1aff282f34b2e550a9f9358a3bdecd16b74e3442f743c89`;
EPUB is 379,901 /
`1bb882a75209adb220de4ee6c6cf92355b5402538c88050e807dc161fa5d9321`.
Live Chromium checks at 1,440, 768, and 390 pixels find zero page overflow,
escaped elements, broken images, or missing internal targets; 4,535 MathML
surfaces remain native, and wide formulas/tables scroll only locally. Browser
receipt: 4,436 / `c0ac06d3545821da1b03fa059fc6213b1585e2657e4e6bd8b122ebcf4dea388a`.

Backend: PASS at 4,877 records. JSONL is 3,534,351 /
`a8fe25a7170cd699a217a65f5a0c250518be7efa83f45529b70e17b0c737ff30`;
CSV is 4,272,596 /
`8c98c63fcf528bb6dc202fdbaf4d7d791be3eb205513033bffd91be8b8120915`.
All 4,337 non-course predecessor records remain byte/order-identical, the one
course record changes exactly two stale fields, and 539 records are appended.
Publication/package validation follows after control reconciliation.

Final consolidated detail: the PDF validator records 78 outlines, 328,294
searchable characters, all 25 fonts embedded, six fonts with Unicode maps and
19 mathematical fonts without Unicode maps; marked/structured content and
`/Tabs /S` pass on every page. The reflow validator records 4,535 MathML
surfaces, 729 display surfaces, 651 labels, and 29 order markers; EPUBCheck has
zero errors and warnings. The live browser receipt already obtained at the
accepted reader boundary supersedes the earlier static receipt's geometry
limitation; no new visible-browser run is needed or permitted.

Final integrated rights/release audit: PASS. Script
`qa/verify_integrated_rights_release.py` is 89,201 bytes / SHA-256
`53bbde57200d9f10751715d2849a8f489ea01cbe0cbd52b6a5b9405ad5161763`;
receipt `qa/INTEGRATED_RIGHTS_RELEASE_QA.json` is 68,004 /
`35ce414e9a347db004562df18b77ea3ddcf9a89095dd9156672de8912a778003`.
Result `pass`, `release_ready=true`, failed checks empty, contradiction count
zero, privacy pass, and publication-route pass. This audit used no network,
Git, credential, or browser operation.
