# O015 production cursor

As of: 2026-08-22  
State: Penn/Habring companion admitted through Penn Chapter 5; preservation transaction active; selected primary cursor is the MIT first-lecture semantic-source pilot

## Completed at this boundary

- Habring Chapters 3--9 and Penn Chapters 3--5 are admitted as ten optional-companion reader units with exact sources, wrappers, PDFs, corrections, rights, and QA.
- Penn Chapter 5 reaches `Section5.tex` EOF, preserves its full topology/exercise/reference/figure closure in seven stable segments, integrates events `O015-PENN-ADV-0038`--`0049`, and passes independent mathematical, computation, deterministic-build, visual, text, and bounded accessibility gates.
- The companion backend passes repeated generation/validation cycles after the final architecture/rights refresh and contains 1,283 records / 84 segments. JSONL SHA-256: `e57a457d20edfcf772f38f7dd9dfdd3368530d785bbf5b71179b90784b8130f9`; CSV SHA-256: `e2ca8f3b58dc74e208a579ff1b55997d0e5e202f49c2b018edce6358b7492c2f`.
- The current public Zenodo version `10.5281/zenodo.22059742` preserves the first nine units through Penn Chapter 4 and passed anonymous exact-byte readback for all 15 files and all 132 manifest-bound ZIP payloads.
- Figshare item `33314733` / DOI `10.6084/m9.figshare.33314733.v1` is the single public work item and is present in project `280296` and collection `8668413`. Its old CC0 metadata-only state is the update base, not the final target.
- The controlling primary-architecture handoff was read completely and verified at 13,143 bytes, SHA-256 `cd2b47ed14d55bf9de7881fdf977b0479c9d79eab296bd436e65e229bd2c210e`. MIT OCW 6.253 + Royer is now the selected D90 primary; Penn/Habring remains an optional companion.
- The Penn Chapter 6 candidate is preserved, clean, and unadmitted. No Penn Chapter 7 work has begun.

## Active preservation cursor

- Release scope: Habring Chapters 3--9 + Penn Chapters 3--5, ten PDFs, exact editable source/backend closure, rights, manifests, checksums, and bounded QA.
- Destination: a new version in existing Zenodo concept DOI `10.5281/zenodo.22059741`; do not create a new concept.
- Required labels: explicitly incomplete; no claim of semantic HTML/EPUB, tagged PDF, human/native-speaker review, or complete primary D90 course.
- Exclusions: Penn Chapter 6 and later candidates, Maple files, Git metadata, build/temp/cache trees, credentials, and any mixed-license blanket claim.
- Post-publication gate: anonymous inventory and byte-for-byte readback of every public file, ZIP integrity and inner-manifest verification, DOI/version/concept/rights/TTP-metadata validation, then a sanitized receipt.
- Figshare follow-up: update article ID `33314733` in place, with the verified 103-page Habring Chapters 3--9 combined reader as the first file and only a compact Habring-only source package, exact CC BY 4.0 license, manifest, and checksums after it. Prove the task payload is at most 500,000,000 bytes and the public project total stays below 20,000,000,000 bytes; publish, link the new Zenodo version and stable concept, anonymously read back every file, and do not create a second item or upload Penn bytes.

## Next primary production cursor

After preservation closes, stop automatic Penn source-order expansion and freeze the selected authorities locally:

- MIT OCW 6.253 official course, repository commit `58d7c86195f09dd8708b84dde28205d3199207dd` / tree `26d3136df9d5d7f564f0b1d068ec8d7a7c8818d6`, 340-page notes SHA-256 `41afb47e0f6ce328298d386d16c15defa1d98c88802175a22ba80b619bd18181`, complete 13-PDF/395-page teaching package, CC BY-NC-SA 4.0.
- Royer official 45-page notes SHA-256 `3290c61e870ef807ae92c4ace309449ee46ab3aa544e033c100f4a005311dfd3`, two laboratory ZIPs SHA-256 `88e18ea096b87bd12d182072bfbf6fd12ac73d666e16911a3f015ee9a574d461` / `0a0a908157dcf07f0dd3874c118e416dad3033a5f04f9cb37ae248b2f8feb623`, CC BY-NC 4.0.

The first translation/conversion target is one complete MIT lecture block, selected only after the official lecture-note page boundaries are frozen. Create exact page and segment IDs and independently reconstruct it twice. Admission requires:

1. every source page/segment, theorem, formula, definition, example, prompt, and reference accounted for;
2. exact source-page mapping and stable IDs;
3. no Athena Scientific figure bytes or copied layout; independently redraw required mathematics with separate rights or omit it with an exact locator;
4. deterministic semantic HTML and PDF builds;
5. searchable text, `id-ID` language metadata, semantic headings/math/navigation/alt text, and explicit limitations;
6. terminology and mathematical rereview with P1/P2/P3 closed;
7. second clean reconstruction matching the admitted semantic record.

A failed pilot reopens the conversion architecture. It does not authorize lossy OCR or bulk translation.

## Stop rules

- Do not admit Penn Chapter 6 or begin Penn Chapter 7 as automatic continuation.
- Do not restart source selection or inventory alternatives.
- Do not overlap O018.
- Do not run Git or GitHub while the provider suspension/support ticket is active.
- Do not contact upstream during production.
- Do not publish a final-corpus claim until the full MIT/Royer route, bridges, labs, mastery/solution layer, accessible surfaces, backend, rights, and human-review status are complete.
