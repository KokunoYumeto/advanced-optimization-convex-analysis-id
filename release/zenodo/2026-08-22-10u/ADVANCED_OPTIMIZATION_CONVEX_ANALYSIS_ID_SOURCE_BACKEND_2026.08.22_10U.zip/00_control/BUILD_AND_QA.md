# O015 build and QA record

As of: 2026-08-21  
Unit: Habring Chapter 3 — Subgradients / Subgradien  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-03-subgradien-id.tex` — 3,940 bytes — SHA-256 `48fe2efc3fa2b724963e40942906061c5d7dc54c92ae4280641e951d55b4d669`.
- Translated chapter: `source/id-ID/habring-03-subgradien-id.tex` — 19,266 bytes — SHA-256 `d04ff82898c157f56924c6c08fd204bcd97625f060847fd8a0b6f7a2b90b0a5c`.
- Macros: `source/id-ID/macros-id.tex` — 4,465 bytes — SHA-256 `135642edfaffb7ec15e02e330dde76e694abe957da5f1a401c8563f9d885c1c2`.
- Class: `source/id-ID/shinybook.cls` — 10,133 bytes — SHA-256 `83514a06b2884dcaa02575bb3409d2f8cc9cf2fc6e6aef344b442d424850f2c0`.
- Figures are exact copies of the two arXiv-v1 raster assets and are bound separately in `COMPONENT_RIGHTS.csv` and the backend.

The final retained build used pdfTeX 1.40.29 / MiKTeX 26.5 and four `pdflatex` passes from `source/id-ID`, with output directed to `build/habring-unit-03-id`. The exact historical shell command was not captured as a standalone receipt; `pass4.console.txt` and the final `.log` are retained. Reproduction must use the listed input hashes and the same toolchain/options: `-interaction=nonstopmode -halt-on-error -file-line-error`.

## Final artifact

- Build PDF: `build/habring-unit-03-id/D90-HAB-03-subgradien-id.pdf`.
- Publication copy: `output/pdf/D90-HAB-03-subgradien-id.pdf`.
- Both: 516,084 bytes; 15 A4 pages; SHA-256 `45f7bc24ff46079881e42be9aa6f1b508c324a208f2b4dd82e35e7e3a6d544b4`.
- Final log: 101,648 bytes; SHA-256 `217291b4c0d275977674b03a5e1dc05bc293503c7583e9ef41a1a2cbca80a6ad`.
- Final text extraction: 25,751 bytes; SHA-256 `531760f570f311256d5b141bd5f28e5495469d9bdf0f2f0c70ce5260a400d2eb`.
- Two consecutive final builds were byte-identical.

## Structural and mathematical QA

`python qa/audit_subgradient_unit.py` passes:

- authority and target hashes exact;
- 61/61 ordered environments preserved;
- 11/11 stable segment markers present and ordered;
- source labels retained, with one declared target chapter label;
- two expected figure paths retained;
- 230 source and 252 target formula surfaces aligned into 46 explicit delta blocks;
- every non-editorial delta is ledger-bound;
- formula-delta manifest SHA-256 `c979be4ecb19687c87ef590feda4d5ba8f083a945a0e0cda98236d8d7581b681`.

An independent final rereview of target SHA-256 `d04ff828…` found P1=0, P2=0, P3=0. It separately confirmed the standing-space conventions, proof-exposition delta, finite-dimensional qualifications, supporting-hyperplane repair, and all referenced adverse-ledger IDs.

## Computation QA

`python qa/validate_subgradient_unit.py` passes with Python 3.13.9, NumPy 2.4.4, and SciPy 1.17.1:

- HiGHS solves the epigraph LP for `min |x-1|` at `x=1`, objective 0;
- SLSQP verifies the composite two-variable `l1` example at approximately `(1.5, 0.375)`;
- the explicit subgradient optimality residual is `6.50e-8` in infinity norm.

Result: `qa/SUBGRADIENT_SOLVER_RESULTS.json` — 980 bytes — SHA-256 `65dde2a94aeb55e71667146509f4b5302e947d2e79af2da8339dd6049974cc52`.

## Visual, text, and accessibility QA

All 15 physical pages were rendered and inspected in three contact sheets. The two mathematical figures and the reader-facing corrections appendix were also checked at higher resolution. No clipping, overlap, blank page, broken glyph, or unreadable formula was found. The extracted text has no active English prose residue under the bounded reader scan.

The PDF is unencrypted, searchable, and declares `/Lang` as `id-ID`. Both figures have Indonesian descriptions in the editable source. The PDF is not tagged; no semantic HTML/EPUB surface is claimed at this boundary.

## Nonblocking toolchain warnings

The final log contains only inherited/template/toolchain warnings: obsolete `xcolor` `hyperref` option; KOMA-Script with `tocloft`; unavailable Indonesian modules for `glossaries`, `tracklang`/`datatool`, and `biblatex`. It contains no overfull or underfull box, unresolved reference, undefined control sequence, or LaTeX error.

---

# Habring Chapter 4 build and QA record

As of: 2026-08-21  
Unit: Habring Chapter 4 — Projected subgradient descent / Metode subgradien terproyeksi  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-04-metode-subgradien-terproyeksi-id.tex` — 4,297 bytes — SHA-256 `4efde33cf820393e001153370cdf52f96bd8b22d24582ca17063cc87e492d249`.
- Translated chapter: `source/id-ID/habring-04-metode-subgradien-terproyeksi-id.tex` — 16,612 bytes — SHA-256 `29fdc330007009bd765a17ca1dcd0cf130ff802312ebb402bf03413da5f96a7d`.
- Authority chapter: `authority/habring/source-v1/projected_subgradient_method.tex` — 14,391 bytes — SHA-256 `44ac28a0f0b67fed4855f7ed91089fab52f77804115f2a06201bff98437bd8da`.
- The wrapper uses the frozen authority bibliography `authority/habring/source-v1/references.bib` directly.

The retained build used pdfTeX 1.40.29 / MiKTeX 26.5 with `latexmk` 4.88 and Biber, from `source/id-ID`, with `SOURCE_DATE_EPOCH=1786643315`, `TZ=UTC`, and output directed to `build/habring-unit-04-id`.

## Final artifact

- Build PDF: `build/habring-unit-04-id/D90-HAB-04-metode-subgradien-terproyeksi-id.pdf`.
- Publication copy: `output/pdf/D90-HAB-04-metode-subgradien-terproyeksi-id.pdf`.
- Both: 370,824 bytes; 13 A4 pages; SHA-256 `5c9991af837995b2e24f4a9060eb3b0efe7b2d71a9bbde01948eeb81ebfd63b7`.
- Final log: 101,402 bytes; SHA-256 `1e389bcb5d005b5b65772e7383766cfe3317293cd7da48491ea65ce38e3db87d`.
- Final text extraction: 27,027 bytes; SHA-256 `1b835413d44817328ca9945962963ae4bdeadec0d5fa3eba0dfb88b5005253e7`.
- A forced full rebuild reproduced the PDF byte-for-byte.

## Structural and mathematical QA

`python qa/audit_projected_subgradient_unit.py` passes:

- authority and target hashes exact;
- all 67 ordered environments and four authority labels preserved;
- eight stable translation segments present and ordered;
- three footnotes, the Beck citation, both informal exercise prompts, and the no-figure closure retained;
- 140 authority and 169 target formula surfaces aligned into 40 explicit delta blocks;
- every substantive delta is bound to O015-HAB-ADV-0019 through O015-HAB-ADV-0027;
- formula-delta manifest SHA-256 `d0453330d42781afffe1e1b7ad3d5a663533509f43a754f9958785b9646171b4`.

An independent final rereview of target SHA-256 `29fdc330…` found P1=0, P2=0, P3=0. It separately confirmed the Hilbert-space projection proof, projection characterization and nonexpansiveness, the fundamental inequality, Polyak and general step rules, the corrected strongly convex constants and induction, both exercises, and the transparency of all nine ledger entries.

## Computation QA

`python qa/validate_projected_subgradient_unit.py` passes with Python 3.13.9, NumPy 2.4.4, and SciPy 1.17.1:

- 512 deterministic projection samples satisfy the variational inequality and nonexpansiveness with maximum residual 0;
- a constrained nonsmooth example validates the fundamental inequality, Polyak and general schedules, and the nonzero-subgradient-at-constrained-optimum counterexample;
- an SLSQP epigraph solve validates the strongly convex value and distance rates with maximum residual 0.

Result: `qa/PROJECTED_SUBGRADIENT_SOLVER_RESULTS.json` — 1,773 bytes — SHA-256 `67719078430b0e3fbfabca3dbfac3d08fed6594659c5d0b2ae69cfd2a1cbb04a`.

## Visual, text, and accessibility QA

All 13 physical pages were rendered and inspected in a contact sheet; the chapter opening, Polyak proof/rate, and correction appendix were also inspected at full size. No clipping, overlap, blank page, broken glyph, or unreadable formula was found. The bounded English-residue scan found only cited English source titles.

The PDF is unencrypted, searchable, and declares `/Lang` as `id-ID`. It is not tagged; no semantic HTML/EPUB surface is claimed at this boundary.

## Nonblocking toolchain warnings

The final log contains only inherited/template/toolchain warnings: the locale fallback, obsolete `xcolor` `hyperref` option, KOMA-Script with `tocloft`, and unavailable Indonesian localization for `biblatex`. It contains no overfull or underfull box, unresolved reference, undefined control sequence, or LaTeX error.

## Two-unit backend verification

`python qa/validate_backend.py` passes with zero errors after deterministic generation/validation. The backend contains 238 records and 19 stable translation segments. After the final component-rights refresh, `backend/records.jsonl` is 161,956 bytes with SHA-256 `cfc027adbb6104adf9290222d5e37403eefcd6d3af9abe7acc765a52daabfca0`; its lossless `backend/records.csv` projection is 195,684 bytes with SHA-256 `9bc78b5f038bb784d92a04b1682781b3f00edcccd6008f0c0a789ca35ae36916`. Chapter 3 and Chapter 4 both record passed independent mathematical rereviews; independent Indonesian language review remains `not_recorded`, and PDF accessibility remains `pass_with_limitation` because the PDFs are untagged.

---

# Habring Chapter 5 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 5 — Proximal Gradient Methods / Metode Gradien Proksimal  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-05-metode-gradien-proksimal-id.tex` — 4,817 bytes — SHA-256 `8c67641de7ebf2e06afefa2309c09823e78a4d3d5dbba89a28536392d82c359d`.
- Translated chapter: `source/id-ID/habring-05-metode-gradien-proksimal-id.tex` — 20,575 bytes — SHA-256 `1292f09d375ff0e0ff12e7c87e673596400bb94f228db70d49f9a517b1678691`.
- Authority chapter: `authority/habring/source-v1/proximal_gradient.tex` — 18,464 bytes — SHA-256 `59d5694742f0e2f9f46da0c1418b5fe0ff18521c49078ed29c843b6e8c701f6e`.
- The wrapper uses the frozen authority bibliography `authority/habring/source-v1/references.bib` directly.

The retained build used pdfTeX 1.40.29 / MiKTeX 26.5 with `latexmk` 4.88 and Biber, from `source/id-ID`, with `SOURCE_DATE_EPOCH=1786665600`, `TZ=UTC`, and output directed to `build/habring-unit-05-id`.

## Final artifact

- Build PDF: `build/habring-unit-05-id/D90-HAB-05-metode-gradien-proksimal-id.pdf`.
- Publication copy: `output/pdf/D90-HAB-05-metode-gradien-proksimal-id.pdf`.
- Both: 473,685 bytes; 15 A4 pages; SHA-256 `6f8aa99f6d0395f3c732ed64d2b5cadd5d95ff2195e2504e959d31a3c010731d`.
- Final log: 99,841 bytes; SHA-256 `462372113f47285d8a7940c1d31c779b673c8ae1da85401840310cab9acd8deb`.
- Final text extraction: 33,973 bytes; SHA-256 `a2fdf8d859cd6767f951dfa4a17c8b89c470d98b13d24e01ce1783191e2313f8`.
- A forced full rebuild reproduced the PDF byte-for-byte.

## Structural and mathematical QA

`python qa/audit_proximal_gradient_unit.py` passes:

- authority and target hashes exact;
- all 78 ordered environments preserved;
- eight stable translation segments present and ordered;
- nine label occurrences retained in source order, with the duplicated second authority label transparently remapped to `proximal:eq:moreau_diff2_bound`;
- the Beck citation, all three informal learner prompts or their completed dispositions, the one unnumbered display, and the no-figure/no-footnote/no-input closure retained;
- 162 authority and 188 target formula surfaces aligned into 38 explicit delta blocks;
- every substantive delta is bound to O015-HAB-ADV-0028 through O015-HAB-ADV-0038;
- formula-delta manifest SHA-256 `3b910b86e304b2ba472df7fbf642db5928824ee999b551cc60f287b2c5705a3c`.

An independent rereview of the complete target and a final byte-delta rereview of target SHA-256 `1292f09d…` found P1=0, P2=0, P3=0. It confirmed the proximal existence/uniqueness and fixed-point arguments, Moreau definition and smoothing proof, completed projection/soft-threshold/Euclidean-shrinkage example, all six prox rules, the smooth descent lemma, and the corrected step conditions, polarization, indexing, rate, and full-sequence convergence theorem.

## Computation QA

`python qa/validate_proximal_gradient_unit.py` passes with Python 3.13.9, NumPy 2.4.4, and SciPy 1.17.1:

- box projection agrees with independent SLSQP to `2.23e-14` in infinity norm;
- coordinate soft threshold agrees with an SLSQP epigraph solve to `2.67e-7`, and Euclidean shrinkage agrees with an independent radial solve to `4.68e-9`;
- the Moreau-envelope gradient formula agrees with centered finite differences to `4.68e-10`;
- a quadratic-plus-`l1` forward–backward run uses the exact spectral constant `L=4.6167578080095515` and `tau L=0.95`; descent, telescoping, monotonicity, and corrected `O(1/n)` value bounds have no positive violation beyond floating-point noise;
- the independently solved optimum has gradient-mapping norm `9.79e-8`.

Result: `qa/PROXIMAL_GRADIENT_SOLVER_RESULTS.json` — 5,769 bytes — SHA-256 `de96482c608bbca67fc0a14eeb32a4e69890a97b8f6834a389ea198d2b440a54`.

## Visual, text, and accessibility QA

All 15 physical pages were rendered at 120 dpi and inspected in a contact sheet. The chapter opening, prox formulas/rules, Moreau proof, convergence theorem, two-page correction appendix, and attribution page were also inspected at full size. No clipping, overlap, blank page, broken glyph, or unreadable formula was found. The bounded English-residue scan found only the cited English source title and the explicitly identified source chapter title.

The PDF is unencrypted, searchable, and declares `/Lang` as `id-ID`. It is not tagged; no semantic HTML/EPUB surface is claimed at this boundary. Independent Indonesian language review remains `not_recorded`.

## Nonblocking toolchain warnings

The final log contains only inherited/template/toolchain warnings: locale fallback, obsolete `xcolor` `hyperref` option, KOMA-Script with `tocloft`, and unavailable Indonesian localization for `biblatex`. It contains no overfull or underfull box, unresolved reference or citation, undefined control sequence, or LaTeX error.

## Three-unit backend verification

`python qa/extend_backend_ch05.py` followed by `python qa/validate_backend.py` passes with zero errors. The backend contains 337 records and 27 stable translation segments: Chapter 3 has 11, Chapter 4 has 8, and Chapter 5 has 8. The Chapter 5 extension adds 99 records across the unit, segments, concepts, terms, source learning surfaces, corrections, QA, artifacts, rights, and relations. Two generation/validation cycles were byte-identical, and a separate baseline reconstruction proved the 238 pre-Chapter-5 records semantically unchanged except for legitimate artifact byte/hash refreshes. Independent Indonesian language review remains `not_recorded`; PDF accessibility remains `pass_with_limitation` because the reader PDFs are untagged. Final JSONL/CSV hashes are refreshed after the current control records below and must be read from the validator output rather than this prose to avoid a self-referential artifact-hash loop.

---

# Habring Chapter 6 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 6 — Acceleration / Akselerasi  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-06-akselerasi-id.tex` — 5,491 bytes — SHA-256 `46903dd6b6ff8c845624931d37d9b24fd37cd89f0bf77601ba11539c59dfd5b9`.
- Translated chapter: `source/id-ID/habring-06-akselerasi-id.tex` — 24,690 bytes — SHA-256 `b1e27d912bc94722ec1c33257598c074eec8a6f5bf81f43b8946f85b48f4c35a`.
- Authority chapter: `authority/habring/source-v1/acceleration.tex` — 18,873 bytes — SHA-256 `2ff1e10e9421c0fe01a09140e3e230cb2d3728c30c572bb6ca5513b229f1e605`.

The retained build used pdfTeX 1.40.29 / MiKTeX 26.5 with `latexmk` 4.88 and Biber, from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and output directed to `build/habring-unit-06-id`. The wrapper locally disables microtype expansion, loads the Libertine/newtx font maps, and localizes equation cross-references as Indonesian `persamaan`; shared Chapter 3–5 inputs were not changed.

## Final artifact

- Build and publication PDF: `output/pdf/D90-HAB-06-akselerasi-id.pdf` — 392,662 bytes; 15 A4 pages; SHA-256 `cb9edf46d8d2582591ad3114f9a2b316073825dfd48079d12560793ad4bca0a0`.
- Final log: `build/habring-unit-06-id/D90-HAB-06-akselerasi-id.log` — 97,942 bytes; SHA-256 `0775c19ecd2e8356e7b33bd50c30871f233e0c7d05dd703ba2ec19a4f7f560f0`.
- Final text extraction: `qa/D90-HAB-06-akselerasi-id.txt` — 37,033 bytes; SHA-256 `d2679e94ce7e44cdcf183b17e73295b5b5093a1612b2460c0c6ecba512431cda`.
- Two forced fixed-epoch final builds reproduced the PDF byte-for-byte.

## Structural and mathematical QA

`python qa/audit_acceleration_unit.py` passes. The audit script is 17,917 bytes with SHA-256 `f97926aecce6f63a1dcc7733785e0f283e064888ed68d6642d676dcdac3fc8c4`; its 37,873-byte report has SHA-256 `e82f254fb7e69d498162ffcdfb70fe7d4929556351f892872bb8e65da3715b4b`.

- all 99 ordered environments and all seven labels match the authority exactly;
- all twelve stable segment markers occur in order;
- the exact internal-reference surface is restored: four `cref` and four `eqref` invocations in authority order;
- the source and target both contain no citation, figure, asset, footnote, or included-file surface;
- the source editorial verification request is exposed as one rendered self-study verification prompt;
- 166 authority and 241 target formula surfaces align into 32 explicit delta blocks, with manifest SHA-256 `886d80e0a759977c0c176d9b97e595b4c3515ecd52446a8c8b714146a9be3f4a`;
- all 47 required correction surfaces are present and bound to exact ledger events O015-HAB-ADV-0039 through O015-HAB-ADV-0049.

An independent complete review of the pre-fix target identified two P2 and one P3 findings. The frozen post-fix delta review of target SHA-256 `b1e27d912…` passes with P1=0, P2=0, P3=0. It confirms the lower-bound quantifier order and hypotheses, the complete scaled Schur–Jury minimax proof including the equal-curvature case, and the exact reference/topology closure. It separately confirmed the Gelfand/Jordan proof, spectral corollary, local heavy-ball analysis, and FISTA energy/rate argument.

## Computation QA

`python qa/validate_acceleration_unit.py` passes with Python 3.13.9, NumPy 2.4.4, and SciPy 1.17.1. The 33,735-byte validator has SHA-256 `12aa1feacc6230131ce9b82a769177449a8af7ed586ccbf56f0b7ce`; its 37,060-byte result has SHA-256 `135ded1ed0f4f3ca70616822d8856a85d3747458c9ca6e765dab72a11d3b88f0`.

- Gelfand witnesses cover defective Jordan, nonnormal diagonalizable, complex-pair, and nilpotent matrices; the nilpotent case reaches exact zero at power four without dividing by a zero spectral radius.
- Heavy-ball witnesses cover a general admissible case, the `beta=0` zero-root edge, and the minimax parameters. The optimal modal radius is `2/3`, with maximum modulus error `1.11e-16`.
- FISTA passes 518 deterministic fundamental-inequality checks with maximum violation zero. The Lyapunov-energy drift is `4.62e-11`, below the `2e-9` tolerance, and both corrected explicit rate bounds have zero violation.
- At 40 equal gradient/prox evaluations, the FISTA objective gap is `3.0715e-05`, versus `1.4867e-04` for proximal gradient. These are deterministic witnesses, not replacements for the analytic proofs.

## Visual, text, and accessibility QA

All 15 pages of the final post-localization PDF were rendered at 120 dpi and inspected in a five-row contact sheet; formula-heavy pages and the corrections appendix were inspected full size. No clipping, collision, blank page, broken glyph, or unreadable formula was found. A bounded English-residue scan is empty after localizing `Eq.` to `persamaan`.

The PDF is unencrypted, searchable, and declares `/Lang` as `id-ID`; all fonts are embedded and expose Unicode mappings. It is not tagged, so accessibility remains `pass_with_limitation`; independent Indonesian language review remains `not_recorded`.

The final log has no LaTeX error, undefined control sequence, unresolved reference or citation, or missing glyph. It retains two small mathematical overfull warnings (7.08 pt and 3.00 pt); both displays were inspected at full size and remain visibly within the page without clipping. Other warnings are inherited locale/class/toolchain fallbacks.

## Four-unit backend verification

`python qa/extend_backend_ch06.py` followed by `python qa/validate_backend.py` passes with zero errors across two final generation/validation cycles; the JSONL and CSV exports are byte-identical between cycles. The 40,091-byte Chapter 6 generator has SHA-256 `286a4fabd006e748c9681533338c172096c0f42252bb87836a2bf3b1cd77d6a7`; the 25,048-byte validator has SHA-256 `20c45a79ca698a45d640719da547fd27c045055665d4f4315f7e094e7e3574b5`.

The backend contains 449 records, adding 112 Chapter 6 records to the 337-record baseline. Its 39 stable translation segments are distributed 11/8/8/12 across Chapters 3/4/5/6. Entity counts are: 52 artifacts, 4 assets, 55 concepts, 49 corrections, 1 course, 2 editions, 19 learning surfaces, 1 program, 36 QA events, 126 relations, 1 resource, 16 rights records, 39 segments, 43 terms, and 5 units. All 337 pre-Chapter-6 records match a freshly regenerated Chapter 5 baseline except legitimate current control/artifact byte and hash refreshes. Independent Indonesian language review remains `not_recorded`; PDF accessibility remains `pass_with_limitation` for all admitted untagged readers. Final JSONL/CSV byte identities are refreshed once more after the control updates in this paragraph and are taken from the terminal validator output to avoid a self-referential prose hash loop.

---

# Habring Chapter 7 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 7 — Duality / Dualitas  
Admission: PASS

## Build inputs

- Wrapper: `source/id-ID/D90-HAB-07-dualitas-id.tex` — 8,615 bytes — SHA-256 `3b6e710e37c07cc9ec82ca919451c313c52fa762d58c7b01c6792a78a0098797`.
- Translated chapter: `source/id-ID/habring-07-dualitas-id.tex` — 35,428 bytes — SHA-256 `11e9ad614f7ac4e3107e78bc3bed03a6d4acfe22f2a65fca26433b0ae3209fd9`.
- Authority chapter: `authority/habring/source-v1/duality.tex` — 30,761 bytes — SHA-256 `0b112dee2582813cec5629c02df1dda329f690f944b60f4694b1c5762129bea9`.
- Integrated correction records: `O015-HAB-ADV-0050` through `O015-HAB-ADV-0075`; the exact 26-record proposal is 15,830 bytes with SHA-256 `57dbba9afdee2fc453dde9fbb97621c1a6897ff5377c1ec6a210827a8dce675d`.

The retained build used pdfTeX 1.40.29 / MiKTeX 26.5 with `latexmk` 4.88 and Biber, from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and output directed to `build/habring-unit-07-id`.

## Final artifact

- Build and output PDF: `output/pdf/D90-HAB-07-dualitas-id.pdf` — 445,733 bytes; 21 A4 pages; PDF 1.5; SHA-256 `c4354e1e1366bdb20cebb9c6eca26fba172d6d82a6ad22dd9e2e470da2baeb6e`.
- Final log: `build/habring-unit-07-id/D90-HAB-07-dualitas-id.log` — 105,821 bytes — SHA-256 `795b594b1c78e0a0769fe6b7f292fea0d6ddc81a054cad00a4d857da0cab217d`.
- Final text extraction: `qa/D90-HAB-07-dualitas-id.txt` — 53,128 bytes — SHA-256 `b473c80434a35ec607c6a9b9da3dcc31e3d5a3a233ae1f7da72293a87d65a544`.
- Two forced fixed-epoch final builds reproduced the PDF byte-for-byte.

## Structural and mathematical QA

`python qa/audit_duality_unit.py` passes twice deterministically with zero failures on the exact frozen target. The 36,689-byte script has SHA-256 `4e29ad8cc208ab35f35e8dfc2bb323343977e7badcaed7aa7d8cfa75392cf35b`; its 32,121-byte report has SHA-256 `fd909b00e4274a31c9e9c707cbb9039d5e03233876d0c0094c66c1049802307f`.

- all 148 ordered source environments are preserved;
- all eleven stable segment markers occur in source order;
- all 24 label occurrences are retained, with only the duplicated final source label remapped uniquely and its reference changed in lockstep;
- all 21 `eqref`, 3 `cref`, 1 `Cref`, 9 `ref`, 2 citations, 1 footnote, 9 items, and 5 learner prompts are preserved;
- the source and target have no figure, asset, or included-file surface;
- 254 source and 296 target formula surfaces align into 49 explicit delta blocks, with every one of the 43 substantive blocks bound to an integrated correction event;
- the 81,046-byte formula-delta manifest has SHA-256 `fe72e72d0223117a0b34727d235ced9b6bf2af17cf48154e6b670d2ce75d89fb`.

Independent full-target and final-delta rereviews pass with P1=0, P2=0, P3=0. They confirm the finite-dimensional Hilbert/Riesz convention, conjugacy and biconjugacy repairs, Fenchel--Rockafellar scope, Moreau scaling, primal--dual gap, PDHG update/ergodic proof, and ADMM typing, stationarity, residual, Lyapunov, and objective arguments.

## Computation QA

`python qa/validate_duality_unit.py` passes twice with byte-identical stdout and no stderr. The 45,213-byte validator has SHA-256 `127bed94abe4b506ebd999a46ea71b31457f2f4cc65c7fdd7cd4efcc60569c5b`; its exact 10,830-byte receipt has SHA-256 `9ceeadd90b4868f600241301813a8f24c1d1279690abc8cbf96baa3faf62f3c3`.

The suite checks Fenchel/subdifferential and scaled-Moreau identities; an independent SciPy Fenchel--Rockafellar witness; PDHG one-step inequalities, convergence, metric coefficients, averaging indices, and the zero-operator branch; and ADMM primal/dual residuals, Lyapunov descent, and objective convergence with negative controls. These deterministic witnesses support, but do not replace, the included analytic review.

## Visual, text, and accessibility QA

All 21 pages of the exact final PDF were rendered at 120 dpi and inspected in three contact sheets. Formula-heavy primal--dual/ADMM pages, the correction appendix, and the one repaired proof-heading/list transition were inspected at full size. No clipping, collision, blank page, broken glyph, or unreadable formula was found. The bounded English-residue scan is empty.

The PDF is unencrypted, searchable on every page, and declares `/Lang` as `id-ID`; every embedded font exposes a Unicode mapping. It is not tagged, so accessibility remains `pass_with_limitation`; independent Indonesian language review remains `not_recorded`.

## Toolchain and backend verification

The final log has no LaTeX error, undefined control sequence, unresolved reference or citation, missing glyph, overfull/underfull box, or rerun request. Remaining notices are inherited locale/class/toolchain fallbacks.

`python qa/extend_backend_ch07.py` followed by `python qa/validate_backend.py` passes across two deterministic generation/validation cycles. The five-unit backend has 50 stable translation segments distributed 11/8/8/12/11 across Chapters 3/4/5/6/7. Its exact current record count and JSONL/CSV byte identities are taken from the terminal validator output after all control-file updates, avoiding a self-referential artifact-hash loop. Pre-Chapter-7 semantic records remain unchanged except legitimate current artifact/control hash refreshes.

---

# Habring Chapter 8 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 8 — Stochastic Gradient Descent / Penurunan Gradien Stokastik  
Admission: PASS

## Build inputs and artifact

- Authority: `authority/habring/source-v1/stochastic.tex` — 4,665 bytes — SHA-256 `610d11b59d8dfabbbbe6fbc509a0f9ac1727540458c67f8cd3b7bab49566a07d`.
- Target: `source/id-ID/habring-08-penurunan-gradien-stokastik-id.tex` — 6,378 bytes — SHA-256 `f610aaec91aa9b76582f251458da65d25cc37a933a51da478cad13ee16e5a344`.
- Wrapper: `source/id-ID/D90-HAB-08-penurunan-gradien-stokastik-id.tex` — 5,129 bytes — SHA-256 `d00ea41830af388c227a1054025f049a9315da6f41675573965042d320eb7428`.
- Integrated corrections: `O015-HAB-ADV-0076` through `O015-HAB-ADV-0083`; exact eight-record proposal SHA-256 `a815d0211da31b21a25a3f9fd8a2c1ec5fcc7da5e7a62c980f75df40ae65d45d`.
- Build/output PDF: `output/pdf/D90-HAB-08-penurunan-gradien-stokastik-id.pdf` — 346,785 bytes; 8 A4 pages; SHA-256 `c1ed028667c5df3fd0a837807e2a17bf7a9e1fa3170938853c9a96b9670fa86a`.
- Final log: 98,530 bytes; SHA-256 `59609048d4930761a5de52f05aa65f80cf3da36dc7f64bd624c1ec539e64702c`.
- Final text extraction: `qa/D90-HAB-08-penurunan-gradien-stokastik-id.txt` — 13,751 bytes; SHA-256 `8556e8138248e163bff23d1778e1d2d782d7c0b3bfa6c1c4df5adaed439a05c6`.

Two full builds from `source/id-ID` with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, `latexmk`/pdfTeX, and Biber produced identical PDF bytes.

## Structural, mathematical, and computation QA

`python qa/audit_stochastic_unit.py` passes twice byte-identically with P1=0, P2=0, P3=0. The 29,112-byte script has SHA-256 `d6a201efc1489fd8220510408bb65cf3cb56d5603b130f46287c6ec8f5be905e`; its 12,202-byte report has SHA-256 `d44495208072e4555011dce4cf6155d434bc526574614d2683b8a97484f730dc`.

- all 24 ordered environments and all nonblank source lines are covered by three stable segments;
- the sole label/reference pair and no-citation/no-figure/no-footnote/no-exercise closure are exact;
- 38 source and 61 target formula surfaces align into seven substantive delta blocks, every one bound to the eight integrated correction events;
- the 24,702-byte formula-delta manifest has SHA-256 `2f9632d02071ded0c84d54ca17af019137cecfe18245d94a7e9243449c0e9fe9`.

The independent source/target review found no remaining target defect. It confirms the normalized finite-sum oracle, well-posed projected iteration, conditional filtration/oracle assumptions, exact second-moment identity, consistent best-iterate definition, restored factor, and sharp `S_K`/`Q_K` bound.

`python qa/validate_stochastic_unit.py` passes 24/24 gates twice with byte-identical output. The 18,417-byte validator has SHA-256 `ef05e828b83ab285e5ba090dc27753cd758d5c3e1697f9c138b57bf052a7006e`; its 21,107-byte receipt has SHA-256 `3b78aa1140a08cf811493f37496b10c2955f02bec570385dcde6480f37578f22`.

It verifies the normalized finite-sum mean and missing-`N` negative control; three exact conditional-oracle states and their variance decomposition; metric projection and the one-step recurrence; ten exact-enumeration best-iterate cases under two schedules; and the source's failing extra-`Q_K` asymptotics. The minimum theorem-bound margin is `1/8`. For `tau_k=(k+1)^(-1/5)` at `K=100000`, the correct `Q_K/S_K` term is approximately `0.1332502401`, while the erroneous `Q_K^2/S_K` term is approximately `221.9331877`.

## Visual, text, accessibility, and backend QA

All eight exact final pages were rendered and inspected in a contact sheet; theorem/proof and correction pages were inspected at full size. No clipping, collision, broken glyph, blank content page, or unreadable formula was found. The bounded English-residue scan is empty. The log has no TeX error, unresolved reference, missing glyph, box warning, or rerun request.

The PDF is unencrypted and searchable on every page, declares `/Lang` `id-ID`, and embeds all fonts with Unicode mappings. It remains untagged, so accessibility is `pass_with_limitation`; independent Indonesian language review remains `not_recorded`.

`python qa/extend_backend_ch08.py` followed by `python qa/validate_backend.py` passes across two deterministic generation/validation cycles. The six-unit backend has 53 stable translation segments distributed 11/8/8/12/11/3 across Chapters 3/4/5/6/7/8. Its exact current record count and JSONL/CSV byte identities are taken from the final validator output after all control updates, avoiding a self-referential artifact-hash loop. Pre-Chapter-8 semantic records remain unchanged except legitimate current artifact/control hash refreshes.

---

# Habring Chapter 9 build and QA record

As of: 2026-08-22  
Unit: Habring Chapter 9 — Excursion on Optimal Transport / Selingan tentang Transportasi Optimal  
Admission: PASS

## Build inputs and artifact

- Authority: `authority/habring/source-v1/optimal_transport.tex` — 15,378 bytes / 264 lines — SHA-256 `719df724b368126cc7540dffd461dc33aba7d5b5b6060132181086dfa17649ba`.
- Target: `source/id-ID/habring-09-transportasi-optimal-id.tex` — 21,252 bytes / 352 lines — SHA-256 `45c0eef50b535ffb8722ad74caf4df0bf014f5eebb43d13b24f00639018ca3bd`.
- Wrapper: `source/id-ID/D90-HAB-09-transportasi-optimal-id.tex` — 6,822 bytes / 87 lines — SHA-256 `1e308a2bed0d1a6f5cdcff09cce932674cf32842a135bc88a5a34bc96c483ff6`.
- Corrected unit-local bibliography: `source/id-ID/references-ot-id.bib` — 306 bytes / 9 lines — SHA-256 `93611c4b6a753478c51c601e59ef6cd3e290677e2e2d25b104d5d3b74df03126`.
- Integrated corrections: `O015-HAB-ADV-0084` through `O015-HAB-ADV-0096`; proposed content ledger SHA-256 `643fde3fbe1409732ef2df8fdef52465e4df7a583fd9bbeb2137a6122f548add`.
- Build/output PDF: `output/pdf/D90-HAB-09-transportasi-optimal-id.pdf` — 498,244 bytes / 15 A4 pages — SHA-256 `edc8e17fd43d17a0dd7811879dfbedaab9ac226c291ed5558ca0bfbb3ce10214`.
- Final log: 103,255 bytes — SHA-256 `2b083221c49f6fbdede8f541e68cd9129632a74168d7855c1ddc14c1bf48b3a4`.
- Final text extraction: 30,053 bytes — SHA-256 `283864c3fc84d414ff721f128a0f10e4b61b4646c0f5edcd53551ee13f911859`.

Two fixed-epoch builds from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and `latexmk -gg -pdf`, produced byte-identical PDF files.

## Admission result

The strict audit passes twice: all 47 ordered environments, five labels, native TikZ figure, citation/footnote/glossary surfaces, and every nonblank authority line are preserved in nine stable segments. Its report SHA-256 is `eb8b194c01dd7610dcdb7325322765ab16b3ec9cf907d28f9463fa11692767aa`; the 35-block / 34-substantive formula manifest SHA-256 is `796e13fbf1f221139f0233d30b2464dfb026027eb5b9ce44b66b58c2f2e169ef`. All substantive deltas bind to exact integrated corrections.

The open validator passes 41/41 gates twice. It checks a rectangular 3-by-4 OT primal/dual witness with objective 0.575 and zero gap, Wasserstein-2 squared distance 3, a positive entropic Sinkhorn plan in 27 iterations with maximum marginal residual `3.608224830031759e-15`, factorization/KKT/scaling/strict-convexity witnesses, and four negative controls. Receipt SHA-256: `4f751c615f2d7f03622b1447b3985ad1d660bd4f758cf4c4fb61d4d384b4e7a0`.

All 15 pages were rendered and inspected; formula-heavy pages and the correction appendix were inspected full size. No clipping, collision, blank content page, broken glyph, or unreadable formula remains. The final independent rereview is P1=0, P2=0, P3=0. The PDF is searchable, declares `/Lang` `id-ID`, embeds all fonts with Unicode mappings, and remains untagged. Semantic HTML/EPUB and independent human Indonesian review remain open. Full evidence is in `CHAPTER09_SOURCE_AUDIT.md` (SHA-256 `49f3d61892cf7587281fa3a95525b7f7ae1814223c38fe3de76efc02a193a85b`) and `qa/CHAPTER09_WORKLOG.md` (SHA-256 `0527b8b61dee2ffccd493e8331b7d57f592ba3ec9b5ef87226c15cb1a342e99e`).

`python qa/extend_backend_ch09.py` followed by `python qa/validate_backend.py` passes across two deterministic generation/validation cycles. The seven-unit backend contains 793 records and 62 stable translation segments distributed 11/8/8/12/11/3/9 across Chapters 3/4/5/6/7/8/9; final export identities are emitted by the validator after live control updates.

---

# Penn Chapter 3 build and QA record

As of: 2026-08-22  
Unit: Penn Chapter 3 — Introduction to Gradient Ascent and Line Search Methods / Pengantar Pendakian Gradien dan Metode Pencarian Garis  
Admission: PASS

## Build inputs and artifact

- Authority: `authority/penn-state/source/ClassNotes/Section3.tex` — 41,715 bytes / 608 lines — SHA-256 `d4ae6142e2366b12575eafddc833df067518af114e9816187668cc367be43010`.
- Target: `source/id-ID/penn-03-pendakian-gradien-dan-pencarian-garis-id.tex` — 44,364 bytes / 646 lines — SHA-256 `7c75d0ae56a5a912d561d91ece607f088a4ff4f3de4dbc3396ce40d6d7d6a229`.
- Wrapper: `source/id-ID/D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.tex` — 8,203 bytes / 192 lines — SHA-256 `0876d121d417ef4f73f308eac62056a55499628af44713e06246315852dcfa38`.
- Bundled-bibliography excerpt: `source/id-ID/references-penn-ch03-id.bbl` — 852 bytes / 25 lines — SHA-256 `d3e645c03298c14fee272d44b5d471a81d31aec60a95d4f568b4923edde63867`.
- Integrated corrections: `O015-PENN-ADV-0004` through `O015-PENN-ADV-0024`; proposal SHA-256 `80aa5a3f7b4f46c7dfe01f58f6f68555c9aeaeb91d0877eaf27cbb447c4a67fa`.
- Build/output PDF: `output/pdf/D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.pdf` — 515,851 bytes / 20 A4 pages — SHA-256 `e1be82d06572c51b403608cd9595cc5adf2dc64cfa93f53001eba94e48f77e3e`.
- Final log: 27,077 bytes / 697 lines — SHA-256 `2702aa4b756fec32557368a144ddfe9a91f32363e034cefea9956034178a74f6`.
- Final text extraction: 47,464 bytes / 828 lines — SHA-256 `9880848f06e2f1104a88213f3a9f7629db87c6cc8bf0b515281cf553ed1895bc`.

Two complete builds from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and `latexmk -gg -pdf`, produced byte-identical PDF files. The final log has no TeX error, undefined control sequence, unresolved reference/citation, missing glyph, overfull/underfull box, or rerun request. The only retained log notice is an OT1 bold-small-caps font substitution; direct inclusion of the frozen bibliography excerpt produces an expected terminal-only latexmk notice.

## Structural, mathematical, and computation QA

`python qa/audit_penn_ch03_unit.py` passes twice byte-identically. All 142 ordered environments, 35 labels, 37 unique reference targets, nine citations, four figure calls, twelve exercises, and all 608 authority lines in eight segments close exactly. The 499 source and 570 target math records align into 230 canonical-equal pairs and 89 delta blocks, with zero unbound blocks and zero unknown correction bindings. The report SHA-256 is `97af8d897decb2aac58355d97cf65898c1396e18c08deca5e1e8834a6b49d588`; the formula-manifest SHA-256 is `af04268dddc2cc3b74ccfe775967673bcfebab911d5d298c61df2a5a68ff653c`. Independent final rereview is P1=0, P2=0, P3=0.

`python qa/validate_penn_ch03_unit.py` passes 31/31 checks twice, including eleven negative controls. It validates bracketing, dichotomy, golden-section evaluation reuse/contraction/plateau failure, bisection, strong-concavity distance control, quartic extrema, Newton curvature/sign/failure cases, and exact local convergence-rate behavior. Result SHA-256: `dcf133cf7ca8aefebb3193711c8ceb1b719d9756b15778971572f1762e6b0565`.

## Visual, text, and accessibility QA

All 20 final pages were rendered at 120 dpi and inspected in a 4-by-5 contact sheet; the title/about/contents pages, Newton-rate page, bibliography, correction appendix, and attribution page were inspected full size. No blank page, clipping, collision, broken glyph, or unreadable formula remains. The title was reflowed manually to remove the non-content blank verso produced by the default book title machinery.

The PDF is A4/PDF 1.5, unencrypted, searchable on every page, declares `/Lang` `id-ID`, exposes six outlines, and has no form fields, widgets, or JavaScript. It is untagged. Nineteen reader fonts expose Unicode maps; eighteen embedded font resources inside the four inherited vector figures do not. Accessibility therefore passes with an explicit limitation; independent Indonesian language review remains unrecorded.

Full authority, rights, closure, and admission evidence is in `PENN_CH03_SOURCE_AUDIT.md`. Semantic HTML/EPUB, interactive computation, and the independent solution/mastery layer remain open.

`python qa/extend_backend_penn_ch03.py` followed by `python qa/validate_backend_penn_ch03.py` passes across two deterministic generation/validation cycles. The canonical backend now has 973 records and 70 stable translation segments. The Penn extension adds 180 records: 17 artifacts, four assets, 14 concepts, 21 corrections, two editions, 19 learning surfaces, 12 QA events, 59 relations, one resource, seven rights records, eight segments, 14 terms, and two units. JSONL: 718,846 bytes, SHA-256 `77fe247050077fda23c9a0bb2aa9c329f7c72d2e2e5f4b8890956b9df32343ec`; lossless CSV: 860,463 bytes, SHA-256 `5fe10a172f5abd9b847cf99c71620c02c460649d531537dbd61283a2c2d7f0cf`.

The 698-record Habring semantic baseline is unchanged at record-set SHA-256 `41fd7e0f51828f4c70f9f56a8ab424ad1ee944bb3f02ba5a654ff059bbeab878`. Ninety-four immutable baseline artifact records remain unchanged. The sole enumerated baseline refresh is `artifact.o015.adverse-ledger`, updated from the pre-admission 99-record ledger to the live 120-record identity; the refreshed 793-record baseline set has SHA-256 `7588bdc2e110564bd420e5bcf7bd1737b3f91dd50eabfa213eaa12fa757bfe4f`. Validation returns zero errors.

---

# Penn Chapter 4 build and QA record

As of: 2026-08-22  
Unit: Penn Chapter 4 — Approximate Line Search and Convergence of Gradient Ascent / Pencarian Garis Hampiran dan Konvergensi Pendakian Gradien  
Admission: PASS

## Build inputs and artifact

- Authority: `authority/penn-state/source/ClassNotes/Section4.tex` — 34,684 bytes / 469 lines — SHA-256 `76113034709b5914fa920076f2e882ccf30157e78ce5bdf4593a5d39af1886d5`.
- Target: `source/id-ID/penn-04-pencarian-garis-hampiran-dan-konvergensi-id.tex` — 33,313 bytes / 613 lines — SHA-256 `c5c0f09d38454177e61c2a97c9beef07771d5f4f715cc7a4a81a871ff54ced8f`.
- Wrapper: `source/id-ID/D90-PENN-04-pencarian-garis-hampiran-dan-konvergensi-id.tex` — 8,018 bytes / 187 lines — SHA-256 `b40ac7e4e1ee69afd0f7f82dbfc9042c6df79c1aaf2ccca78ec9e639b2030edc`.
- Bundled-bibliography excerpt: `source/id-ID/references-penn-ch04-id.bbl` — 625 bytes / 16 lines — SHA-256 `037e62878f1a562314a33054da8f4df4e49c029bbad31c2ec75066cd3e1a99f3`.
- Integrated corrections: `O015-PENN-ADV-0025` through `O015-PENN-ADV-0037`; proposal SHA-256 `fa9c5c0b097b7349a959ca6c1c9c797fc0ed2ea61e91148badec62bb239b7bbd`.
- Build/output PDF: `output/pdf/D90-PENN-04-pencarian-garis-hampiran-dan-konvergensi-id.pdf` — 847,350 bytes / 17 A4 pages — SHA-256 `c0f283aa7d70eba05de6a35c98bc0aa55f3177ab40702bf7eed5de45a7b6ab8a`.
- Final log: 27,564 bytes / 706 lines — SHA-256 `f247633a55e47a6fc002899bc9dbd24128f0949e39cc2954f78164411c301174`.
- Final text extraction: 26,421 bytes / 845 lines — SHA-256 `3ee30d8a4948910d40d8f61bec87a8e36e29f1934c6000dab1d9a8c96f5e518f`.

Two complete builds from `source/id-ID`, with `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and `latexmk -gg -pdf`, produced byte-identical PDF files. The final log has no TeX error, undefined control sequence, unresolved reference/citation, missing glyph, overfull/underfull box, or rerun request. The only retained log notice is an OT1 bold-small-caps font substitution; direct inclusion of the frozen bibliography excerpt produces an expected terminal-only latexmk notice.

## Structural, mathematical, and computation QA

`python qa/audit_penn_ch04_candidate.py` passes twice byte-identically. All 112 ordered environments, 32 labels, 66 displayed-formula pairs, 52 source reference calls and complete target closure, four citations, five figure calls, four exercises, and all 469 authority lines in seven segments pass 22 fail-closed gates. Twenty-six determined formula pairs bind to all 13 corrections. The report SHA-256 is `c43e0195fc7da99590efd17b83ace3ca6a5721bc5156e86d2121a877b85e2c0a`; the formula-manifest SHA-256 is `fe7aa0bbd5cab4ff50cdf855a3bcf3c73f6ad0e007e2ce2033369cf54ed4a65e`. Independent final rereview found and fixed one P3 capture-theorem wording defect and finishes with P1=0, P2=0, P3=0.

`python qa/validate_penn_ch04_math.py` passes 12/12 checks twice. It validates ascent-form Wolfe signs and negative controls, finite Armijo backtracking, the failure recurrence, deterministic Kantorovich/exact-ascent witnesses, the corrected quadratic matrix/condition factor, and eventual unit-step/superlinear Newton behavior. Script SHA-256: `6f2ebf4a462043d327b5eb8c7e238808b6098aea2c193eab66cfa43794cd4bc4`; result SHA-256: `44c2b1a2509775e182e38b125f6c25ca49eb2f7e23e68ec2fce6878bf7704dd2`.

## Visual, text, and accessibility QA

All 17 final pages were rendered at 130 dpi and inspected in a four-column contact sheet; title, figure, algorithm, proof, correction, and rights pages were inspected full size. The source's two forced `[p]` algorithm floats initially created an otherwise mostly empty algorithm page; changing only their placement to `[htbp]` reflowed both boxes with their surrounding proof and example. The final reader has no blank page, clipping, collision, broken figure, or unreadable formula. Exact evidence is in `qa/PENN_CH04_VISUAL_QA.json`, SHA-256 `e700d08476f7aaa018ca31687d2eea2e8a50729599f760d300dd5b6f89211e70`.

The PDF is A4/PDF 1.5, unencrypted, searchable on all 17 pages, declares `/Lang` `id-ID`, exposes six outlines, and has no forms or JavaScript. It is untagged. Of 36 font resources, 26 expose Unicode maps and ten inherited vector-figure resources do not. Accessibility therefore passes with an explicit limitation; independent Indonesian language review remains unrecorded.

Full authority, rights, closure, and admission evidence is in `PENN_CH04_SOURCE_AUDIT.md`. Semantic HTML/EPUB, interactive computation, and the independent solution/mastery layer remain open.

## Backend admission

`python qa/extend_backend_penn_ch04.py` followed by `python qa/validate_backend_penn_ch04.py` passes across two byte-identical cycles. The nine-unit backend contains 1,128 records and 77 stable translation segments. Penn Chapter 4 adds 155 records and seven segments; its record-set SHA-256 is `b956955faee9f9f41b1212952d5c76c6d0eea2f30b33e4881198e48e8a409714`. The stabilized 973-record baseline has record-set SHA-256 `a53d556fe87bab226e120d7df3611b15e38cabb3defb19e850d481dd72058f9c`; its 861 semantic records remain `e20bb942a17185bfcabbc0e0377ce3608697530162664ebe06fba4400ec706a9`, and its 109 non-refreshed artifacts remain `0694bc4785d8712429c783002f0940d61c3832c32de8b8fc5fc436c128ca21e1`. Only `artifact.o015.adverse-ledger`, `artifact.o015.component-rights`, and `artifact.o015.coverage-overlap` are authorized live-binding refreshes.

Final JSONL: 829,770 bytes, SHA-256 `d378b1fcaf46fc83076a9961da16ff96d5f50e22912ede054be923a6bd389650`. Final lossless CSV: 994,096 bytes, SHA-256 `b36ecc26c8080786d6f0eacd3d3af7ffb6bbf81151400b561853751b72cc34df`. The 65,190-byte extension script has SHA-256 `f1e8f13c48bf5b76f0eb0212190ebe247a7ab40a11100dade9ba0fcacdc7ae14`; the 34,749-byte validator has SHA-256 `a56508efbd0b84f485b3fecaec77df41fb5410657a2c89bdf1a2676e4e79f15b`. Validation returns `errors=[]`.

---

# Penn Chapter 5 build and QA record

As of: 2026-08-22  
Unit: Penn Chapter 5 — Newton's Method and Corrections / Metode Newton dan Koreksinya  
Admission: PASS; optional Penn/Habring companion boundary frozen after this unit

## Build inputs and artifact

- Authority: `authority/penn-state/source/ClassNotes/Section5.tex` — 22,371 bytes / 317 lines — SHA-256 `15186b99be0913d83046e3e32eaf7a378d3a4fccd222219984b091ddf7f9a428`.
- Target: `source/id-ID/penn-05-metode-newton-dan-koreksi-id.tex` — 27,317 bytes / 400 lines — SHA-256 `0f6afd7da2268661124f967f299ac9df89bb6a8f5683b3e4e8fea32718a8549a`.
- Wrapper: `source/id-ID/D90-PENN-05-metode-newton-dan-koreksi-id.tex` — 7,230 bytes / 175 lines — SHA-256 `82450c4cdbe6de904c7cba1ee22922869f5d2e2caf19be69285092a5ea987e55`.
- Bibliography excerpt: `source/id-ID/references-penn-ch05-id.bbl` — 625 bytes / 16 lines — SHA-256 `037e62878f1a562314a33054da8f4df4e49c029bbad31c2ec75066cd3e1a99f3`.
- Integrated corrections: `O015-PENN-ADV-0038` through `O015-PENN-ADV-0049`; all twelve proposed records are byte-identically appended to the live adverse ledger.
- Final PDF: `output/pdf/D90-PENN-05-metode-newton-dan-koreksi-id.pdf` — 2,691,780 bytes / 15 A4 pages — SHA-256 `427db2c5a4428dfbe222d7e1d4f5c5349d4f78484a8593c412328fe94a7353c6`.
- Canonical log: 27,062 bytes / 700 lines — SHA-256 `bb3e9416233d14400ced235b69eeb95f76e6347dfeabbfd2c06727b543aed8be`.
- Extracted text: 29,195 bytes / 541 lines — SHA-256 `78fc7ecf877b7707c6c33736210449d502bbc148b84994b65b0d2fc4791365d3`.

Two complete fixed-epoch builds produced byte-identical PDFs. The canonical log contains no TeX error, undefined reference or citation, overfull box, missing glyph, or rerun request; one contained underfull caption warning is accepted.

## Structural, mathematical, computation, and rights QA

The final structural audit passes twice and preserves all 84 ordered environments, all ten labels, all five exercises, the sole citation, four figure calls, the exact 35 displayed-formula sequence, the complete reference closure, and every source line in seven gap-free segments. `qa/PENN_CH05_STRUCTURE_REPORT.json` is 26,392 bytes, SHA-256 `89757169df04a17c4e19bb72469aa6cd5ebb094e4c1298e3b8b78b44b3d9146a`.

The independent rereview raised and resolved one P2 and three P3 findings and closes at P1=0, P2=0, P3=0. Its 9,373-byte receipt has SHA-256 `239e4d79f90c570ac95ceb22cab097b41980c308abb39f940fe66dbc5f7861dd`.

The deterministic SymPy 1.13.1 validator passes all seven gates twice. It reconstructs the quartic Newton map, the double-peak stationary set and failed pure-Newton ascent direction, the corrected modified-Cholesky factor and solves, spectral bounds, and a local Q-quadratic witness. `qa/PENN_CH05_SOLVER_RESULTS.json` is 6,242 bytes, SHA-256 `9c5905c0022a1a99f8064484cff40abff0b9435df133822b5e16fc2b0ac6401f`. No excluded Maple code is executed.

The four Penn vector figures are retained byte-exactly. Five Maple/legacy listings remain excluded because their component rights are unclear/external; their reader roles are replaced by three independently authored, separately registered pseudocode surfaces. Penn-derived text/figures remain CC BY-NC-SA 3.0 US; original bridges are separately identified inside the combined NC-SA derivative.

## Visual and accessibility QA

All 15 pages were inspected in a contact sheet; pages 4, 5, 9, 10, 11, 12, and 14 were inspected at full size. No blank content page, clipping, collision, broken figure, unreadable glyph, or stranded algorithm page remains. The exact 2,687-byte visual receipt has SHA-256 `3130aee988a10cf4fc4c2b3cfbdc494293142519c0c416d603a109704188bde4`.

The PDF is A4/PDF 1.5, unencrypted, searchable on all 15 pages, declares `/Lang` `id-ID`, exposes six outlines, has no forms or JavaScript, and all 137 font resources expose Unicode maps. It remains untagged; semantic HTML/EPUB and independent human/native-speaker Indonesian review remain open.

## Backend admission

Root independently reran `python qa/extend_backend_penn_ch05.py` and `python qa/validate_backend_penn_ch05.py` after the producing agent's clean cycles, then repeated the transaction after the authorized architecture/rights/coverage refresh. The terminal two cycles are byte-identical and validation returns `errors=[]`.

The ten-unit companion backend contains 1,283 records and 84 stable segments. Chapter 5 adds 155 records in seven contiguous source/target mappings and has terminal record-set SHA-256 `979ec311c13ac368e7950bb734d4240310dec154d3e8151b042ed82333cb78c8`. The 1,128-record incoming baseline is unchanged after the three enumerated live-control refreshes and has record-set SHA-256 `23ffc42f0fa6b19a828154db74bdda2a0fa99e860f7615c918f4c7a3787f2edb`; its 999 semantic records have SHA-256 `971333c796eeb036b59cc1ff5ce6c0ce5bfa2836e5ab4d7f4176d4aeea0b5d97` and its 126 immutable artifact records have SHA-256 `68c89eb4dd196935f8b60d9f3eccc32a4ae61530503d189bb4ca3903bd9061c0`.

Final JSONL: 942,447 bytes, SHA-256 `e57a457d20edfcf772f38f7dd9dfdd3368530d785bbf5b71179b90784b8130f9`. Final lossless CSV: 1,129,757 bytes, SHA-256 `e2ca8f3b58dc74e208a579ff1b55997d0e5e202f49c2b018edce6358b7492c2f`. The 67,831-byte extension script has SHA-256 `d06a5149cdf6e08588cf20a586b7418e7244c189f2f4e8c06e8082cc75b1f1b9`; the 38,114-byte validator has SHA-256 `f89dfcb19a2febc15d44b75ed9894ed348861632db35b66a371843457e5e0ab6`.
