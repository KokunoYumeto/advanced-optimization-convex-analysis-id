# Chapter 8 production worklog

Status: COMPLETE CANDIDATE - awaiting root admission/review

Scope is strictly Habring Chapter 8. This worklog does not admit the unit into
shared controls, modify the backend, promote a PDF to output/pdf, use Git,
publish, or contact the author.

## Frozen authority and closure audit

The sole chapter authority is
authority/habring/source-v1/stochastic.tex from Andreas Habring, Lecture Notes:
Convex Optimization, arXiv:2607.11664v1 (13 July 2026), under CC BY 4.0.

- Authority bytes: 4,665.
- Authority physical lines: 107.
- Authority SHA-256:
  610d11b59d8dfabbbbe6fbc509a0f9ac1727540458c67f8cd3b7bab49566a07d.
- Chapter title: Stochastic Gradient Descent.
- Chapter-local closure: no figures, external assets, citations, bibliography
  references, footnotes, exercises, solutions, hints, or executable
  interactives. The one informal reader check concerning unbiasedness is
  retained and made explicit by the displayed finite-sum calculation.
- Dependency surface: convex subgradients and the subgradient inequality;
  Euclidean projection onto a nonempty closed convex set and its
  nonexpansiveness; Lipschitz/subgradient norm bounds; conditional expectation,
  conditional variance, filtrations, and elementary telescoping estimates.
  These are stated as prerequisites in the standalone wrapper rather than
  silently importing prior chapters.

The authority has exactly 24 begin and 24 end environments in this sequence:
six opening equation-level environments (one containing cases), theorem,
equation containing cases, proof, and the remaining proof equations/aligned
blocks. Aggregated counts are 15 equation, five aligned, two cases, one
theorem, and one proof. It has one label
(stochastic:eq:gradient), one matching eqref, and zero plain refs, citations,
footnotes, items, or figures.

The complete source partition is:

- H08-S001: authority lines 1--34 - motivation, normalized finite-sum model,
  component-gradient sampling, and unbiasedness.
- H08-S002: authority lines 36--50 - projected-SGD convergence theorem and its
  stochastic/step-size assumptions.
- H08-S003: authority lines 51--107 - projection recursion, conditional
  expectation estimates, telescoping, and best-iterate convergence.

The target carries the corresponding canonical markers
d90.hab.v1.ch08.seg0001 through d90.hab.v1.ch08.seg0003.

## Complete Indonesian production

The contiguous id-ID translation preserves all source-order prose,
mathematics, algorithmic surfaces, theorem/proof structure, and the sole
label/reference pair. Its environment sequence is byte-independently parsed
and exactly equal to the authority sequence: 24 begin and 24 end environments,
including all 15 equations, five aligned blocks, two cases blocks, one theorem,
and one proof. All references resolve, and a bounded English-residue scan found
only the source label name and LaTeX environment names.

- source/id-ID/habring-08-penurunan-gradien-stokastik-id.tex:
  6,378 bytes; 133 physical lines; SHA-256
  f610aaec91aa9b76582f251458da65d25cc37a933a51da478cad13ee16e5a344.
- source/id-ID/D90-HAB-08-penurunan-gradien-stokastik-id.tex:
  5,129 bytes; 69 physical lines; SHA-256
  d00ea41830af388c227a1054025f049a9315da6f41675573965042d320eb7428.
  The wrapper gives exact source identity, attribution, CC BY 4.0 terms,
  change notice, non-endorsement, prerequisites, Indonesian metadata, and a
  transparent corrections appendix.
- qa/CHAPTER08_PROPOSED_LEDGER.jsonl:
  5,188 bytes; eight valid unique JSONL records O015-HAB-ADV-0076 through
  O015-HAB-ADV-0083; SHA-256
  a815d0211da31b21a25a3f9fd8a2c1ec5fcc7da5e7a62c980f75df40ae65d45d.
  Root subsequently merged these exact records into the shared adverse ledger;
  repeated structural validation confirms their validity and complete formula-
  delta binding.

The eight transparent correction classes are: finite-sum normalization for
uniform-sampling unbiasedness; the missing convex/projected-SGD well-posedness
hypotheses and algorithm; conditional filtration/oracle assumptions; the
undefined best-iterate quantity and inconsistent indices; the incorrect
unconditional second-moment manipulation; the missing factor one-half in the
summed estimate; the invalid sigma_n algebra and incomplete asymptotic
conditions; and three determined notation/prose defects. The repaired theorem
uses S_K=sum tau_k and Q_K=sum tau_k squared and proves

    E[f_best^K-f(x*)] <= ||x0-x*||^2/(2 S_K) + M^2 Q_K/(2 S_K),

which tends to zero under S_K tending to infinity and Q_K/S_K tending to zero.
No unresolved mathematical uncertainty remains in this bounded chapter.

## Reproducible standalone build and QA

The standalone wrapper was built twice from source/id-ID with fixed
SOURCE_DATE_EPOCH=1783900800, FORCE_SOURCE_DATE=1, TZ=UTC, and:

    latexmk -gg -pdf -interaction=nonstopmode -halt-on-error
      -file-line-error -outdir=<absolute build/habring-unit-08-id path>
      D90-HAB-08-penurunan-gradien-stokastik-id.tex

Both clean builds exited successfully and independently produced the same PDF
bytes and SHA-256.

- build/habring-unit-08-id/D90-HAB-08-penurunan-gradien-stokastik-id.pdf:
  346,785 bytes; eight A4 pages; PDF 1.5; SHA-256
  c1ed028667c5df3fd0a837807e2a17bf7a9e1fa3170938853c9a96b9670fa86a.
- build/habring-unit-08-id/D90-HAB-08-penurunan-gradien-stokastik-id.log:
  98,530 bytes; 2,414 physical lines; SHA-256
  59609048d4930761a5de52f05aa65f80cf3da36dc7f64bd624c1ec539e64702c.
- build/habring-unit-08-id/D90-HAB-08-penurunan-gradien-stokastik-id.txt:
  13,751 bytes; 263 physical lines; SHA-256
  8556e8138248e163bff23d1778e1d2d782d7c0b3bfa6c1c4df5adaed439a05c6.

The final log has zero undefined controls or references, multiply defined
labels, overfull or underfull boxes, missing characters, fatal/emergency
errors, or rerun requests. Remaining package notices are the same benign
environment-level notices seen in adjacent units: Perl locale fallback,
obsolete xcolor option, KOMA/tocloft advisory, and missing Indonesian
localization modules with package fallbacks.

PDF inspection reports the exact Indonesian title and author, /Lang=id-ID,
eight A4 pages, no encryption, no forms or JavaScript, embedded/subset fonts
with Unicode mappings, and searchable text (7,869 characters through an
independent pypdf extraction). The source toolchain does not emit a tagged PDF;
semantic HTML/EPUB accessibility therefore remains a later corpus-level
surface rather than a claim of this standalone PDF.

All eight pages were rendered at 150 dpi and inspected individually. The title
and provenance page, unit note, contents page, complete chapter, correction
appendix, and attribution page have no clipping, overlap, broken glyphs,
unreadable formulas, blank content pages, or margin/footer collisions. The
latest rendered bytes correspond exactly to the frozen PDF hash above.

Terminal state for this bounded task: COMPLETE CANDIDATE. Root may now perform
independent mathematical/content review, merge the proposed ledger if admitted,
extend shared controls/backend, and decide promotion. No output/pdf copy,
shared-control mutation, Git operation, publication, or upstream contact was
performed here.

## Post-candidate root admission

Root's independent source/target review, twice-repeated structural/formula
audit, twice-repeated 24-gate stochastic validator, exact all-page visual
inspection, and text/font/language checks all passed. Root copied the frozen PDF
byte-for-byte to `output/pdf/D90-HAB-08-penurunan-gradien-stokastik-id.pdf`,
copied the exact text extraction into `qa`, integrated events 0076--0083, and
updated the Chapter 8 source, rights, build, state, cursor, and decision
controls. No Git, external publication, or upstream contact occurred in the
restricted turn.
