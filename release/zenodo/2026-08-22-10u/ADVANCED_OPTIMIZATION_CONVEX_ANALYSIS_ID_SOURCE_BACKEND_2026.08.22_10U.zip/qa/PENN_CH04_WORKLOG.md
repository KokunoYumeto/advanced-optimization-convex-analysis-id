# Penn Chapter 4 production worklog

Status: ADMITTED READER — complete translation, independent mathematical
rereview, standalone deterministic build, visual/accessibility QA, adverse
ledger integration, and rights/control closure pass. Backend integration is
being finalized separately without changing the admitted reader bytes.

This bounded pass translated the complete Penn State MATH 555 `Section4.tex`
in source order. It created only the Indonesian fragment, five exact figure
copies, a proposed correction ledger, this worklog, a source-audit draft, and
bounded QA scripts/results. It did not edit Chapter 3, any wrapper, shared
controls, the backend, rights tables, authority files, or publication surfaces.
It did not run Git, publish, or contact upstream.

## Frozen authority and cursor

The text authority is Christopher Griffin, *Nonlinear Programming*, Penn State
MATH 555 editable source v1.0, authority identity
`o015-penn-math555-v1.0-source`, licensed CC BY-NC-SA 3.0 US. The derivative
must preserve attribution and a change notice, remain noncommercial, use the
same license, link the license, and avoid implied endorsement. The lane’s
frozen authority record identifies the public v1.0.1 PDF as the correction
witness for the missing closing norm delimiter in the capture theorem; the
editable source remains unchanged.

| Component | Bytes | Lines | SHA-256 |
|---|---:|---:|---|
| `authority/penn-state/source/ClassNotes/Section4.tex` | 34,684 | 469 | `76113034709b5914fa920076f2e882ccf30157e78ce5bdf4593a5d39af1886d5` |
| `source/id-ID/penn-04-pencarian-garis-hampiran-dan-konvergensi-id.tex` | 33,313 | 613 | `c5c0f09d38454177e61c2a97c9beef07771d5f4f715cc7a4a81a871ff54ced8f` |

The source title is “Approximate Line Search and Convergence of Gradient
Ascent”; the Indonesian title is “Pencarian Garis Hampiran dan Konvergensi
Pendakian Gradien.” The candidate reaches physical source line 469, the exact
EOF. Its seven stable source partitions are:

- P04-S001 / `d90.penn.v1.ch04.seg0001`: lines 1–74, Wolfe conditions and
  worked radial example;
- P04-S002 / `d90.penn.v1.ch04.seg0002`: lines 75–124, Wolfe existence and
  Armijo backtracking;
- P04-S003 / `d90.penn.v1.ch04.seg0003`: lines 125–206, gradient-related
  directions and stationarity;
- P04-S004 / `d90.penn.v1.ch04.seg0004`: lines 207–243, convergence failure
  and capture theorem;
- P04-S005 / `d90.penn.v1.ch04.seg0005`: lines 244–331, exact-gradient rate
  and Kantorovich inequality;
- P04-S006 / `d90.penn.v1.ch04.seg0006`: lines 332–363, independent
  gradient-ascent pseudocode and quadratic example;
- P04-S007 / `d90.penn.v1.ch04.seg0007`: lines 364–469, eventual unit steps
  and superlinear convergence.

The next unstarted source-order cursor is
`authority/penn-state/source/ClassNotes/Section5.tex:1`, “Newton’s Method and
Corrections”: 22,371 bytes, 317 physical lines, SHA-256
`15186b99be0913d83046e3e32eaf7a378d3a4fccd222219984b091ddf7f9a428`.

## Reader closure and dependency decisions

The candidate represents all source-order prose, 66 displayed formula
environments, 112 ordered live environments, 32 labels, every unique source
reference target, the four-entry citation sequence, five figure calls, and all
four exercises. It preserves the chapter’s internal identifiers. Six labels
that followed inner numbered content were moved ahead of that content so they
bind to their owning definition, lemma, theorem, or example; their strings did
not change.

Nine chapter-external references remain for the eventual Penn wrapper/main
closure. The bundled `Math555.aux` (62,603 bytes, SHA-256
`a809aa76c780221a8c03a271c790b21529fe4bb49b4860cfe8c22ab593a71b16`)
resolves them as follows:

- `prop:DirecDeriv` 1.20; `thm:DirDeriv` 1.22;
- `thm:MVT` 2.2; `thm:MVT2` 2.4;
- `def:AscentDir` 3.2; `lem:AscentDirection` 3.8;
- `alg:ModifiedGradientAscent` Algorithm 2; `alg:Bracket` Algorithm 3;
- `alg:GoldenSearch` Algorithm 5.

The only citation key is `Bert99`, repeated four times. Its exact bundled
entry remains in `Math555.bbl` and already occurs in the bounded five-entry
excerpt `source/id-ID/references-penn-ch03-id.bbl` (852 bytes, SHA-256
`d3e645c03298c14fee272d44b5d471a81d31aec60a95d4f568b4923edde63867`).
The bibliography databases remain absent; no metadata was invented here.

Five source figure assets were copied byte-for-byte into `source/id-ID/figures`:

| Asset | Bytes | SHA-256 |
|---|---:|---|
| `ThreeDCos.pdf` | 234,150 | `e14dc949d3fd7cd7d0593f0352567aa9ac6e66423886113929df9c7feb2eace5` |
| `WolfePhiOfT.pdf` | 16,923 | `221447efe0da804b341570bf3877c842199dd6052b7029eb70cf2edf1aab9a09` |
| `WolfeConditionsIllustrated.pdf` | 163,565 | `b3d2c7c62a79e6bf74ec62089afc773f631f1c62d67e2f8bfd58fb4a078796ec` |
| `ConvergenceFailure.pdf` | 11,302 | `fc5f89515414dcbc704e718e6de62b0bb15785b645bd669c98254dd058a16836` |
| `GradientAscentOut.pdf` | 110,472 | `31cdba8ed1818564289fba9c2c279b48cd0bddc347097261ae8df572953eecc4` |

The three legacy listing calls point to `BackTrace.mpl` (361 bytes, SHA-256
`cd0604aaa19b7ecbaef8358a9a6d9d3516b6f6aa9b068e983ff5a180c1b4a09d`),
`GradientAscent-1.mpl` (1,467 bytes, SHA-256
`bd9c2521846c183de5c7b2d00af23c828742fb0c6c7301b16cb09794e0cdf8ec`),
and `GradientAscent-2.mpl` (866 bytes, SHA-256
`a27c3ee087e55986ad6a938208e63b9ef0b29d101846be12dabc7f087a796824`).
The rights table excludes Penn Maple/legacy code because its component rights
are unclear or external. No listing text or syntax was copied. Each executable
surface was replaced in place by independently authored locale-neutral
pseudocode with explicit inputs, state updates, stopping behavior, and return
contract. That bridge needs a separate lane-authored component-rights entry at
admission.

## Mathematical corrections

The proposed ledger is `qa/PENN_CH04_PROPOSED_LEDGER.jsonl`: 10,055 bytes,
13 records/lines, SHA-256
`fa9c5c0b097b7349a959ca6c1c9c797fc0ed2ea61e91148badec62bb239b7bbd`.
Its unique IDs are exactly `O015-PENN-ADV-0025` through
`O015-PENN-ADV-0037`; all 13 now form the exact final tail of the shared
adverse ledger.

The determined changes correct the shifted-gradient chain rule and curvature
interpretation; vectorize the two-dimensional line path; state the missing
Wolfe regularity and upper-bound hypotheses; replace excluded Maple surfaces;
restrict the stationarity theorem to the backtracking rule its proof actually
uses; repair the limsup/subsequence and limit arguments; add finite-attainment,
iterate-convergence, and uniform spectral hypotheses to the corollaries; fix
the failure-example index; restore the capture-theorem norm delimiter; separate
spectral condition number from convergence factor; fix the endpoint and
lambda-index algebra in the Kantorovich proof; use the correctly scaled
quadratic matrix; state the complete Newton direction; and make the eventual
unit-step proof uniform over varying normalized directions.

## Bounded QA

`qa/audit_penn_ch04_candidate.py` (33,499 bytes, SHA-256
`aec0ca750c3de504f5c6f8b9a95217c1d5cda2111a5a697442caadaae952c256`)
passes twice with a byte-identical report:
`qa/PENN_CH04_STRUCTURE_REPORT.json` (39,127 bytes, SHA-256
`c43e0195fc7da99590efd17b83ace3ca6a5721bc5156e86d2121a877b85e2c0a`).
The report proves the exact 112-environment ordered topology and counts, all
32 labels exactly once, every unique source reference target, exact citation
and figure sequences, four exercises, all seven source-line segments without
gap or overlap, an exact 66-entry displayed-formula environment sequence,
balanced TeX environments/braces, no legacy listing dependency, all 13 ledger
records, and exact figure bytes.

The formula-delta manifest contains 66 ordered pairs and binds all 26
determined pairs to the 13 events; its SHA-256 is
`fe7aa0bbd5cab4ff50cdf855a3bcf3c73f6ad0e007e2ce2033369cf54ed4a65e`.
The deterministic open numerical validator
`qa/validate_penn_ch04_math.py` (13,339 bytes, SHA-256
`6f2ebf4a462043d327b5eb8c7e238808b6098aea2c193eab66cfa43794cd4bc4`)
passes all 12 gates twice. Its 5,523-byte result has SHA-256
`44c2b1a2509775e182e38b125f6c25ca49eb2f7e23e68ec2fce6878bf7704dd2`.
It checks ascent-form Wolfe signs and negative controls, Armijo termination,
the closed recurrence and alternating limits, deterministic
Kantorovich/exact-ascent witnesses, the corrected `diag(-4,-20)` matrix with
condition number 5 and factor 2/3, and eventual unit-step/superlinear Newton
behavior on a smooth strictly concave witness.

## Final admission evidence

The independent reread found and fixed one P3 wording defect in the capture
theorem and ended with P1=0, P2=0, P3=0. The admitted wrapper is 8,018 bytes /
SHA-256 `b40ac7e4e1ee69afd0f7f82dbfc9042c6df79c1aaf2ccca78ec9e639b2030edc`.
Two fixed-epoch builds are byte-identical. The final 17-page A4 PDF is 847,350
bytes / SHA-256
`c0f283aa7d70eba05de6a35c98bc0aa55f3177ab40702bf7eed5de45a7b6ab8a`;
its canonical log contains no TeX/reference/citation/box/glyph/rerun blocker.
All pages were rendered and inspected. Two forced `[p]` algorithm placements
were reflowed to `[htbp]`, removing the algorithm-only page without altering
topology. Searchability, `/Lang id-ID`, absence of forms/JavaScript, and the
untagged/inherited-font limitations are frozen in
`qa/PENN_CH04_VISUAL_QA.json`. Section 5 production has begun in a separate
source-order pass; it does not change Chapter 4 admission.
