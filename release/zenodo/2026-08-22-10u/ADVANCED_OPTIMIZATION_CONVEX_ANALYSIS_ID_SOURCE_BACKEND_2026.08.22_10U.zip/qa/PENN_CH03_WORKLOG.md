# Penn Chapter 3 production worklog

Status: ADMITTED  
Date: 2026-08-22  
Cursor after this unit: `authority/penn-state/source/ClassNotes/Section4.tex:1`

## Outcome

The complete 608-line Penn MATH 555 Chapter 3 authority was translated contiguously into Indonesian, closed as a standalone 20-page A4 reader, independently audited, numerically checked with open runtimes, built twice byte-identically, visually reviewed, admitted into the correction ledger, and bound for the modular backend. No Git operation, publication, or upstream contact occurred in this production turn.

## Frozen identities

- Authority `authority/penn-state/source/ClassNotes/Section3.tex`: 41,715 bytes / 608 lines / SHA-256 `d4ae6142e2366b12575eafddc833df067518af114e9816187668cc367be43010`.
- Target `source/id-ID/penn-03-pendakian-gradien-dan-pencarian-garis-id.tex`: 44,364 bytes / 646 lines / SHA-256 `7c75d0ae56a5a912d561d91ece607f088a4ff4f3de4dbc3396ce40d6d7d6a229`.
- Wrapper `source/id-ID/D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.tex`: 8,203 bytes / 192 lines / SHA-256 `0876d121d417ef4f73f308eac62056a55499628af44713e06246315852dcfa38`.
- Bibliography excerpt `source/id-ID/references-penn-ch03-id.bbl`: 852 bytes / 25 lines / SHA-256 `d3e645c03298c14fee272d44b5d471a81d31aec60a95d4f568b4923edde63867`.
- Final reader `output/pdf/D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.pdf`: 515,851 bytes / 20 A4 pages / SHA-256 `e1be82d06572c51b403608cd9595cc5adf2dc64cfa93f53001eba94e48f77e3e`.
- Extracted text `qa/D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.txt`: 47,464 bytes / 828 lines / SHA-256 `9880848f06e2f1104a88213f3a9f7629db87c6cc8bf0b515281cf553ed1895bc`.

## Contiguous source partition

1. P03-S001 / `d90.penn.v1.ch03.seg0001`: source lines 1–47, basic ascent algorithm.
2. P03-S002 / `d90.penn.v1.ch03.seg0002`: source lines 48–80, ascent directions and exact line search.
3. P03-S003 / `d90.penn.v1.ch03.seg0003`: source lines 81–160, maximum bracketing.
4. P03-S004 / `d90.penn.v1.ch03.seg0004`: source lines 161–224, dichotomous search.
5. P03-S005 / `d90.penn.v1.ch03.seg0005`: source lines 225–312, golden-section search.
6. P03-S006 / `d90.penn.v1.ch03.seg0006`: source lines 313–404, bisection search.
7. P03-S007 / `d90.penn.v1.ch03.seg0007`: source lines 405–452, one-dimensional Newton method.
8. P03-S008 / `d90.penn.v1.ch03.seg0008`: source lines 453–608, Newton convergence.

The exact next authority is `Section4.tex`: 34,684 bytes / 469 lines / SHA-256 `76113034709b5914fa920076f2e882ccf30157e78ce5bdf4593a5d39af1886d5`.

## Reader closure and rights decisions

All live prose, definitions, statements, proofs, examples, exercises, formulas, IDs, references, citations, and four figure calls remain in source order. The target has the exact 142-environment live sequence, the same 35 unique labels, the same 37 unique reference targets, the nine-entry citation sequence, four byte-identical figures, and all twelve exercises.

The authority's six Maple listings are excluded because no separate reusable code license closes that component. They were replaced at the same pedagogical surfaces by independently authored locale-neutral pseudocode; no Maple syntax or implementation was copied. Five legacy generated-output calls were replaced by explicitly identified numerical witnesses. The target therefore has no legacy listing or input dependency. The five-entry bibliography is excerpted exactly from the bundled Penn `Math555.bbl`; no missing database metadata was invented.

The source and derivative are handled under CC BY-NC-SA 3.0 US. The wrapper includes attribution, changes, the license link, NonCommercial/ShareAlike handling, and nonendorsement. Independently authored bridge material is not attributed to Penn or the source authors.

## Corrections and ledger admission

The final proposal `qa/PENN_CH03_PROPOSED_LEDGER.jsonl` contains 21 valid records, SHA-256 `80aa5a3f7b4f46c7dfe01f58f6f68555c9aeaeb91d0877eaf27cbb447c4a67fa`. Before admission, a collision check found that Penn IDs 0001–0003 already belonged to the authority-version and Chapter 11 adverse records. The Chapter 3 events were therefore renumbered in order to `O015-PENN-ADV-0004`–`O015-PENN-ADV-0024`; the wrapper, auditors, numerical validator, and backend bindings were changed in lockstep. The admitted `ADVERSE_LEDGER.jsonl` now has 120 unique records; its last 21 objects equal the proposal exactly.

The final mathematical rereview repaired three draft issues before admission: the local Newton-rate theorem now has standard C2/simple-root hypotheses and distinguishes Q-quadratic convergence from exact order two; the golden-section failure example is correctly described as weakly but not strictly unimodal, with a one-sided equality tie on its lower plateau; and the pseudocode ledger no longer claims a zero-curvature behavior it does not implement. Two long numerical tuples were moved into display math, and the final Newton proof's equation/display ordering was adjusted without changing formulas so the exact source environment sequence remained intact.

## Independent structural and computation gates

`qa/audit_penn_ch03_unit.py` passes twice deterministically on the frozen source, target, and proposal. Its report SHA-256 is `97af8d897decb2aac58355d97cf65898c1396e18c08deca5e1e8834a6b49d588`; the formula manifest SHA-256 is `af04268dddc2cc3b74ccfe775967673bcfebab911d5d298c61df2a5a68ff653c`.

- 499 source and 570 target math records.
- 230 canonical-equal formula pairs.
- 89 explicit delta blocks.
- zero unbound deltas and zero unknown correction bindings.
- P1=0, P2=0, P3=0.

`qa/validate_penn_ch03_unit.py` passes 31/31 deterministic checks, including 11 negative controls. The retained result SHA-256 is `dcf133cf7ca8aefebb3193711c8ceb1b719d9756b15778971572f1762e6b0565`. The suite covers bracketing, dichotomy, golden-section reuse/contraction/failure, bisection, strong concavity, quartic classification, Newton curvature and sign handling, and exact local rate behavior with SciPy/mpmath references.

## Build and reader QA

Two complete builds from `source/id-ID` used `SOURCE_DATE_EPOCH=1783900800`, `FORCE_SOURCE_DATE=1`, `TZ=UTC`, and:

    latexmk -gg -pdf -interaction=nonstopmode -halt-on-error -file-line-error "-outdir=<bounded-build-dir>" D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.tex

The canonical and reproduction PDFs are byte-identical at SHA-256 `e1be82d06572c51b403608cd9595cc5adf2dc64cfa93f53001eba94e48f77e3e`. The canonical 27,077-byte log has SHA-256 `2702aa4b756fec32557368a144ddfe9a91f32363e034cefea9956034178a74f6` and contains no TeX error, unresolved reference/citation, box warning, missing glyph, or rerun request. The direct frozen `.bbl` inclusion causes only an expected latexmk terminal notice.

All 20 pages were rendered at 120 dpi and inspected in `tmp/pdfs/penn-ch03-final-e1be82d0/contact.png`, with the front matter, Newton-rate page, bibliography, correction appendix, and attribution page inspected full size. No blank verso, clipping, collision, broken glyph, or unreadable formula remains. The PDF is A4/PDF 1.5, unencrypted, searchable on every page, and declares `/Lang id-ID`; it has six outlines and no forms or JavaScript.

Accessibility is pass-with-limitation: the PDF is untagged, and eighteen embedded fonts inside the inherited vector figures lack ToUnicode maps even though the nineteen reader font resources and surrounding text extract correctly. Semantic HTML/EPUB, interactive computation, independent Indonesian language review, and a solution/mastery layer remain open corpus work.

The locale-neutral backend extension passes twice deterministically. It adds 180 Penn records and raises the canonical backend to 973 records / 70 translation segments. JSONL is 718,846 bytes with SHA-256 `77fe247050077fda23c9a0bb2aa9c329f7c72d2e2e5f4b8890956b9df32343ec`; CSV is 860,463 bytes with SHA-256 `5fe10a172f5abd9b847cf99c71620c02c460649d531537dbd61283a2c2d7f0cf`. The Habring semantic baseline is unchanged; only the live adverse-ledger artifact binding is refreshed.

## Admission

Penn Chapter 3 is the eighth admitted reader unit and the first admitted Penn unit. Full evidence is in `00_control/PENN_CH03_SOURCE_AUDIT.md`. Production continues at Penn Chapter 4; this is not a claim that the corpus, curriculum admission, accessibility layer, or publication is complete.
