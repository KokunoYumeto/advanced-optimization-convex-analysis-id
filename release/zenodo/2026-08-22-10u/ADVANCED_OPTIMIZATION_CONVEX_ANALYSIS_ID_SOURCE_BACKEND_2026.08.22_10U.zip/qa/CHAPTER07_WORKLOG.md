# Chapter 7 working log — Duality / Dualitas

## Fixed authority and write boundary

- Authority: `authority/habring/source-v1/duality.tex`
- Authority size: 30,761 bytes; 597 physical lines.
- Authority SHA-256: `0b112dee2582813cec5629c02df1dda329f690f944b60f4694b1c5762129bea9`.
- Authorized targets only: `source/id-ID/habring-07-dualitas-id.tex`,
  `source/id-ID/D90-HAB-07-dualitas-id.tex`,
  `qa/CHAPTER07_PROPOSED_LEDGER.jsonl`, this work log, and
  `build/habring-unit-07-id/`.
- No Git, publication, shared-control, backend, final-output/PDF, upstream contact,
  or other-chapter mutation is part of this task.

## Bounded source audit (pre-translation)

The source is one chapter with three sections: Fenchel duality (lines 4--247),
primal--dual optimization (248--396), and ADMM (397--597). It contains no
figures, tables, URLs, or file inputs.

Environment topology (begin/end counts agree): 148 total environments:
`aligned` 27, `bmatrix` 4, `cases` 7, `defn` 1, `enumerate` 3,
`equation` 79, `example` 1, `lemma` 8, `proof` 12, `rem` 2, and
`theorem` 4.

Labels in source order (24 occurrences, 23 distinct):
`chapter:duality`; `duality:lemma:subdiff_conjugate`; `duality:item1`;
`duality:item2`; `duality:item3`; `duality:thm:Moreau:id`;
`duality:eq:fenchel_duality`; `duality:eq:fenchel_rocka`;
`duality:qe:problem`; `duality:qe:saddlepoint`; `duality:eq:AH`;
`duality:eq:pdhg`; `duality:eq:pdhg2`; `eq:admm1`; `eq:admm2`;
`duality:eq:admm_algo`; `duality:eq:admm3`;
`duality:eq:proof_admm1`; `duality:eq:proof_admm2`;
`duality:eq:proof_admm3`; `duality:eq:proof_admm4`;
`duality:eq:proof_admm5`; and `duality:eq:proof_admm6` at both lines 529
and 584. The first `duality:eq:proof_admm6` is retained; the second will be
transparently remapped to `duality:eq:proof_admm7`, with its sole reference at
line 596 remapped in lockstep.

All 34 reference-command occurrences resolve internally after that remap.
There are two citations: `beck2017first` at line 34 (with locator
`Corollary 3.19`) and `chambolle2011first` at line 320. Both keys exist in
`authority/habring/source-v1/references.bib`. There is one footnote at line 47.
The sole source TODO is commented out at line 24. Reader prompts occur at line
47 (lsc left as an exercise), line 57 (`Exercise.`), line 185 (`why?`), line
276 (`Exercise.`), and line 411 (`Exercise!`); all will remain visible as
Indonesian prompts except the already-commented TODO, which remains commented.

TeX dependencies are the local `shinybook.cls` and `macros-id.tex`; relevant
localized theorem environments and macros include `defn`, `example`, `lemma`,
`theorem`, `rem`, `proof`, `inner`, `dom`, `epi`, `prox`, `Id`, `Lc`, `Gc`,
`R`, `cf`, and `emptyarg`. Bibliography processing requires Biber. Conceptual
dependencies not repeated in this standalone unit are normed/Hilbert spaces,
continuous duals and adjoints, lower semicontinuity and epigraphs, Hahn--Banach
separation, subgradients and subdifferential calculus, proximal maps, strong
convexity, and elementary telescoping/Jensen arguments.

High-confidence defects staged for transparent correction are: the reversed
duality pairing and wrong norm in the conjugate examples (18--20); the
unqualified subgradient-existence step and ill-typed `f^*(\hat x)` (27--47);
the free `y` in the biconjugate bound (76); two missing inequality signs in the
`alpha=0` biconjugate argument (119, 125); incompleteness of the inner-product
space hypothesis in Moreau's identity (178--185); the type-inconsistent and
sign-swapped primal--dual gap (262); use of `f` instead of `g^*` in PDHG (324),
the wrong minimization variable (332), and `tau` instead of `sigma` (354);
the one-step shift in the PDHG ergodic averages and proof (362, 388, 392); the
wrong ADMM minimization variable (417) and differentiability-only notation
(424--431); the malformed residual substitution (496); the wrong cross-term
sign and claimed sign, missing `gamma` factors, and initialization index in the
Lyapunov descent (551--580); the wrong sign and missing `gamma` in the final
objective bound (593); and the duplicate label at 584/596. Pure source-language
misspellings will be normalized by translation and grouped separately.

The source-level topology gap is resolved transparently in the target by a
coherent finite-dimensional real-Hilbert convention, continuous duals, and
Riesz identifications. This is deliberately stronger than the source's intended
general-space reach, but it gives every lsc/closedness, separation, adjoint,
proximal, and algorithmic statement in this standalone reader an unambiguous
common scope. The restriction is staged as a proposed correction rather than
silently imposed.

## Stable source-order segments

- `H07-S001`: source lines 1--24 — chapter setup, conjugate definition/example.
- `H07-S002`: source lines 25--60 — properness/lsc, Fenchel inequality,
  biconjugate introduction.
- `H07-S003`: source lines 61--141 — biconjugate inequality and Fenchel--Moreau
  proof/remark.
- `H07-S004`: source lines 142--186 — conjugate subdifferential and Moreau.
- `H07-S005`: source lines 187--247 — Fenchel--Rockafellar theorem and proof.
- `H07-S006`: source lines 248--277 — primal/dual/saddle formulations and gap.
- `H07-S007`: source lines 278--335 — Arrow--Hurwicz and PDHG derivation.
- `H07-S008`: source lines 336--394 — PDHG estimate and ergodic convergence.
- `H07-S009`: source lines 395--432 — ADMM formulation and algorithm.
- `H07-S010`: source lines 433--502 — ADMM convergence, proof steps 1--2.
- `H07-S011`: source lines 503--597 — ADMM Lyapunov algebra and conclusion.

## Completed production and correction record

The Indonesian reader is complete and frozen. It translates all 597 authority
lines in source order and retains every theorem, proof, example, enumeration,
formula, citation, footnote, and reader prompt. The target has 632 physical
lines, including provenance and correction material, with the following exact
identity:

- `source/id-ID/habring-07-dualitas-id.tex`: 35,428 bytes;
  SHA-256 `11e9ad614f7ac4e3107e78bc3bed03a6d4acfe22f2a65fca26433b0ae3209fd9`.
- `source/id-ID/D90-HAB-07-dualitas-id.tex`: 8,615 bytes; 89 physical lines;
  SHA-256 `3b6e710e37c07cc9ec82ca919451c313c52fa762d58c7b01c6792a78a0098797`.
  The standalone wrapper contains source attribution, license and
  non-endorsement notices, wrapper-local Indonesian equation names, and a
  corrections appendix.
- `qa/CHAPTER07_PROPOSED_LEDGER.jsonl`: 15,830 bytes; 26 valid, unique JSONL
  records from `O015-HAB-ADV-0050` through `O015-HAB-ADV-0075`;
  SHA-256 `57dbba9afdee2fc453dde9fbb97621c1a6897ff5377c1ec6a210827a8dce675d`.
  Root subsequently merged these exact records into `00_control/ADVERSE_LEDGER.jsonl`; the repeated structural audit confirms exact proposal/integrated-record equality.

The target retains exactly 148 `begin` and 148 `end` environments in the
authority sequence, including 79 equation environments. It has 24 distinct
label occurrences, 21 `eqref`, three `cref`, one `Cref`, nine plain `ref`, two
citations, one footnote, and nine items. All references resolve. The duplicated
final source label is resolved uniquely: the first
`duality:eq:proof_admm6` remains, the second is
`duality:eq:proof_admm7`, and the intended final reference changes in lockstep.
The eleven `H07-S001`--`H07-S011` markers and the canonical
`d90.hab.v1.ch07.seg0001`--`seg0011` markers form the exact contiguous source
partition recorded above.

The 26 proposed correction records transparently cover the conjugate/norm and
subgradient examples; biconjugation and Fenchel--Moreau hypotheses and proof
repairs; the finite-dimensional real-Hilbert convention and extended-real
codomains; the Gamma-regularization edge case; Moreau and
Fenchel--Rockafellar scope/calculus; saddle/gap signs and attainment; scaled
Moreau and PDHG typing, indices, metrics, averages, and zero-operator branch;
and ADMM typing, solvability, stationarity, residual, Lyapunov, indexing,
factor, sign, and conclusion repairs. The final proof-heading paragraph break
is layout-only and therefore does not create a mathematical correction event.

## Reproducible build and final QA freeze

The standalone unit was built twice from `source/id-ID/` with:

```text
SOURCE_DATE_EPOCH=1783900800
FORCE_SOURCE_DATE=1
TZ=UTC
latexmk -gg -pdf -interaction=nonstopmode -halt-on-error -file-line-error -outdir=../../build/habring-unit-07-id D90-HAB-07-dualitas-id.tex
```

Both full fixed-epoch builds exited successfully and independently produced the
same 445,733-byte PDF with the same SHA-256. The frozen build products are:

- `build/habring-unit-07-id/D90-HAB-07-dualitas-id.pdf`: 445,733 bytes;
  21 A4 pages; PDF 1.5;
  SHA-256 `c4354e1e1366bdb20cebb9c6eca26fba172d6d82a6ad22dd9e2e470da2baeb6e`.
- `build/habring-unit-07-id/D90-HAB-07-dualitas-id.log`: 105,821 bytes;
  2,548 physical lines;
  SHA-256 `795b594b1c78e0a0769fe6b7f292fea0d6ddc81a054cad00a4d857da0cab217d`.
- `build/habring-unit-07-id/D90-HAB-07-dualitas-id.txt`: 53,128 bytes;
  941 physical lines;
  SHA-256 `b473c80434a35ec607c6a9b9da3dcc31e3d5a3a233ae1f7da72293a87d65a544`.

The final log has zero matches for undefined controls or references, multiply
defined labels, overfull/underfull boxes, missing characters, fatal/emergency
errors, or rerun requests. Remaining messages are benign environment notices:
the Perl locale fallback, an obsolete `xcolor` option, the KOMA/`tocloft`
advisory, and missing Indonesian localization modules with package fallbacks.

Exact-byte numerical validation passed twice with byte-identical stdout and
receipt output:

- `qa/validate_duality_unit.py`: 45,213 bytes;
  SHA-256 `127bed94abe4b506ebd999a46ea71b31457f2f4cc65c7fdd7cd4efcc60569c5b`.
- `qa/DUALITY_SOLVER_RESULTS.json`: 10,830 bytes;
  SHA-256 `9ceeadd90b4868f600241301813a8f24c1d1279690abc8cbf96baa3faf62f3c3`.

The independent structural/formula audit also passed twice deterministically
with zero failures on the exact frozen target:

- `qa/audit_duality_unit.py`: 36,689 bytes; 943 physical lines;
  SHA-256 `4e29ad8cc208ab35f35e8dfc2bb323343977e7badcaed7aa7d8cfa75392cf35b`.
- `qa/DUALITY_STRUCTURE_REPORT.json`: 32,121 bytes; 1,312 physical lines;
  SHA-256 `fd909b00e4274a31c9e9c707cbb9039d5e03233876d0c0094c66c1049802307f`.
- `qa/DUALITY_FORMULA_DELTA_MANIFEST.json`: 81,046 bytes; 2,312 physical lines;
  SHA-256 `fe72e72d0223117a0b34727d235ced9b6bf2af17cf48154e6b670d2ce75d89fb`.

The bounded visual review covered all 21 pages. Its sole readability finding,
the near-collision between `Bukti.` and the first custom enumerate label on
physical page 7, was repaired with a proof-local paragraph break. A fresh
180-dpi render confirms separate lines with no collision:
`build/habring-unit-07-id/render-final-page7-fixed.png`, 293,582 bytes,
SHA-256 `376c40e3bedcef31f934d32b7512ba7798fe886c99515df4b01cf88311c899ab`.
The content rereview reported P1/P2/P3 = 0; the final layout-only delta then
passed the repeated structural and numerical gates above.

Residual scope limitation: the reader deliberately uses a coherent
finite-dimensional real-Hilbert framework, which is stronger than the wider
functional-analytic reach suggested by parts of the authority. This is stated
in the reader and correction appendix rather than hidden. Numerical witnesses
support, but do not replace, the included mathematical review and proofs.

**Terminal state: FROZEN.** No copy was made to `output/pdf`, no publication or
upstream contact occurred, and no shared control was modified. The only later
action outside this task is the expressly withheld promotion of these frozen
bytes after the required independent release review.

## Post-freeze root promotion

After the independent review, repeated structural/formula and numerical gates,
fixed-epoch replay, and final all-page visual inspection passed, root copied the
frozen PDF byte-for-byte to `output/pdf/D90-HAB-07-dualitas-id.pdf` and the
53,128-byte extraction to `qa/D90-HAB-07-dualitas-id.txt`. Root then updated the
shared Chapter 7 source audit, rights, build, state, cursor, decision, and
backend controls. This promotion did not use Git, publish externally, or contact
upstream in the restricted turn.
