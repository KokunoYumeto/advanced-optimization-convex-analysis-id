# Optimisasi Lanjut dan Analisis Konveks — Edisi Bahasa Indonesia

Edisi pembaca bahasa Indonesia yang sedang dikembangkan untuk materi optimisasi lanjut, analisis konveks, dan metode nonsmooth. Repositori ini memuat sumber TeX dan Markdown semantik yang dapat disunting, HTML yang dapat mengalir ulang, PDF yang telah diverifikasi, pemeriksaan matematika dan komputasi yang dapat diulang, serta backend modular dengan pengenal stabil.

**Status:** karya dalam proses. Unit Habring Bab 3–9 dan Penn Bab 3–5 telah diterjemahkan serta lolos audit struktural, matematika, komputasi, pembangunan deterministik, dan pemeriksaan visual sebagai pendamping opsional sepuluh unit. Korpus utama D90 yang dipilih adalah MIT OpenCourseWare 6.253 ditambah materi gradien stokastik Clément Royer. Unit semantik MIT halaman 2–5, 6–13, 14, dan 15 (“The Rise of the Algorithmic Era”) telah lolos dan diterima; QA browser langsung L04 lulus, sedangkan PDF tetap belum bertag dan tinjauan bahasa Indonesia manusia belum tercatat. Halaman 16 membuka bagian multi-halaman berikutnya yang akan ditutup dengan satu gerbang gabungan. Status ini bukan klaim bahwa keseluruhan korpus telah selesai.

English discovery label: **Advanced Optimization and Convex Analysis — Indonesian (id-ID) Edition**.

## Preservasi dan mirror

Checkpoint sepuluh unit yang belum lengkap dan pilot MIT dipreservasi dalam
garis keturunan Zenodo yang sama: [koreksi publik terbaru
10.5281/zenodo.22071030](https://doi.org/10.5281/zenodo.22071030) dan [DOI
konsep 10.5281/zenodo.22059741](https://doi.org/10.5281/zenodo.22059741).
Koreksi tersebut mempertahankan berkas parent byte demi byte dan telah dibaca
kembali secara anonim. Publikasi L04 belum berhasil karena transaksi Zenodo
mengembalikan HTTP 504; tidak ada klaim bahwa byte L04 sudah publik.

Modul Habring Bab 3–9 yang murni CC BY 4.0 juga tersedia sebagai permukaan pembaca
utama di [Figshare versi 2](https://doi.org/10.6084/m9.figshare.33314733.v2),
dengan PDF gabungan 103 halaman sebagai berkas pertama, paket sumber yang dapat
dibangun ulang, lisensi, manifest, dan checksum. Komponen Penn berlisensi campuran
tidak ditempatkan pada item Figshare tersebut dan tetap berada di Zenodo.

Akses GitHub telah dipulihkan oleh penyedia pada 22 Agustus 2026. Checkpoint ini
telah disinkronkan ke [repositori yang sama](https://github.com/KokunoYumeto/advanced-optimization-convex-analysis-id)
pada [commit `9204053`](https://github.com/KokunoYumeto/advanced-optimization-convex-analysis-id/commit/92040531272bd26556b0768406e0225105b16deb);
identitas commit/tree dan sebelas berkas pembaca, sumber, backend, kontrol,
rilis, serta resi publik dibaca kembali secara anonim dan cocok byte demi byte.
Tidak dibuat repositori pengganti.

## Pembaca yang tersedia

- `output/html/D90-MIT-01-peran-kekonveksan-id.html` — permukaan semantik utama pilot MIT halaman sumber 2–5; 20.613 byte; SHA-256 `fff4de952dd2cb208208e1cfb3bbc8fe8a64936ff5fdb532a23a92fb0dc6af8b`.
- `output/pdf/D90-MIT-01-peran-kekonveksan-id.pdf` — pembaca A4 pilot MIT halaman sumber 2–5, 3 halaman; SHA-256 `bd03912f9d3fe6dbe7376577c7ca6e7ab5aee007dd33b51669cde1792644df58`.
- `output/html/D90-MIT-02-dualitas-dan-perilaku-pengecualian-id.html` — permukaan semantik MIT halaman sumber 6–13; 38.196 byte; SHA-256 `d722e7bebc5b5f1c0a9d4c1980b747564897521ea7632be0ab0e3433b26ec007`.
- `output/pdf/D90-MIT-02-dualitas-dan-perilaku-pengecualian-id.pdf` — pembaca A4 MIT halaman sumber 6–13, 5 halaman; 67.749 byte; SHA-256 `06b9c6ce9eaac8f78149e7a881ebdff6ef5c8692d9040c5dec8929a2e646d89b`.
- `output/html/D90-MIT-03-pandangan-modern-optimisasi-konveks-id.html` — permukaan semantik MIT halaman sumber 14; 9.762 byte; SHA-256 `01785166246be0f1187353c64f228f341626951e7d20fef127a4b92ab7e96d90`.
- `output/pdf/D90-MIT-03-pandangan-modern-optimisasi-konveks-id.pdf` — pembaca A4 MIT halaman sumber 14, 2 halaman; 34.550 byte; SHA-256 `3cc20409b71331564cbc5429ce72cd27ebe3cbdb072910d2483e0bdeee54a136`.
- `output/html/D90-MIT-04-kebangkitan-era-algoritmik-id.html` — permukaan semantik MIT halaman sumber 15; 9.975 byte; SHA-256 `c7ee3ace683dd854ce99259536b58bc802cb17fdd189a32b403f9e87521ea81e`.
- `output/pdf/D90-MIT-04-kebangkitan-era-algoritmik-id.pdf` — pembaca A4 MIT halaman sumber 15, 2 halaman; 36.971 byte; SHA-256 `9056c6ba9fa3996f907d1dfd6147ef219aa7c88941582c78d01977e60ce8ef5f`.
- `output/pdf/D90-HAB-03-09-modul-pendamping-id.pdf` — modul Habring Bab 3–9 gabungan, 103 halaman; SHA-256 `6cd291cc447999b7cd72622e8c2003b837cf4f21ea5de0fcb7094913e20acd87`.
- `output/pdf/D90-HAB-03-subgradien-id.pdf` — 15 halaman; SHA-256 `45f7bc24ff46079881e42be9aa6f1b508c324a208f2b4dd82e35e7e3a6d544b4`.
- `output/pdf/D90-HAB-04-metode-subgradien-terproyeksi-id.pdf` — 13 halaman; SHA-256 `5c9991af837995b2e24f4a9060eb3b0efe7b2d71a9bbde01948eeb81ebfd63b7`.
- `output/pdf/D90-HAB-05-metode-gradien-proksimal-id.pdf` — 15 halaman; SHA-256 `6f8aa99f6d0395f3c732ed64d2b5cadd5d95ff2195e2504e959d31a3c010731d`.
- `output/pdf/D90-HAB-06-akselerasi-id.pdf` — 15 halaman; SHA-256 `cb9edf46d8d2582591ad3114f9a2b316073825dfd48079d12560793ad4bca0a0`.
- `output/pdf/D90-HAB-07-dualitas-id.pdf` — 21 halaman; SHA-256 `c4354e1e1366bdb20cebb9c6eca26fba172d6d82a6ad22dd9e2e470da2baeb6e`.
- `output/pdf/D90-HAB-08-penurunan-gradien-stokastik-id.pdf` — 8 halaman; SHA-256 `c1ed028667c5df3fd0a837807e2a17bf7a9e1fa3170938853c9a96b9670fa86a`.
- `output/pdf/D90-HAB-09-transportasi-optimal-id.pdf` — 15 halaman; SHA-256 `edc8e17fd43d17a0dd7811879dfbedaab9ac226c291ed5558ca0bfbb3ce10214`.
- `output/pdf/D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.pdf` — 20 halaman; SHA-256 `e1be82d06572c51b403608cd9595cc5adf2dc64cfa93f53001eba94e48f77e3e`.
- `output/pdf/D90-PENN-04-pencarian-garis-hampiran-dan-konvergensi-id.pdf` — 17 halaman; current working-tree SHA-256 `18e7162f8d1e55a050ee96a6ba05a2ffaa0d5cb578f96e264152666a79dc83a8` (the previously published Zenodo bytes remain `c0f283aa7d70eba05de6a35c98bc0aa55f3177ab40702bf7eed5de45a7b6ab8a`).
- `output/pdf/D90-PENN-05-metode-newton-dan-koreksi-id.pdf` — 15 halaman; current working-tree SHA-256 `dad34c7cb363197da1ae87117b22b2dde21d6d183997745cd3ffff62245c0b96` (the previously published Zenodo bytes remain `427db2c5a4428dfbe222d7e1d4f5c5349d4f78484a8593c412328fe94a7353c6`).

Sumber Indonesia berada di `source/id-ID`; rekaman audit dan pemeriksaan ada di `qa`; backend mesin-baca beku L04 berisi 1.543 rekaman di `backend`; keputusan, otoritas sumber, hak komponen, dan kursor ada di `00_control`.

## Provenans produksi

Terjemahan, rekonstruksi sumber semantik, pembuatan backend, serta QA matematika dan komputasi dalam edisi ini dibantu oleh **OpenAI Codex gpt-5.6-sol, Ultra** atas arahan pengguna repositori. Sistem tersebut bukan penulis sumber, pemberi lisensi, atau wakil institusi mana pun. Semua kredit penulis dan kontributor manusia tetap dipertahankan; rincian peran, hak per komponen, nondukungan, dan batas tinjauan manusia dicatat dalam `PROVENANCE.md` dan `RIGHTS.md`.

## Otoritas dan perubahan

Korpus utama MIT merupakan rekonstruksi semantik dan terjemahan independen dari Dimitri P. Bertsekas, *Convex Analysis and Optimization*, MIT OpenCourseWare 6.253, di bawah [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Gambar yang dinyatakan digunakan atas izin Athena Scientific tidak disalin; gambar yang diperlukan harus digambar ulang secara independen dengan rekaman hak terpisah atau dihilangkan dengan lokator sumber. Komponen stokastik Clément Royer berada di bawah [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/). Unit Habring merupakan terjemahan independen dari Andreas Habring, *Lecture Notes: Convex Optimization*, arXiv:2607.11664v1, di bawah [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Unit Penn merupakan terjemahan independen dari Christopher Griffin, *Nonlinear Programming* / Penn State MATH 555, di bawah [CC BY-NC-SA 3.0 US](https://creativecommons.org/licenses/by-nc-sa/3.0/us/). Setiap komponen mempertahankan lisensi, atribusi, penandaan perubahan, dan nondukungan sendiri; tidak ada lisensi menyeluruh untuk seluruh repositori. Daftar koreksi yang transparan ada di `00_control/ADVERSE_LEDGER.jsonl`.

Empat belas masukan listing Maple yang ditemui pada Penn Bab 3–5 tidak disalin atau diterjemahkan sebagai kode. Permukaan itu diganti dengan pseudokode mandiri yang tidak bergantung pada Maple atau bahasa pemrograman tertentu dan diungkapkan sebagai perubahan. Lihat `RIGHTS.md`, `00_control/COMPONENT_RIGHTS.csv`, dan audit sumber Penn Bab 3–5 di `00_control`.

## Membangun ulang

Prasyarat yang telah diverifikasi: Pandoc, LuaLaTeX, MiKTeX/pdfTeX, `latexmk`, dan Biber. Bangun dua permukaan pilot MIT dari akar repositori:

```powershell
python qa/build_mit_pilot.py --output-root output/mit-pilot-rebuild
python qa/validate_mit_pilot.py
python qa/build_mit_l02.py --output-root output/mit-l02-rebuild
python qa/validate_mit_l02.py
python qa/build_mit_l03.py --html-output output/mit-l03-rebuild.html --pdf-output output/mit-l03-rebuild.pdf
python qa/validate_mit_l03.py
python qa/build_mit_l04.py --html-output output/mit-l04-rebuild.html --pdf-output output/mit-l04-rebuild.pdf
python qa/validate_mit_l04.py
```

Dari `source/id-ID`, bangun unit Penn Bab 3–5 dengan pola berikut:

```powershell
$env:SOURCE_DATE_EPOCH='1783900800'
$env:FORCE_SOURCE_DATE='1'
$env:TZ='UTC'
latexmk -gg -pdf -interaction=nonstopmode -halt-on-error -file-line-error -outdir='..\..\build\penn-unit-03-id' 'D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.tex'
latexmk -gg -pdf -interaction=nonstopmode -halt-on-error -file-line-error -outdir='..\..\build\penn-unit-04-id' 'D90-PENN-04-pencarian-garis-hampiran-dan-konvergensi-id.tex'
latexmk -gg -pdf -interaction=nonstopmode -halt-on-error -file-line-error -outdir='..\..\build\penn-unit-05-id' 'D90-PENN-05-metode-newton-dan-koreksi-id.tex'
```

Jalankan audit dan pemeriksaan numerik dari akar repositori:

```powershell
python qa/audit_penn_ch03_unit.py
python qa/validate_penn_ch03_unit.py
python qa/audit_penn_ch04_candidate.py
python qa/validate_penn_ch04_math.py
python qa/audit_penn_ch05_candidate.py
python qa/validate_penn_ch05_math.py
python qa/extend_backend_mit_l01.py
python qa/validate_backend_mit_l01.py
python qa/extend_backend_mit_l02.py
python qa/validate_backend_mit_l02.py
python qa/extend_backend_mit_l04.py
python qa/validate_backend_mit_l04.py
```

Generator Penn/Habring terdahulu tetap disimpan sebagai bukti transaksi historis. Rantai backend MIT hidup berakhir pada pasangan `extend_backend_mit_l04.py` / `validate_backend_mit_l04.py`; baseline L02 dipertahankan byte demi byte.

Rekaman pembangunan lengkap ada di `00_control/BUILD_AND_QA.md`.

## Aksesibilitas dan batas saat ini

Semua PDF bersifat dapat dicari dan mendeklarasikan bahasa `id-ID`, tetapi belum bertanda semantik. Sebagian font internal pada gambar vektor Penn Bab 3–4 tidak memiliki peta Unicode lengkap; Penn Bab 5 dan pilot MIT memetakan seluruh fontnya. Pilot MIT mempunyai HTML semantik yang dapat mengalir ulang, dengan struktur heading, MathML, navigasi, tautan lompat, dan pengenal halaman/butir yang telah diuji pada lebar desktop dan ponsel tanpa luapan horizontal. HTML/EPUB semantik untuk korpus lengkap, permukaan komputasi interaktif, lapisan latihan/hint/solusi lengkap, dan peninjauan bahasa independen masih harus diselesaikan. Penn Bab 6 yang sudah diterjemahkan disimpan sebagai kandidat pendamping yang belum diterima; produksi utama tidak berlanjut otomatis ke bab tersebut.

## Batas MIT L02 yang diterima (23 Agustus 2026)

Unit pembaca semantik kedua MIT mencakup tepat halaman sumber 6–13, dari
“Duality” hingga “Exceptional Behavior”; halaman 14, “Modern View of Convex
Optimization”, adalah kursor yang berlaku sebelum penerimaan L03. Sumber bahasa Inggris dan bahasa
Indonesia, HTML, PDF A4 lima halaman, validasi, QA browser, dan peninjauan
independen tercatat dengan hash lengkap di `00_control/CURRENT_STATE.md` dan
`00_control/BUILD_AND_QA.md`.

Topologinya adalah 8 halaman, 19 butir tingkat atas, 7 daftar bersarang, 4
rumus display, 2 contoh, 1 pertanyaan didaktik berjawab, 1 permukaan display,
dan 61 simpul MathML. Tujuh grafik Athena Scientific yang terikat izin tidak
disalin sebagai byte atau tata letak; masing-masing diganti deskripsi semantik
berlokator tepat yang mempertahankan label dan hubungan matematis. Komponen
MIT tetap CC BY-NC-SA 4.0 dengan atribusi, penandaan perubahan, kewajiban NC/SA,
dan nondukungan. Batas ini tidak memiliki latihan, petunjuk, solusi, atau
interaktivitas sumber; tidak ada yang diada-adakan. Validasi, reflow desktop/
ponsel, pemeriksaan visual, dan rereview independen lulus (P1=0/P2=0/P3=0).

Ini masih karya parsial: halaman sumber yang tersisa, empat jembatan asli,
laboratorium, lapisan mastery/solusi, capstone, EPUB semantik,
PDF bertag, dan tinjauan bahasa Indonesia oleh manusia masih terbuka. Tidak ada
klaim penyelesaian korpus penuh.

Ekstensi backend L02 lulus secara idempoten dan mempertahankan baseline 1.430
rekaman: snapshot L02 berisi 1.495 rekaman / 92 segmen stabil, dengan 65 rekaman
baru; snapshot ini adalah baseline byte-preserved bagi backend L04 1.543 rekaman.
`backend/records.jsonl` berukuran 1.076.672 byte (SHA-256
`61422fc3d0a1dfa3fed57f3710ae0ffbefb48b8b45957c25ed7455d3a9bd05e7`) dan
`backend/records.csv` 1.293.072 byte (SHA-256
`146f9a251bcd6b7c9938debc5e9b3f8d680cb51b6d6309bc9a85c90269d22f82`). Set ID
baru SHA-256 `1436ab92aa0c80e1aedaf5ae1dce1b2ba28b31a9a88695d6f6d2803bc41789c4`;
skrip ekstensi 27.926 byte SHA-256
`9c13a77eb1bd6a4d440bd4f765099201ccf1e1bba611423a9689853cac1d8368`, validator
15.089 byte SHA-256
`5b0999b563b7dd3afa199bd8d89d391772b026035b836d448f2cef418576811a`, dan resi
`qa/MIT_L02_BACKEND_VALIDATION.json` 7.985 byte SHA-256
`6a325456a0591b6fe17704b7d0139247bbed8d1a622a18702f86048b45939005`.

## Batas MIT L03 yang diterima (23 Agustus 2026)

Unit pembaca semantik ketiga MIT mencakup tepat halaman sumber 14, “Modern
View of Convex Optimization”; halaman 15 adalah kursor berikutnya. Sumber
bahasa Inggris dan bahasa Indonesia, HTML, PDF A4 dua halaman, validasi, QA
browser, dan rereview independen tercatat dengan hash lengkap di
`00_control/CURRENT_STATE.md` dan `00_control/BUILD_AND_QA.md`.

Topologinya adalah 1 halaman, 2 butir tingkat atas, 6 butir bersarang, 2
permukaan grafik yang dihilangkan, 0 rumus display, dan 0 byte gambar. Grafik
Athena Scientific yang terikat izin tidak disalin sebagai byte, potongan, atau
tata letak; masing-masing diganti deskripsi semantik berlokator tepat yang
mempertahankan label dan hubungan matematis. Komponen MIT tetap CC BY-NC-SA 4.0
dengan atribusi, penandaan perubahan, kewajiban NC/SA, dan nondukungan. Batas
ini tidak memiliki latihan, petunjuk, solusi, kode, atau interaktivitas sumber;
tidak ada yang diada-adakan. Validasi, reflow desktop/ponsel, pemeriksaan
visual, dan rereview independen lulus; PDF dapat dicari, `/Lang id-ID`, tetapi
belum bertag. Tinjauan bahasa Indonesia oleh manusia belum tercatat.

Preservasi publik L02 tetap berada pada koreksi Zenodo
[10.5281/zenodo.22071030](https://doi.org/10.5281/zenodo.22071030), dengan resi
baca anonim 9.338 byte SHA-256
`4d1ec4e50c2428a6c0cbad1e8e530892f1bc0b6c6eeb7da89b48e987932c6dbb`. Resi itu
adalah garis keturunan koreksi L02. L03 kini dipreservasi tersendiri pada
[10.5281/zenodo.22071175](https://doi.org/10.5281/zenodo.22071175): 40 berkas,
ZIP delta 484.193 byte SHA-256
`16116f249ffd4fc731a01de8f748b13c9e32c6734ca60c035098420e40b2909f`, dan resi
baca anonim 11.373 byte SHA-256
`3d3a22a371eb267915f19773e8d4fc94b482840d808a46b0b376e98518ad8822`.
Korpus lengkap tetap belum selesai.

## Batas MIT L04 yang diterima (23 Agustus 2026)

Unit pembaca semantik keempat MIT mencakup tepat halaman sumber 15, “The Rise
of the Algorithmic Era”; halaman 16 adalah kursor berikutnya. Sumber bahasa
Inggris dan bahasa Indonesia, HTML, PDF A4 dua halaman, validasi, QA browser,
QA visual, dan rereview independen tercatat dengan hash lengkap di
`00_control/CURRENT_STATE.md` dan `00_control/BUILD_AND_QA.md`.

Topologinya adalah 1 halaman, 6 butir tingkat atas, 12 butir bersarang, 1
permukaan matematika inline, 0 rumus display, 0 grafik, dan 0 byte gambar. Hak
MIT tetap CC BY-NC-SA 4.0 dengan atribusi, penandaan perubahan, kewajiban NC/SA,
dan nondukungan. Batas ini tidak memiliki latihan, petunjuk, solusi, kode, atau
interaktivitas sumber; tidak ada yang diada-adakan. Validasi, pembangunan
deterministik, pemeriksaan visual, dan rereview independen lulus.

QA browser kini berstatus `pass`: pemeriksaan DOM langsung pada desktop 1280×720
dan ponsel 390×844 tidak menemukan luapan horizontal atau temuan konsol, serta
tidak ada ID duplikat, fragmen tak terselesaikan, atau gambar. Zenodo sedang
mengalami HTTP 504 pada transaksi L04; oleh karena itu belum ada DOI atau klaim
byte publik untuk L04. PDF tetap tidak ditag dan tinjauan bahasa Indonesia oleh
penutur asli belum tercatat. Korpus lengkap tetap belum selesai.

Backend L04 beku pada 1.543 rekaman, yaitu 48 tambahan terhadap baseline L02
1.495 rekaman. JSONL 1.102.706 byte memiliki SHA-256
`92f6b805a83361f29a830b8c37b1c52f3468cb420d10b9a3a810cf0f8ac20645`; CSV
1.325.476 byte memiliki SHA-256
`fedc1855df37e006e52ba76d99af2ee132accfa3b416519c39c036454f378a7d`; set ID
baru memiliki SHA-256
`8216b6f6713c519699e42923138a3f5e1f374000f3a494ececc646b9819dbb2d`.
Hash skrip ekstensi, validator, dan resi lulus masing-masing adalah
`19d315c38d77691b067050e6a09ffb411767008a41582b1674c90d37087f7272`,
`d218daa09e803be9dd9c6401a5aace85f5340a88dbb7cf53b3563728bbb79c46`, dan
`59277c7f61b350625d829b079b8800343489a97591c7f4cbf56d01e2c82c1204`.

Transaksi L04 yang mengembalikan HTTP 504 tidak menghasilkan rekaman publik;
tidak akan dibuat rilis L04 tersendiri. Halaman 16 memulai bagian sumber
multi-halaman yang koheren. Terjemahan, pemeriksaan pembaca, backend, hak, dan
preservasi berikutnya akan ditutup sekali pada batas batch itu, bukan sebagai
proyek atau rilis per halaman.

## Batas MIT L05 yang diterima (23 Agustus 2026)

L05 menerima satu blok orientasi kursus yang koheren pada halaman sumber
16–19. Saksi Inggris 7.120 byte memiliki SHA-256
`3acbde47074da0429419e5c702785ee0490efa5e43f2b07cbac497f0d480492f`;
target Indonesia 8.702 byte
`65cb7fec2d6b1aeda69837e10568f2410a9f4bded2b835b8dac59a9b516444cc`;
HTML 16.029 byte
`424d854bb1e83e841a15d0073aad3db6bab0585ca6d587fd14a3b5cfb4274d83`;
PDF A4 tiga halaman 46.785 byte
`2af9e4dc8e999969f03817350451c4b21f3c764564eee64327d15b48483313c0`;
dan CSS 2.636 byte
`d8d8417c4d2f9e01852cd30bc97552f377da3a6d1f9bbee25c25d47e16ce9645`.

Batas ini memuat 16 butir tingkat atas, 26 butir bersarang, dua URI sumber yang
tetap aktif, serta nol rumus, gambar, latihan, solusi, kode, atau interaktivitas.
Validasi 4.195 byte
(`2ef09a674c6bcc586cd13dd513a2f0f24aade6d10d2d11ccdfe317b7307dc3aa`),
QA browser langsung 1.271 byte
(`24b775fb6afc271a16a62097151175852a4a01eb1c41605a196258e19f01d342`),
QA visual 1.544 byte
(`d32b4e66cf7c1fd4f9fa06c75f88bfb80404caeefe894ba92396c548d126af04`),
dan rereview independen 3.066 byte
(`c1c358c32f245ca4ef1c15efe3ed4d319f9bdef758319bce04f501bb525f7fb9`)
semuanya lulus. Koreksi nama `O015-MIT-SEM-0004` diterima dan dibekukan dalam
snapshot 642 byte, SHA-256
`c701e631c4839aa07a2f8a4b8e8f026394c66bd709ffa37318431bbc461e1595`.
Hak komponen tetap MIT CC BY-NC-SA 4.0. PDF dapat dicari dan berbahasa
`id-ID`, tetapi belum bertag; tinjauan penutur asli belum tercatat.

Backend L05 final berisi 1.605 rekaman, 62 tambahan terhadap baseline L04
1.543 rekaman yang direkonstruksi tepat dan dipertahankan byte demi byte. JSONL
1.142.443 byte memiliki SHA-256
`30c6f3257d481136995acd7947a725da003c4ab2ea2e9049de53a23fa681658b`;
CSV 1.373.874 byte memiliki SHA-256
`f66227edc14e953b44d833b87b0373f76d87bf04fdd32d2f50552597915746e3`.
Hash generator 35.174 byte, validator 27.004 byte, dan resi lulus final 5.108
byte masing-masing adalah
`6a1b0c319e3a59820bcd18b257b9d160d0c39ae21f1dcf772df9bb8a61c7b36c`,
`d4572ac9c0924459beebb225f8184b60b8e6a022fe1bdcccba2a6409a4f6fbab`,
dan `7e653889523fdf6da918a0403e230b7f3a185107ed87ca22cc6936f37db57afc`.

Tidak ada versi Zenodo L04 tersendiri. Checkpoint Zenodo gabungan L04+L05 dan
push GitHub yang memuat L05 masih tertunda; belum ada klaim byte publik L05.
Produksi aktif adalah seluruh Kuliah 2, halaman 20–28. Sensus batasnya 9.962
byte, SHA-256
`fc0cb5b863652aa810ed765f247a248be1510cd61f240277b896e605a41b3ea4`;
saksi dan target sudah berupa draf tetapi belum diterima, sementara build/QA
sedang berjalan. Halaman 29 memulai Kuliah 3 dan menjadi kursor sesudah batch.
`00_control/CURRENT_GOAL_AND_WORKFLOW.md` tetap menjadi otoritas pelanjutan.

## Batas MIT L06 yang diterima (23 Agustus 2026)

L06 menerima seluruh Kuliah 2 pada halaman sumber 20–28 sebagai satu batch.
Saksi Inggris, target Indonesia, HTML, dan PDF A4 empat halaman masing-masing
memiliki SHA-256
`a8094ad892a90a20d271e961504fb418b1ea241859b072cf5ba56317783b809a`,
`a9e8b353adddc4919b6244e27df4365a33e74d4b034b9d99fff6eb3f93e0b23e`,
`94275af59592c64e7c8ae55fc384b721b2863a22ee328c33dc3b1d5a1e0af9a6`,
dan `84ce42542ed58e102c736dacc02b69cf16ab264a577d689d2fe5f7a24ba37d75`.

Batas ini memuat sembilan halaman, 32 butir tingkat atas, 17 butir bersarang,
12 rumus display, dan lima deskripsi grafik. Tidak ada byte, potongan, atau tata
letak grafik Athena Scientific yang disalin. Koreksi notasi
`O015-MIT-SEM-0005` dan `0006` diungkapkan. Validasi deterministik, QA
browser desktop/ponsel, inspeksi visual empat halaman, dan rereview independen
semuanya lulus. PDF dapat dicari, A4, dan berbahasa `id-ID`, tetapi belum
bertag. Tidak adanya tinjauan penutur asli dicatat sebagai bukti yang belum
tersedia, bukan sebagai penahan kerja atau publikasi.

Backend kini memuat 1.714 rekaman, 109 tambahan terhadap baseline L05. JSONL
1.231.983 byte memiliki SHA-256
`9ad375756d2ee3159acf760f5d68084d2921e665cf993e2aaa6514f1e710337e`;
CSV 1.480.312 byte memiliki SHA-256
`f5c81e38ee9d1b4e9d2bcc7632603266fcf271b9b8c6454e99ba3e4b0041f72f`.
Resi backend lulus pada SHA-256
`247fd848a4b4d0c3960ee82d48b7648304215ca69dddf1736305734106615c4c`.

Batch aktif berikutnya adalah seluruh Kuliah 3, halaman 29–38. Halaman 39
memulai Kuliah 4. Sensus dan saksi semantik Kuliah 3 sudah dibekukan; edisi
Indonesia dan pembacanya harus ditutup sekali sebagai L07, bukan per halaman.
