# Lisensi dan hak komponen — MIT L06

Materi reader, transkripsi semantik, dan adaptasi yang berasal dari MIT
OpenCourseWare 6.253 pada checkpoint ini dilisensikan di bawah **Creative
Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA
4.0)**: <https://creativecommons.org/licenses/by-nc-sa/4.0/>.

Sumber: Dimitri P. Bertsekas, *Convex Analysis and Optimization*, MIT
OpenCourseWare 6.253, Spring 2012,
<https://ocw.mit.edu/courses/6-253-convex-analysis-and-optimization-spring-2012/>.
Bahasa diterjemahkan ke Bahasa Indonesia, struktur ditranskripsikan secara
semantik, dan koreksi yang tercatat diterapkan. Tidak ada persetujuan atau
dukungan oleh penulis maupun MIT yang tersirat.

Lima grafik Athena Scientific pada halaman 20–28 berada di luar izin umum yang
dibuktikan untuk redistribusi: tidak ada byte, tata letak, atau salinan grafik
sumber yang disertakan. Deskripsi teks dan locator independen menggantikan
salinannya. Teks legal CC BY-NC-SA 4.0 yang dibekukan dari sumber resmi
disertakan di dalam bundel delta.

Berkas yang diwarisi dari versi induk mempertahankan hak masing-masing:
Habring CC BY 4.0, Griffin/Penn CC BY-NC-SA 3.0 United States, dan pembekuan
sumber Royer CC BY-NC 4.0. Catatan ini tidak mengganti hak komponen tersebut
dengan lisensi payung.

