# O015 production cursor

As of: 2026-08-22  
State: Habring Chapters 3–9 and Penn Chapters 3–4 admitted after independent audits; Penn Chapter 5 is the active cursor

## Completed production

- Authority frozen: Penn State MATH 555 official index, public v1.0.1 PDF, editable v1.0 source archive, legal code, entry manifest, and reproducible local build.
- Authority frozen: Habring arXiv:2607.11664v1 PDF, source tar, metadata, CC BY 4.0 legal code, extracted closure, experimental HTML witness, and local build.
- Bounded three-candidate comparison complete; no replacement admitted.
- O018 overlap/exclusion map complete.
- Habring Chapter 3 translated contiguously into id-ID with exact two-figure closure and an independent standalone master.
- Open-solver validation passes for the absolute-value and composite $\ell^1$ examples.
- Structural/formula audit and independent final mathematical rereview pass with P1=0, P2=0, P3=0.
- All 15 reader pages have been visually inspected; the final PDF is deterministic across two consecutive builds.
- A deterministic locale-neutral first-unit backend is implemented in JSONL with a lossless CSV projection and a bounded validator.
- Habring Chapter 4 has been translated contiguously with eight stable segments, all 67 ordered environments and four authority labels preserved.
- Nine substantive authority defects are transparently corrected and ledger-bound; structural/formula audit, open-solver validation, deterministic rebuild, all-page visual inspection, and independent mathematical rereview all pass.
- Chapter 5 authority identity, closure, topology, dependencies, and correction plan are frozen in `CHAPTER05_SOURCE_AUDIT.md`; the complete translation preserves 78 ordered environments in eight stable segments and has passed structural/formula, computation, deterministic-build, visual, and independent mathematical gates.
- The public corpus repository at `https://github.com/KokunoYumeto/advanced-optimization-convex-analysis-id` has a verified four-unit `main` checkpoint through Chapter 6; exact commit/tree and byte-readback evidence are in `PUBLICATION_RECEIPTS.md`.
- The six-unit Habring backend through Chapter 8 validated deterministically at that historical boundary and contained 53 stable segments. The current nine-unit backend is validated by `qa/validate_backend_penn_ch04.py`. Chapter 6's exact topology, twelve segments, dependencies, correction plan, and admission outcome are frozen in `CHAPTER06_SOURCE_AUDIT.md`.
- Chapter 6 is translated contiguously with all 99 ordered environments, seven labels, eight internal reference calls, and twelve stable segments preserved. Eleven ledger-bound source repairs, structural/formula audit, numerical validation, deterministic build, all-page visual inspection, and independent final delta rereview pass with P1=0, P2=0, P3=0.
- Chapter 7 is translated contiguously with all 148 ordered environments, 24 label occurrences, the complete 34-reference/two-citation/one-footnote surface, five learner prompts, and eleven stable segments preserved. Twenty-six ledger-bound source repairs, structural/formula audit, open numerical validation, two byte-identical fixed-epoch builds, all-page visual inspection, and independent final rereview pass with P1=0, P2=0, P3=0. Its exact closure and admission evidence are frozen in `CHAPTER07_SOURCE_AUDIT.md`.
- Chapter 8 is translated contiguously with all 24 ordered environments and its sole label/reference pair preserved in three stable segments. Eight ledger-bound repairs close finite-sum scaling, projected-SGD scope, conditional-oracle, second-moment, indexing, and final-bound defects. Repeated structural/formula audit, 24-gate exact stochastic validation, byte-identical builds, all-page visual inspection, and independent review pass with P1=0, P2=0, P3=0. Its exact closure and admission evidence are frozen in `CHAPTER08_SOURCE_AUDIT.md`.
- Chapter 9 is translated contiguously with all 47 ordered environments, five labels, native TikZ figure, complete citation/footnote/glossary surface, and every nonblank authority line preserved in nine stable segments. Events O015-HAB-ADV-0084 through O015-HAB-ADV-0096 close its measure-theoretic, duality, discrete-typing, entropy, factorization, Sinkhorn, and bibliography defects. Repeated structural/formula audit, 41-gate open numerical validation, byte-identical builds, all-page visual inspection, and independent review pass with P1=0, P2=0, P3=0. Exact evidence is frozen in `CHAPTER09_SOURCE_AUDIT.md` and `qa/CHAPTER09_WORKLOG.md`.
- Penn Chapter 3 is translated contiguously with all 142 ordered environments, 35 labels, the same 37 unique reference targets, nine citations, four exact vector figures, twelve exercises, and every authority line preserved in eight stable segments. Events O015-PENN-ADV-0004 through O015-PENN-ADV-0024 close its algorithm-state, theorem, code/output, identifier, and numerical defects. Repeated structural/formula audit, 31-gate open numerical validation, byte-identical builds, all-page visual inspection, and independent review pass with P1=0, P2=0, P3=0. Exact evidence is frozen in `PENN_CH03_SOURCE_AUDIT.md` and `qa/PENN_CH03_WORKLOG.md`.
- Penn Chapter 4 is translated contiguously with all 112 ordered environments, 32 labels, 66 displayed-formula pairs, four citations, five exact vector figures, four exercises, and every authority line preserved in seven stable segments. Events O015-PENN-ADV-0025 through O015-PENN-ADV-0037 close its Wolfe/Armijo, theorem-scope, convergence-factor, Newton, code, and identifier defects. Repeated 22-gate structural/formula audit, 12-gate open numerical validation, byte-identical builds, all-page visual inspection, and independent review pass with P1=0, P2=0, P3=0. Two forced algorithm floats were reflowed without topology change. Exact evidence is frozen in `PENN_CH04_SOURCE_AUDIT.md` and `qa/PENN_CH04_WORKLOG.md`.
- The nine-unit backend through Penn Chapter 4 contains 1,128 deterministic records and 77 segments; its JSONL/CSV hashes are `d378b1fc…` / `b36ecc26…`. The stabilized 973-record baseline has SHA-256 `a53d556f…`; its 861 semantic records and 109 non-refreshed artifacts remain unchanged, while only enumerated live control-artifact bindings were refreshed.

## Exact cursor

- Current completed source unit: `authority/penn-state/source/ClassNotes/Section4.tex`
- Current target unit: `source/id-ID/penn-04-pencarian-garis-hampiran-dan-konvergensi-id.tex`
- Next source file: `authority/penn-state/source/ClassNotes/Section5.tex`
- Next unit title: Newton's Method and Corrections / Metode Newton dan Koreksi
- Do not restart at preliminaries or convexity; those are admitted as prerequisites/overlap, not untranslated cursor gaps.

## Next actions

1. Admit the already audited and built Penn Chapter 5 candidate into the shared ledger, rights map, controls, and backend. Its target is 27,317 bytes / 400 lines / SHA-256 `0f6afd7da2268661124f967f299ac9df89bb6a8f5683b3e4e8fea32718a8549a`; its 15-page PDF is 2,691,780 bytes / SHA-256 `427db2c5a4428dfbe222d7e1d4f5c5349d4f78484a8593c412328fe94a7353c6`; independent rereview and visual QA pass.
2. Continue the non-overlapping Penn smooth numerical sequence in source order; do not admit Penn Chapter 9 or empty Chapter 11 headings.
3. Add independently authored assessments/solutions only where the exact source mastery gap has been documented and component rights remain separate.
4. Build a semantic HTML/EPUB accessibility surface before any final corpus publication claim.
5. Maintain coherent verified checkpoints in the same Zenodo concept lineage while GitHub is suspended. Resume narrow corpus-repository commits and pushes only after the provider restores access.

The GitHub suspension is an operational pause, not a production or preservation pause; do not probe or retry the account while the support ticket is open. Upstream contact remains prohibited until the complete corpus is finished; then at most one concise high-confidence report may be submitted, signed `Codex — at the user’s direction`.
