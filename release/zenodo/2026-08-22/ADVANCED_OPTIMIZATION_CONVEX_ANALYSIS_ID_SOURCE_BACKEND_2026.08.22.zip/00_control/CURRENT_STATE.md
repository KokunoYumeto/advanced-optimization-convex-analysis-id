# O015 current state

As of: 2026-08-22  
Lane: D90 — Advanced Optimization and Convex Analysis  
Locale: id-ID  
Status: nine bounded reader units admitted; Penn Chapter 5 is active; corpus is incomplete

## Ownership and scope

This is the sole active O015 production lane. It owns one Indonesian reader corpus, one locale-neutral modular backend, and one corpus-specific GitHub repository. O018 is adjacent but disjoint: it owns LP/IP modeling, simplex, finite-dimensional LP duality, sensitivity, graph/network algorithms, and general OR solver workflows. The curriculum coordinator owns the later global hub; this lane does not.

## Frozen authority

- Andreas Habring, *Lecture Notes: Convex Optimization*, arXiv:2607.11664v1, CC BY 4.0: immutable PDF, source tar, API record, legal code, and 22-file editable closure are bound in `SOURCE_AUTHORITY.json`.
- Christopher Griffin, *Nonlinear Programming* / Penn State MATH 555, CC BY-NC-SA 3.0 US: editable v1.0 source plus the public v1.0.1 PDF correction witness are frozen. Penn is admitted only for the later non-overlapping smooth numerical sequence.
- The bounded comparator pass found no stronger source that simultaneously provides editable closure, derivative permission, modern nonsmooth coverage, and solutions.

## Admitted reader units

Habring Chapter 3, “Subgradients,” has been translated contiguously as `source/id-ID/habring-03-subgradien-id.tex` and wrapped by `source/id-ID/D90-HAB-03-subgradien-id.tex`.

- Authority source: 16,939 bytes; SHA-256 `c3b447ee9ea5d8dbf98333b927ad5b7408d1d66884c3b7d5590251dfc47c5405`.
- Indonesian unit: 19,266 bytes; SHA-256 `d04ff82898c157f56924c6c08fd204bcd97625f060847fd8a0b6f7a2b90b0a5c`.
- Reader PDF: 15 A4 pages; 516,084 bytes; SHA-256 `45f7bc24ff46079881e42be9aa6f1b508c324a208f2b4dd82e35e7e3a6d544b4`.
- Habring Chapter 4, “Projected subgradient descent,” is translated contiguously as `source/id-ID/habring-04-metode-subgradien-terproyeksi-id.tex` and wrapped by `source/id-ID/D90-HAB-04-metode-subgradien-terproyeksi-id.tex`.
- Chapter 4 authority source: 14,391 bytes; SHA-256 `44ac28a0f0b67fed4855f7ed91089fab52f77804115f2a06201bff98437bd8da`.
- Chapter 4 Indonesian unit: 16,612 bytes; SHA-256 `29fdc330007009bd765a17ca1dcd0cf130ff802312ebb402bf03413da5f96a7d`.
- Chapter 4 reader PDF: 13 A4 pages; 370,824 bytes; SHA-256 `5c9991af837995b2e24f4a9060eb3b0efe7b2d71a9bbde01948eeb81ebfd63b7`.
- Habring Chapter 5, “Proximal Gradient Methods,” is translated contiguously as `source/id-ID/habring-05-metode-gradien-proksimal-id.tex` and wrapped by `source/id-ID/D90-HAB-05-metode-gradien-proksimal-id.tex`.
- Chapter 5 authority source: 18,464 bytes; SHA-256 `59d5694742f0e2f9f46da0c1418b5fe0ff18521c49078ed29c843b6e8c701f6e`.
- Chapter 5 Indonesian unit: 20,575 bytes; SHA-256 `1292f09d375ff0e0ff12e7c87e673596400bb94f228db70d49f9a517b1678691`.
- Chapter 5 reader PDF: 15 A4 pages; 473,685 bytes; SHA-256 `6f8aa99f6d0395f3c732ed64d2b5cadd5d95ff2195e2504e959d31a3c010731d`.
- Habring Chapter 6, “Acceleration,” is translated contiguously as `source/id-ID/habring-06-akselerasi-id.tex` and wrapped by `source/id-ID/D90-HAB-06-akselerasi-id.tex`.
- Chapter 6 authority source: 18,873 bytes; SHA-256 `2ff1e10e9421c0fe01a09140e3e230cb2d3728c30c572bb6ca5513b229f1e605`.
- Chapter 6 Indonesian unit: 24,690 bytes; SHA-256 `b1e27d912bc94722ec1c33257598c074eec8a6f5bf81f43b8946f85b48f4c35a`.
- Chapter 6 reader PDF: 15 A4 pages; 392,662 bytes; SHA-256 `cb9edf46d8d2582591ad3114f9a2b316073825dfd48079d12560793ad4bca0a0`.
- Habring Chapter 7, “Duality,” is translated contiguously as `source/id-ID/habring-07-dualitas-id.tex` and wrapped by `source/id-ID/D90-HAB-07-dualitas-id.tex`.
- Chapter 7 authority source: 30,761 bytes; SHA-256 `0b112dee2582813cec5629c02df1dda329f690f944b60f4694b1c5762129bea9`.
- Chapter 7 Indonesian unit: 35,428 bytes; SHA-256 `11e9ad614f7ac4e3107e78bc3bed03a6d4acfe22f2a65fca26433b0ae3209fd9`.
- Chapter 7 reader PDF: 21 A4 pages; 445,733 bytes; SHA-256 `c4354e1e1366bdb20cebb9c6eca26fba172d6d82a6ad22dd9e2e470da2baeb6e`.
- Habring Chapter 8, “Stochastic Gradient Descent,” is translated contiguously as `source/id-ID/habring-08-penurunan-gradien-stokastik-id.tex` and wrapped by `source/id-ID/D90-HAB-08-penurunan-gradien-stokastik-id.tex`.
- Chapter 8 authority source: 4,665 bytes; SHA-256 `610d11b59d8dfabbbbe6fbc509a0f9ac1727540458c67f8cd3b7bab49566a07d`.
- Chapter 8 Indonesian unit: 6,378 bytes; SHA-256 `f610aaec91aa9b76582f251458da65d25cc37a933a51da478cad13ee16e5a344`.
- Chapter 8 reader PDF: 8 A4 pages; 346,785 bytes; SHA-256 `c1ed028667c5df3fd0a837807e2a17bf7a9e1fa3170938853c9a96b9670fa86a`.
- Habring Chapter 9, “Excursion on Optimal Transport,” is translated contiguously as `source/id-ID/habring-09-transportasi-optimal-id.tex` and wrapped by `source/id-ID/D90-HAB-09-transportasi-optimal-id.tex`.
- Chapter 9 authority source: 15,378 bytes; SHA-256 `719df724b368126cc7540dffd461dc33aba7d5b5b6060132181086dfa17649ba`.
- Chapter 9 Indonesian unit: 21,252 bytes; SHA-256 `45c0eef50b535ffb8722ad74caf4df0bf014f5eebb43d13b24f00639018ca3bd`.
- Chapter 9 reader PDF: 15 A4 pages; 498,244 bytes; SHA-256 `edc8e17fd43d17a0dd7811879dfbedaab9ac226c291ed5558ca0bfbb3ce10214`.
- Penn Chapter 3, “Introduction to Gradient Ascent and Line Search Methods,” is translated contiguously as `source/id-ID/penn-03-pendakian-gradien-dan-pencarian-garis-id.tex` and wrapped by `source/id-ID/D90-PENN-03-pendakian-gradien-dan-pencarian-garis-id.tex`.
- Penn Chapter 3 authority source: 41,715 bytes; SHA-256 `d4ae6142e2366b12575eafddc833df067518af114e9816187668cc367be43010`.
- Penn Chapter 3 Indonesian unit: 44,364 bytes; SHA-256 `7c75d0ae56a5a912d561d91ece607f088a4ff4f3de4dbc3396ce40d6d7d6a229`.
- Penn Chapter 3 reader PDF: 20 A4 pages; 515,851 bytes; SHA-256 `e1be82d06572c51b403608cd9595cc5adf2dc64cfa93f53001eba94e48f77e3e`.
- Penn Chapter 4, “Approximate Line Search and Convergence of Gradient Ascent,” is translated contiguously as `source/id-ID/penn-04-pencarian-garis-hampiran-dan-konvergensi-id.tex` and wrapped by `source/id-ID/D90-PENN-04-pencarian-garis-hampiran-dan-konvergensi-id.tex`.
- Penn Chapter 4 authority source: 34,684 bytes; SHA-256 `76113034709b5914fa920076f2e882ccf30157e78ce5bdf4593a5d39af1886d5`.
- Penn Chapter 4 Indonesian unit: 33,313 bytes; SHA-256 `c5c0f09d38454177e61c2a97c9beef07771d5f4f715cc7a4a81a871ff54ced8f`.
- Penn Chapter 4 reader PDF: 17 A4 pages; 847,350 bytes; SHA-256 `c0f283aa7d70eba05de6a35c98bc0aa55f3177ab40702bf7eed5de45a7b6ab8a`.
- Stable backend: nine-unit deterministic JSONL and lossless CSV through Penn Chapter 4, containing 1,128 records and 77 source-linked translation segments (11/8/8/12/11/3/9 Habring plus 8/7 Penn). JSONL is 829,770 bytes, SHA-256 `d378b1fcaf46fc83076a9961da16ff96d5f50e22912ede054be923a6bd389650`; CSV is 994,096 bytes, SHA-256 `b36ecc26c8080786d6f0eacd3d3af7ffb6bbf81151400b561853751b72cc34df`. Two complete `extend_backend_penn_ch04.py` / `validate_backend_penn_ch04.py` cycles were byte-identical and returned zero errors.

Habring Chapter 3 preserves all 61 source environments and eleven stable segments. Chapter 4 preserves all 67 source environments, four authority labels, and eight stable segments. Chapter 5 preserves all 78 source environments, nine label occurrences with the duplicate source label uniquely mapped, and eight stable segments. Chapter 6 preserves all 99 ordered environments, seven labels, eight internal reference calls, and twelve stable segments. Chapter 7 preserves all 148 ordered environments, 24 label occurrences with only the duplicated final source label uniquely remapped, the complete 34-reference surface, two citations, one footnote, five learner prompts, and eleven stable segments. Chapter 8 preserves all 24 ordered environments and its sole label/reference pair in three stable segments. Chapter 9 preserves all 47 ordered environments, five labels, the complete citation/footnote/glossary/TikZ surface, and every nonblank authority line in nine stable segments. Penn Chapter 3 preserves all 142 ordered environments, 35 labels, 37 unique reference targets, nine citations, four exact figures, twelve exercises, and all 608 authority lines in eight stable segments. Penn Chapter 4 preserves all 112 ordered environments, 32 labels, 66 displayed formulas, five exact figures, four exercises, and all 469 authority lines in seven stable segments. Ninety-six Habring and thirty-seven Penn adverse events are explicit in `ADVERSE_LEDGER.jsonl`; no correction was reported upstream during production.

## Admission evidence

- Structural/formula audits: PASS for all seven Habring units; Habring Chapter 3 has 46 dispositioned formula-delta blocks (manifest `c979be4e…`), Chapter 4 has 40 (`d0453330…`), Chapter 5 has 38 (`3b910b86…`), Chapter 6 has 32 (`886d80e0…`), Chapter 7 has 49 (`fe72e72d…`), Chapter 8 has 7 substantive blocks (`2f9632d0…`), and Chapter 9 has 35 blocks / 34 substantive (`796e13fb…`).
- Penn Chapter 3 structural/formula audit: PASS with 499 source and 570 target math records, 230 canonical pairs, 89 fully bound delta blocks, and report/manifest hashes `97af8d89…` / `af04268d…`.
- Penn Chapter 4 structural/formula audit: PASS across 22 gates with 66 ordered formula pairs, 26 determined/event-bound pairs, and report/manifest hashes `c43e0195…` / `fe7aa0bb…`.
- Independent mathematical rereviews: PASS for all seven Habring units, each with P1=0, P2=0, P3=0 at its frozen admitted target.
- Penn Chapter 3 independent rereview: PASS with P1=0, P2=0, P3=0; open numerical validation passes 31/31 checks including eleven negative controls.
- Penn Chapter 4 independent rereview: PASS with P1=0, P2=0, P3=0 after one repaired P3 wording defect; open numerical validation passes 12/12 fail-closed gates.
- Open computation checks: PASS with Python 3.13.9, NumPy 2.4.4, SciPy 1.17.1, HiGHS, and SLSQP.
- PDF builds: forced final rebuilds produced byte-identical artifacts; no unresolved references or TeX errors. Chapter 6 retains two small, visually contained display overfull warnings, recorded in `BUILD_AND_QA.md`.
- Visual review: all 139 physical pages across the nine admitted PDFs inspected; selected mathematical, algorithm, figure, and correction surfaces inspected at full size; no clipping, collision, or unreadable page found.
- Accessibility: searchable text, `/Lang` set to `id-ID`, Indonesian descriptions for both figures. The PDF is untagged; semantic HTML/EPUB remains required before final corpus publication.

## Known incomplete surfaces

The authorities supply sparse exercises and no systematic answer or solution layer in the admitted units. Independent Indonesian language review has not yet been recorded. The remaining Penn chapters, authored assessment layer, semantic HTML/EPUB reader, interactive computation surfaces, and final corpus publication remain incomplete.

## Public corpus checkpoint

The GitHub mirror remains `https://github.com/KokunoYumeto/advanced-optimization-convex-analysis-id`; its last verified public `main` checkpoint is content commit `fd7aa44f06702c6ddf35886db9534b33411e6114`. GitHub access is temporarily suspended by the provider after VPN use, and the user has filed a support ticket; do not retry Git or GitHub operations until access is restored. A separately maintained nine-unit Zenodo preservation checkpoint is staged under reserved version DOI `10.5281/zenodo.22059742` and concept DOI `10.5281/zenodo.22059741`. It is explicitly labeled incomplete and will be recorded as public only after exact-inventory validation and anonymous byte readback. No upstream contact has occurred.

## Exact continuation

Continue with the already translated candidate `authority/penn-state/source/ClassNotes/Section5.tex` (Penn Chapter 5; 22,371 bytes; 317 lines; SHA-256 `15186b99be0913d83046e3e32eaf7a378d3a4fccd222219984b091ddf7f9a428`). Penn Chapters 3 and 4 are fully admitted; exact Chapter 4 evidence is in `PENN_CH04_SOURCE_AUDIT.md` and `qa/PENN_CH04_WORKLOG.md`. Independently audit, build, and admit Chapter 5 before advancing to `Section6.tex`. Preserve the O018 exclusion boundary and keep translation dominant. Completion of this edition remains independent of the curriculum root's later admission decision.
